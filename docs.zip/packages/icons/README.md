# @root/icons

A generated React icon component package. Converts raw SVG assets into tree-shakeable TSX components that inherit color via `currentColor`.

## Generation

Run from workspace root:

```bash
npm run generate:icons
```

The generator scans `packages/design-system/icons` directories and produces components in `packages/icons/src/generated`.

## Usage

```tsx
import { InfoIcon } from '@root/icons';

export const Example = () => (
  <div style={{ color: '#3b82f6' }}>
    <InfoIcon width={24} height={24} />
  </div>
);
```

Icons do not hardcode any `fill` or `stroke`; they rely on `currentColor`.

## Registry API

```tsx
import { getIconComponent } from '@root/icons';
const Dynamic = getIconComponent('info', 'rounded', 'regular');
```

## Adding new assets
Place new SVGs following naming convention:
`fi-bs-<name>.svg`, `fi-rs-<name>.svg`, `fi-sr-<name>.svg`, etc.
Run generation again.
