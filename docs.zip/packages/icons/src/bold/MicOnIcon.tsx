import * as React from 'react';
export const MicOnIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M18 10V11C18 14.3137 15.3137 17 12 17M6 10V11C6 14.3137 8.68629 17 12 17M12 17V21M16 21H12M12 21H8M12 14C10.3431 14 9 12.6569 9 11V6C9 4.34315 10.3431 3 12 3C13.6569 3 15 4.34315 15 6V11C15 12.6569 13.6569 14 12 14Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default MicOnIcon;
