import * as React from 'react';
export const SecurityShieldIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M4.18962 5.599C4.30692 4.66133 5.12049 4 6.06546 4H17.9345C18.8795 4 19.6931 4.66133 19.8104 5.599C20.0197 7.27187 20.1895 9.94304 19.5556 12.0526C18.5721 15.3253 14.989 18.5945 13.1325 20.1165C12.4674 20.6617 11.5326 20.6617 10.8675 20.1165C9.01104 18.5945 5.42793 15.3253 4.44445 12.0526C3.81049 9.94304 3.98033 7.27187 4.18962 5.599Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default SecurityShieldIcon;
