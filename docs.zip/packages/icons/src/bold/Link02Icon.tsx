import * as React from 'react';
export const Link02Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M13.7677 10.2322C15.3298 11.7943 15.3298 14.327 13.7677 15.8891L10.5858 19.0711C9.02365 20.6332 6.49099 20.6332 4.9289 19.0711C3.3668 17.509 3.3668 14.9763 4.9289 13.4142M19.071 10.5858C20.6331 9.02368 20.6331 6.49102 19.071 4.92893C17.5089 3.36683 14.9763 3.36683 13.4142 4.92893L10.2322 8.11091C8.6701 9.67301 8.6701 12.2057 10.2322 13.7678" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Link02Icon;
