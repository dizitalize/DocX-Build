import * as React from 'react';
export const ChevronTopLeftDuoIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M16.8424 11.1855H11.1855V16.8424M13.3068 7.64999H7.64999V13.3068" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default ChevronTopLeftDuoIcon;
