import * as React from 'react';
export const Message1Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M5.25 8C5.25 5.79086 7.04086 4 9.25 4H17C19.2091 4 21 5.79086 21 8V16C21 18.2091 19.2091 20 17 20H3L4.59419 17.5708C5.02205 16.9188 5.25 16.156 5.25 15.3761V8Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Message1Icon;
