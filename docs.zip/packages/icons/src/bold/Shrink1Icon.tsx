import * as React from 'react';
export const Shrink1Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M10.5858 19.0711V13.4142H4.92892M19.0711 10.5858L13.4142 10.5858L13.4142 4.92892" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Shrink1Icon;
