import * as React from 'react';
export const HeadphonesIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M3 17C3 18.6569 4.34315 20 6 20C7.65685 20 9 18.6569 9 17C9 15.3431 7.65685 14 6 14C4.34315 14 3 15.3431 3 17ZM3 17V13C3 8.02944 7.02944 4 12 4C16.9706 4 21 8.02944 21 13V17M21 17C21 18.6569 19.6569 20 18 20C16.3431 20 15 18.6569 15 17C15 15.3431 16.3431 14 18 14C19.6569 14 21 15.3431 21 17Z" stroke-width="2"/>
</svg>);
export default HeadphonesIcon;
