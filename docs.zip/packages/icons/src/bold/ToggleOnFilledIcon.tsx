import * as React from 'react';
export const ToggleOnFilledIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" stroke-width="2">
<path d="M2 12C2 8.68629 4.68629 6 8 6H16C19.3137 6 22 8.68629 22 12C22 15.3137 19.3137 18 16 18H8C4.68629 18 2 15.3137 2 12Z" fill="black"/>
<circle cx="16" cy="12" r="4" fill="white"/>
</svg>);
export default ToggleOnFilledIcon;
