import * as React from 'react';
export const Settings03Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M11 3.57734C11.6188 3.22007 12.3812 3.22007 13 3.57734L18.7942 6.92264C19.413 7.2799 19.7942 7.94016 19.7942 8.65469V15.3453C19.7942 16.0598 19.413 16.7201 18.7942 17.0773L13 20.4226C12.3812 20.7799 11.6188 20.7799 11 20.4226L5.20575 17.0773C4.58695 16.7201 4.20575 16.0598 4.20575 15.3453V8.65469C4.20575 7.94015 4.58695 7.2799 5.20575 6.92264L11 3.57734Z" stroke-width="2" stroke-linejoin="round"/>
<path d="M15 12C15 13.6568 13.6568 15 12 15C10.3431 15 8.99998 13.6568 8.99998 12C8.99998 10.3431 10.3431 8.99999 12 8.99999C13.6568 8.99999 15 10.3431 15 12Z" stroke-width="2" stroke-linejoin="round"/>
</svg>);
export default Settings03Icon;
