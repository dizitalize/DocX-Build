import * as React from 'react';
export const ChevronBottomDuoIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M8 7.5L12 11.5L16 7.5M8 12.5L12 16.5L16 12.5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default ChevronBottomDuoIcon;
