import * as React from 'react';
export const Frame9stopIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M8.27208 3L15.7279 3L21 8.27208L21 15.7279L15.7279 21L8.27208 21L3 15.7279L3 8.27208L8.27208 3Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Frame9stopIcon;
