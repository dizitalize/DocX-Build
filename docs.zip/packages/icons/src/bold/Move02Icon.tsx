import * as React from 'react';
export const Move02Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M12 2V22M12 2L9 5M12 2L15 5M12 22L9 19M12 22L15 19M2 12L22 12M2 12L5 15M2 12L5 9M22 12L19 15M22 12L19 9" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Move02Icon;
