import * as React from 'react';
export const MessageMoreIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M5.25 8C5.25 5.79086 7.04086 4 9.25 4H17C19.2091 4 21 5.79086 21 8V16C21 18.2091 19.2091 20 17 20H3L4.59419 17.5708C5.02205 16.9188 5.25 16.156 5.25 15.3761V8Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M14 12C14 12.5523 13.5523 13 13 13C12.4477 13 12 12.5523 12 12C12 11.4477 12.4477 11 13 11C13.5523 11 14 11.4477 14 12Z" fill="black"/>
<path d="M18 12C18 12.5523 17.5523 13 17 13C16.4477 13 16 12.5523 16 12C16 11.4477 16.4477 11 17 11C17.5523 11 18 11.4477 18 12Z" fill="black"/>
<path d="M10 12C10 12.5523 9.55228 13 9 13C8.44772 13 8 12.5523 8 12C8 11.4477 8.44772 11 9 11C9.55228 11 10 11.4477 10 12Z" fill="black"/>
</svg>);
export default MessageMoreIcon;
