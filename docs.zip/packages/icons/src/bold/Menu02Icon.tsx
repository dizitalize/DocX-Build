import * as React from 'react';
export const Menu02Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M3 5C3 3.89543 3.89543 3 5 3H8C9.10457 3 10 3.89543 10 5V6C10 7.10457 9.10457 8 8 8H5C3.89543 8 3 7.10457 3 6V5Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M3 14C3 12.8954 3.89543 12 5 12H8C9.10457 12 10 12.8954 10 14V19C10 20.1046 9.10457 21 8 21H5C3.89543 21 3 20.1046 3 19V14Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M14 5C14 3.89543 14.8954 3 16 3H19C20.1046 3 21 3.89543 21 5V10C21 11.1046 20.1046 12 19 12H16C14.8954 12 14 11.1046 14 10V5Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M14 18C14 16.8954 14.8954 16 16 16H19C20.1046 16 21 16.8954 21 18V19C21 20.1046 20.1046 21 19 21H16C14.8954 21 14 20.1046 14 19V18Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Menu02Icon;
