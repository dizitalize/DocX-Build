import * as React from 'react';
export const MailIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M4 6.35418C4.73294 5.52375 5.80531 5 7 5H17C18.0144 5 18.9407 5.37764 19.6458 6M4 6.35418C3.37764 7.05931 3 7.98555 3 9V15C3 17.2091 4.79086 19 7 19H17C19.2091 19 21 17.2091 21 15V9C21 7.80531 20.4762 6.73294 19.6458 6M4 6.35418L12 13L19.6458 6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default MailIcon;
