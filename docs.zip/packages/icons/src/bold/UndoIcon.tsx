import * as React from 'react';
export const UndoIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M5 9.24264C5.80974 7.84012 8.0212 6.01912 9.53689 5.44866C11.0526 4.87819 12.7192 4.85092 14.2527 5.37149C15.7863 5.89206 17.0919 6.92825 17.9471 8.30353C18.8023 9.6788 19.1541 11.3081 18.9428 12.9137C18.7314 14.5193 17.9698 16.002 16.7878 17.109C15.6058 18.2161 14.0765 18.8791 12.4605 18.985C10.8444 19.0909 9.24169 18.6332 7.9253 17.6899C6.6089 16.7466 5.66031 15.376 5.24116 13.8117M5 9.24264H9.24264M5 9.24264V5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default UndoIcon;
