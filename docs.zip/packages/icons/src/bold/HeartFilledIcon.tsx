import * as React from 'react';
export const HeartFilledIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" stroke-width="2">
<path fill-rule="evenodd" clip-rule="evenodd" d="M3.57212 5.43149C5.66827 3.33533 9.06682 3.33534 11.163 5.43149L12 6.26854L12.837 5.43153C14.9332 3.33537 18.3317 3.33537 20.4279 5.43153C22.524 7.52768 22.524 10.9262 20.4279 13.0224L14.2357 19.2145C13.001 20.4493 10.999 20.4493 9.76424 19.2145L3.57211 13.0223C1.47596 10.9262 1.47596 7.52765 3.57212 5.43149Z" fill="black"/>
</svg>);
export default HeartFilledIcon;
