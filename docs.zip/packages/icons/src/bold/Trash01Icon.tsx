import * as React from 'react';
export const Trash01Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M18 6V17C18 19.2091 16.2091 21 14 21H10C7.79086 21 6 19.2091 6 17V6M18 6H16M18 6H20M6 6H4M6 6H8M8 6V5C8 3.89543 8.89543 3 10 3H14C15.1046 3 16 3.89543 16 5V6M8 6H16" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Trash01Icon;
