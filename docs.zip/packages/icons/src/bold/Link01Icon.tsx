import * as React from 'react';
export const Link01Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M14.5 12C14.5 14.2091 12.7091 16 10.5 16H6C3.79086 16 2 14.2091 2 12C2 9.79086 3.79086 8 6 8M18 16C20.2091 16 22 14.2091 22 12C22 9.79086 20.2091 8 18 8H13.5C11.2909 8 9.5 9.79086 9.5 12" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Link01Icon;
