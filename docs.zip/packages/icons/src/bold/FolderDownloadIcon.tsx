import * as React from 'react';
export const FolderDownloadIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M12 11V16M12 16L14 14M12 16L10 14M8.92963 4H5C3.89543 4 3 4.89543 3 6V16C3 18.2091 4.79086 20 7 20H17C19.2091 20 21 18.2091 21 16V11C21 8.79086 19.2091 7 17 7H13.0704C12.4017 7 11.7772 6.6658 11.4063 6.1094L10.5937 4.8906C10.2228 4.3342 9.59834 4 8.92963 4Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default FolderDownloadIcon;
