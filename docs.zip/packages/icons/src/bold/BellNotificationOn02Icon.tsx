import * as React from 'react';
export const BellNotificationOn02Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M14 18V19C14 20.1046 13.1046 21 12 21C10.8954 21 10 20.1046 10 19V18M12 5V3M12 5C14.7614 5 17 7.23858 17 10V15H17.5C18.3284 15 19 15.6716 19 16.5C19 17.3284 18.3284 18 17.5 18H6.5C5.67157 18 5 17.3284 5 16.5C5 15.6716 5.67157 15 6.5 15H7V10C7 7.23858 9.23858 5 12 5Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default BellNotificationOn02Icon;
