import * as React from 'react';
export const CreditCard02Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M13 12.2676C12.7058 12.0974 12.3643 12 12 12C10.8954 12 10 12.8954 10 14C10 15.1046 10.8954 16 12 16C12.3643 16 12.7058 15.9026 13 15.7324M20 19L4 19C2.89543 19 2 18.1046 2 17L2 7C2 5.89543 2.89543 5 4 5L20 5C21.1046 5 22 5.89543 22 7L22 17C22 18.1046 21.1046 19 20 19ZM19 14C19 15.1046 18.1046 16 17 16C15.8954 16 15 15.1046 15 14C15 12.8954 15.8954 12 17 12C18.1046 12 19 12.8954 19 14Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default CreditCard02Icon;
