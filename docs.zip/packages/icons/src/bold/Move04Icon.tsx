import * as React from 'react';
export const Move04Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M14 10L21 3M14 10L14 5.75738M14 10L18.2426 10M3 21L10 14M10 14L10 18.2427M10 14L5.75736 14" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Move04Icon;
