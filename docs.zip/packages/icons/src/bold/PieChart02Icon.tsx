import * as React from 'react';
export const PieChart02Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M12 3C7.02944 3 3 7.02944 3 12C3 16.9706 7.02944 21 12 21C16.9706 21 21 16.9706 21 12C21 7.02944 16.9706 3 12 3ZM12 3C13.9812 3 15.9071 3.65374 17.4789 4.85982C18.7215 5.81332 19.6879 7.06991 20.2916 8.5M12 3V12M12 12L18.364 18.364C19.4811 17.2469 20.2844 15.8554 20.6933 14.3294C21.1022 12.8034 21.1022 11.1966 20.6933 9.67063C20.5859 9.26985 20.4515 8.87884 20.2916 8.5M12 12L20.2916 8.5" stroke-width="2" stroke-linejoin="round"/>
</svg>);
export default PieChart02Icon;
