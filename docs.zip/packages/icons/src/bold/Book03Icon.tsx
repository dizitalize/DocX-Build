import * as React from 'react';
export const Book03Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M21 15V6C21 4.89543 20.1049 4 19.0003 4H15C13 4 12 5 12 7M21 15C21 16.1046 20.1049 17 19.0003 17H15C13 17 12 18 12 20M21 15V18C21 19.1046 20.1046 20 19 20H12M3 15V6C3 4.89543 3.89515 4 4.99972 4H9C11 4 12 5 12 7M3 15C3 16.1046 3.89515 17 4.99972 17H9C11 17 12 18 12 20M3 15V18C3 19.1046 3.89543 20 5 20H12M12 7V20" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Book03Icon;
