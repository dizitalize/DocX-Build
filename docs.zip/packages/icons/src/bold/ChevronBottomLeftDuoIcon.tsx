import * as React from 'react';
export const ChevronBottomLeftDuoIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M11.1856 7.14999V12.8068H16.8424M7.65002 10.6855V16.3424H13.3069" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default ChevronBottomLeftDuoIcon;
