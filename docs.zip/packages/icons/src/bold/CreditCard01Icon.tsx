import * as React from 'react';
export const CreditCard01Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M2 10.5L2 17C2 18.1046 2.89543 19 4 19L20 19C21.1046 19 22 18.1046 22 17V10.5M2 10.5L2 7C2 5.89543 2.89543 5 4 5L20 5C21.1046 5 22 5.89543 22 7L22 10.5M2 10.5H22" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default CreditCard01Icon;
