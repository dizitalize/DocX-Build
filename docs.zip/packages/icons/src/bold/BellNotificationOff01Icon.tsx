import * as React from 'react';
export const BellNotificationOff01Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M7 17V10C7 9.13357 7.22038 8.31862 7.60814 7.60814M7 17H5M7 17H10M12 5C14.7614 5 17 7.23858 17 10V12M12 5V3M12 5C11.4021 5 10.8288 5.10493 10.2974 5.29737M14 17V18C14 19.1046 13.1046 20 12 20C10.8954 20 10 19.1046 10 18V17M14 17H10M14 17H17M3.5 3.5L7.60814 7.60814M7.60814 7.60814L17 17M17 17L20.5 20.5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default BellNotificationOff01Icon;
