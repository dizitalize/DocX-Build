import * as React from 'react';
export const FileSearchIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M13 3H9C6.79086 3 5 4.79086 5 7V12M13 3L19 9M13 3V7C13 8.10457 13.8954 9 15 9H19M19 9V17C19 19.2091 17.2091 21 15 21H13M8.98584 17.0142C10.3617 18.39 12.5923 18.39 13.9681 17.0142C15.344 15.6383 15.344 13.4077 13.9681 12.0319C12.5923 10.656 10.3617 10.656 8.98584 12.0319C7.61001 13.4077 7.61001 15.6383 8.98584 17.0142ZM8.98584 17.0142L5 21" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default FileSearchIcon;
