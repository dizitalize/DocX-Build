import * as React from 'react';
export const MessageRemoveIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M10.5 12H15.5M3 20H17C19.2091 20 21 18.2091 21 16V8C21 5.79086 19.2091 4 17 4H9.25C7.04086 4 5.25 5.79086 5.25 8V15.3761C5.25 16.156 5.02205 16.9188 4.59419 17.5708L3 20Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default MessageRemoveIcon;
