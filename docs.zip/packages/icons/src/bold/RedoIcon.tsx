import * as React from 'react';
export const RedoIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M19.0027 9.24264C18.1929 7.84012 15.9814 6.01912 14.4658 5.44866C12.9501 4.87819 11.2835 4.85092 9.74994 5.37149C8.21639 5.89206 6.9108 6.92825 6.0556 8.30353C5.2004 9.6788 4.84851 11.3081 5.0599 12.9137C5.27128 14.5193 6.03286 16.002 7.21487 17.109C8.39687 18.2161 9.92617 18.8791 11.5422 18.985C13.1582 19.0909 14.761 18.6332 16.0774 17.6899C17.3938 16.7466 18.3423 15.376 18.7615 13.8117M19.0027 9.24264H14.76M19.0027 9.24264V5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default RedoIcon;
