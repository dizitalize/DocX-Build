import * as React from 'react';
export const Graph01Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M7 13L10 10H14L17 7M12 17H5C3.89543 17 3 16.1046 3 15V5C3 3.89543 3.89543 3 5 3H19C20.1046 3 21 3.89543 21 5V15C21 16.1046 20.1046 17 19 17H12ZM12 17V21M12 21H17M12 21H7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Graph01Icon;
