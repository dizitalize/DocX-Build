import * as React from 'react';
export const EyeIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M15.4071 12C15.4071 13.8817 13.8817 15.4071 12 15.4071C10.1183 15.4071 8.59295 13.8817 8.59295 12C8.59295 10.1183 10.1183 8.59295 12 8.59295C13.8817 8.59295 15.4071 10.1183 15.4071 12Z" stroke-width="2" stroke-linejoin="round"/>
<path d="M3.18769 12.7128C4.96486 15.8543 8.2461 17.9623 12 17.9623C15.7539 17.9623 19.0351 15.8543 20.8123 12.7128C21.0626 12.2704 21.0626 11.7296 20.8123 11.2872C19.0351 8.14565 15.7539 6.03766 12 6.03766C8.2461 6.03766 4.96486 8.14565 3.18769 11.2872C2.93744 11.7296 2.93744 12.2704 3.18769 12.7128Z" stroke-width="2" stroke-linejoin="round"/>
</svg>);
export default EyeIcon;
