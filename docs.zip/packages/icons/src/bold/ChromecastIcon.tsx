import * as React from 'react';
export const ChromecastIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M13 19H17C19.2091 19 21 17.2091 21 15V9C21 6.79086 19.2091 5 17 5H7C4.79086 5 3 6.79086 3 9M3 16C3.39397 16 3.78407 16.0776 4.14805 16.2284C4.51203 16.3791 4.84274 16.6001 5.12132 16.8787C5.3999 17.1573 5.62088 17.488 5.77164 17.8519C5.9224 18.2159 6 18.606 6 19M3 13C3.78793 13 4.56815 13.1552 5.2961 13.4567C6.02405 13.7583 6.68549 14.2002 7.24264 14.7574C7.79979 15.3145 8.24175 15.9759 8.54328 16.7039C8.84481 17.4319 9 18.2121 9 19" stroke-width="2" stroke-linecap="round"/>
</svg>);
export default ChromecastIcon;
