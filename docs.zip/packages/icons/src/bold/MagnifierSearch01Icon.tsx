import * as React from 'react';
export const MagnifierSearch01Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M20.5 20.5L14.4743 14.4743M14.4743 14.4743C15.6376 13.3109 16.3571 11.7038 16.3571 9.92857C16.3571 6.37817 13.479 3.5 9.92857 3.5C6.37817 3.5 3.5 6.37817 3.5 9.92857C3.5 13.479 6.37817 16.3571 9.92857 16.3571C11.7038 16.3571 13.3109 15.6376 14.4743 14.4743Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default MagnifierSearch01Icon;
