import * as React from 'react';
export const LockIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M12 14V16M16 9.12602V7C16 4.79086 14.2091 3 12 3C9.79086 3 8 4.79086 8 7V9.12602M16 9.12602C15.6804 9.04375 15.3453 9 15 9H9C8.6547 9 8.31962 9.04375 8 9.12602M16 9.12602C17.7252 9.57006 19 11.1362 19 13V17C19 19.2091 17.2091 21 15 21H9C6.79086 21 5 19.2091 5 17V13C5 11.1362 6.27477 9.57006 8 9.12602" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default LockIcon;
