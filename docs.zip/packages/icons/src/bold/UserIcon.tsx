import * as React from 'react';
export const UserIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M12 13C14.1217 13 16.1565 13.8429 17.6568 15.3431C18.2008 15.8871 18.6583 16.5013 19.0206 17.1645C20.0797 19.1032 18.2091 21 16 21H7.99996C5.79082 21 3.92025 19.1032 4.97933 17.1645C5.3416 16.5013 5.79914 15.8871 6.34311 15.3431C7.8434 13.8429 9.87823 13 12 13ZM12 13C14.7614 13 17 10.7614 17 8C17 5.23858 14.7614 3 12 3C9.23854 3 6.99996 5.23858 6.99996 8C6.99996 10.7614 9.23854 13 12 13Z" stroke-width="2"/>
</svg>);
export default UserIcon;
