import * as React from 'react';
export const Bag01Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M16 7C16 4.79086 14.2091 3 12 3C9.79086 3 8 4.79086 8 7M7 21H17C19.2091 21 21 19.2091 21 17V11C21 8.79086 19.2091 7 17 7H7C4.79086 7 3 8.79086 3 11V17C3 19.2091 4.79086 21 7 21Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Bag01Icon;
