import * as React from 'react';
export const Mobile01Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M9 17H15M9 21H15C17.2091 21 19 19.2091 19 17V7C19 4.79086 17.2091 3 15 3H9C6.79086 3 5 4.79086 5 7V17C5 19.2091 6.79086 21 9 21Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Mobile01Icon;
