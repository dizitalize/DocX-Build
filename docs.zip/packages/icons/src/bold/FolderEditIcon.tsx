import * as React from 'react';
export const FolderEditIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M9.79145 15.9912L11.674 14.1087C12.1087 13.674 12.1087 12.9692 11.674 12.5346L10.4654 11.326C10.0308 10.8913 9.32601 10.8913 8.89133 11.326L7.00879 13.2085M9.79145 15.9912L5.78266 20H3V17.2173L7.00879 13.2085M9.79145 15.9912L7.00879 13.2085M3 12V6C3 4.89543 3.89543 4 5 4H8.92963C9.59834 4 10.2228 4.3342 10.5937 4.8906L11.4063 6.1094C11.7772 6.6658 12.4017 7 13.0704 7H17C19.2091 7 21 8.79086 21 11V16C21 18.2091 19.2091 20 17 20H11" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default FolderEditIcon;
