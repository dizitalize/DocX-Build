import * as React from 'react';
export const Attachments01Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M6 6H16C19.3137 6 22 8.68629 22 12C22 15.3137 19.3137 18 16 18H6C3.79086 18 2 16.2091 2 14C2 13.6914 2.03494 13.391 2.10108 13.1025C2.50845 11.3255 4.09943 10 6 10L16 10C17.1046 10 18 10.8954 18 12C18 13.1046 17.1046 14 16 14H6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Attachments01Icon;
