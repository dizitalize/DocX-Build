import * as React from 'react';
export const TrendArrowDecrease02Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M3 3.5L8.52096 12H14.0419L19.5629 20.5M19.5629 20.5L21 14.1112M19.5629 20.5L13.3385 19.025" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default TrendArrowDecrease02Icon;
