import * as React from 'react';
export const Move05Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M15 9L21 3M21 3L21 7.24264M21 3L16.7573 3M9.00001 9L3.00001 3M3.00001 3L3.00004 7.24264M3.00001 3L7.24268 3M3 21L9 15M3 21L3.00001 16.7574M3 21H7.24265M21 21L15 15M21 21V16.7574M21 21L16.7574 21" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Move05Icon;
