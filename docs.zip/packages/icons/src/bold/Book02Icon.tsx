import * as React from 'react';
export const Book02Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M7 21H17C18.1046 21 19 20.1046 19 19V5C19 3.89543 18.1046 3 17 3H7C5.89543 3 5 3.89543 5 5V19M7 21C5.89543 21 5 20.1046 5 19M7 21H9M5 19C5 17.8954 5.89543 17 7 17H17C18.1046 17 19 16.1046 19 15V14M13 3V8L11 7L9 8V3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Book02Icon;
