import * as React from 'react';
export const PinLocationIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M18 9C18 15.3137 12 21 12 21C12 21 6 15.3137 6 9C6 5.68629 8.68629 3 12 3C15.3137 3 18 5.68629 18 9Z" stroke-width="2" stroke-linejoin="round"/>
<path d="M14 9C14 10.1046 13.1046 11 12 11C10.8954 11 10 10.1046 10 9C10 7.89543 10.8954 7 12 7C13.1046 7 14 7.89543 14 9Z" stroke-width="2" stroke-linejoin="round"/>
</svg>);
export default PinLocationIcon;
