import * as React from 'react';
export const AirplayIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M6 17C4.34315 17 3 15.6569 3 14V8C3 5.79086 4.79086 4 7 4H17C19.2091 4 21 5.79086 21 8V14C21 15.6569 19.6569 17 18 17M8 20L12 15L16 20H8Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default AirplayIcon;
