import * as React from 'react';
export const Layers01Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M20 13.441L21 13.941L12.8944 17.9938C12.3314 18.2753 11.6686 18.2753 11.1056 17.9938L3 13.941L4 13.441M3 9.941L10.6584 6.11182C11.5029 5.68953 12.4971 5.68953 13.3416 6.11182L21 9.941L13.3416 13.7702C12.4971 14.1925 11.5029 14.1925 10.6584 13.7702L3 9.941Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Layers01Icon;
