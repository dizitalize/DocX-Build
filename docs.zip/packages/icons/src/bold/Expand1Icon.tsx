import * as React from 'react';
export const Expand1Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M12.7071 16.9498L7.05026 16.9498L7.05026 11.2929M16.9498 12.7071V7.05026H11.2929" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Expand1Icon;
