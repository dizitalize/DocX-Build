import * as React from 'react';
export const MicOffIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M15 10V6C15 4.34315 13.6569 3 12 3C10.8896 3 9.92006 3.6033 9.40135 4.5M18 10V11C18 11.6056 17.9103 12.1903 17.7434 12.7414M6 10V11C6 14.3137 8.68629 17 12 17M12 17V21M12 17C13.4021 17 14.6918 16.5191 15.7133 15.7133M16 21H12M12 21H8M15.7133 15.7133L20 20M15.7133 15.7133L13.5619 13.5619M13.5619 13.5619C13.1069 13.8398 12.5722 14 12 14C10.3431 14 9 12.6569 9 11V9M13.5619 13.5619L9 9M4 4L9 9" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default MicOffIcon;
