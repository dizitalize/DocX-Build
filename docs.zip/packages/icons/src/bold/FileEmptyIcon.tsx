import * as React from 'react';
export const FileEmptyIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M19 9L13 3M19 9V17C19 19.2091 17.2091 21 15 21H9C6.79086 21 5 19.2091 5 17V7C5 4.79086 6.79086 3 9 3H13M19 9H15C13.8954 9 13 8.10457 13 7V3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default FileEmptyIcon;
