import * as React from 'react';
export const DownloadIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M8 5L5 5C3.89543 5 3 5.89543 3 7V17C3 18.1046 3.89543 19 5 19L19 19C20.1046 19 21 18.1046 21 17V7C21 5.89543 20.1046 5 19 5L16 5M12 15L12 4M12 15L8 11M12 15L16 11" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default DownloadIcon;
