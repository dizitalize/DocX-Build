import * as React from 'react';
export const PhotoCamera02Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M17 7H7M17 7C19.2091 7 21 8.79086 21 11V17C21 19.2091 19.2091 21 17 21H7C4.79086 21 3 19.2091 3 17V11C3 8.79086 4.79086 7 7 7M17 7V5C17 3.89543 16.1046 3 15 3H9C7.89543 3 7 3.89543 7 5V7M15.5 14C15.5 15.933 13.933 17.5 12 17.5C10.067 17.5 8.5 15.933 8.5 14C8.5 12.067 10.067 10.5 12 10.5C13.933 10.5 15.5 12.067 15.5 14Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default PhotoCamera02Icon;
