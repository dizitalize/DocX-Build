import * as React from 'react';
export const ListNumberIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M11 6H21M11 12H21M11 18H21M5 9V3L3 5M5 9H3M5 9H7M3 16C3 15.7153 3.06078 15.4339 3.17827 15.1746C3.29577 14.9153 3.46727 14.684 3.68131 14.4963C3.89535 14.3086 4.147 14.1688 4.41943 14.0861C4.69186 14.0035 4.9788 13.98 5.26105 14.0171C5.54331 14.0543 5.81438 14.1513 6.05614 14.3016C6.2979 14.4519 6.50477 14.6521 6.66294 14.8889C6.8211 15.1256 6.92691 15.3933 6.97329 15.6742C7.06369 16.2218 6.71035 16.7138 6.29491 17.0818L3 20H7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default ListNumberIcon;
