import * as React from 'react';
export const Edit02Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M9 20H4V15L14.5858 4.41422C15.3668 3.63317 16.6332 3.63317 17.4142 4.41422L19.5858 6.58579C20.3668 7.36684 20.3668 8.63317 19.5858 9.41422L9 20ZM9 20H21" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Edit02Icon;
