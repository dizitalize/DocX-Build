import * as React from 'react';
export const LabelTag02Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M16.4723 7.50626L20.4642 11.2778C21.1786 11.9528 21.1786 13.0472 20.4642 13.7222L16.4723 17.4937C16.1292 17.8179 15.6638 18 15.1786 18L4.82949 18C3.81909 18 3 17.2261 3 16.2715L3 8.72848C3 7.77387 3.81909 7 4.82948 7L15.1786 7C15.6638 7 16.1292 7.18211 16.4723 7.50626Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default LabelTag02Icon;
