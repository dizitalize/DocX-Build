import * as React from 'react';
export const Move01Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M3.00001 21L21 2.99998M3.00001 21L3.00002 16.7574M3.00001 21H7.24266M21 2.99998L21 7.24264M21 2.99998L16.7573 3M21 21L3 3M21 21L21 16.7574M21 21L16.7573 21M3 3L3 7.24264M3 3L7.24265 3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Move01Icon;
