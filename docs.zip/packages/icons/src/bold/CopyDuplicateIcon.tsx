import * as React from 'react';
export const CopyDuplicateIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M17 17V11C17 8.79086 15.2091 7 13 7H7M17 17C17 19.2091 15.2091 21 13 21H7C4.79086 21 3 19.2091 3 17V11C3 8.79086 4.79086 7 7 7M17 17C19.2091 17 21 15.2091 21 13V7C21 4.79086 19.2091 3 17 3H11C8.79086 3 7 4.79086 7 7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default CopyDuplicateIcon;
