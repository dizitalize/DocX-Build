import * as React from 'react';
export const ListAddIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M18 15V18M18 18V21M18 18H15M18 18H21M15 6H3M15 12H3M11 18H3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default ListAddIcon;
