import * as React from 'react';
export const MessageCloseIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M11.2322 13.7678L13 12M13 12L14.7678 10.2322M13 12L14.7678 13.7678M13 12L11.2322 10.2322M3 20H17C19.2091 20 21 18.2091 21 16V8C21 5.79086 19.2091 4 17 4H9.25C7.04086 4 5.25 5.79086 5.25 8V15.3761C5.25 16.156 5.02205 16.9188 4.59419 17.5708L3 20Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default MessageCloseIcon;
