import * as React from 'react';
export const PrintIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M7 19C4.79086 19 3 17.2091 3 15V11C3 8.79086 4.79086 7 7 7M7 19L7 17C7 15.8954 7.89543 15 9 15H15C16.1046 15 17 15.8954 17 17V19M7 19C7 20.1046 7.89543 21 9 21H15C16.1046 21 17 20.1046 17 19M17 19C19.2091 19 21 17.2091 21 15V11C21 8.79086 19.2091 7 17 7M17 7H7M17 7V5C17 3.89543 16.1046 3 15 3H9C7.89543 3 7 3.89543 7 5V7M9 11H15" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default PrintIcon;
