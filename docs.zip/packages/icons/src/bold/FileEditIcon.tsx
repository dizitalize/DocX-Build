import * as React from 'react';
export const FileEditIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M11.7914 16.9912L13.674 15.1087C14.1087 14.674 14.1087 13.9692 13.674 13.5346L12.4654 12.326C12.0308 11.8913 11.326 11.8913 10.8913 12.326L9.00879 14.2085M11.7914 16.9912L7.78266 21H5V18.2173L9.00879 14.2085M11.7914 16.9912L9.00879 14.2085M13 3H9C6.79086 3 5 4.79086 5 7V12M13 3L19 9M13 3V7C13 8.10457 13.8954 9 15 9H19M19 9V17C19 19.2091 17.2091 21 15 21H13" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default FileEditIcon;
