import * as React from 'react';
export const RadioExcludedOutlineIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke-width="2"/>
<path d="M9 9L12 12M12 12L15 15M12 12L9 15M12 12L15 9" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default RadioExcludedOutlineIcon;
