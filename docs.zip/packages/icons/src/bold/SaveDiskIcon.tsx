import * as React from 'react';
export const SaveDiskIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M17 21V15C17 13.8954 16.1046 13 15 13H9C7.89543 13 7 13.8954 7 15V21M9 8H15M18 21H6C4.34315 21 3 19.6569 3 18V6C3 4.34315 4.34315 3 6 3H16.5L21 7.5V18C21 19.6569 19.6569 21 18 21Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default SaveDiskIcon;
