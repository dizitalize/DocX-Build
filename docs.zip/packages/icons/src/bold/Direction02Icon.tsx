import * as React from 'react';
export const Direction02Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M3.00001 17L21 17M3.00001 17L7.00001 21M3.00001 17L7.00001 13M21 7L3 7M21 7L17 11M21 7L17 3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Direction02Icon;
