import * as React from 'react';
export const FolderEmptyIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M3 6C3 4.89543 3.89543 4 5 4H8.92963C9.59834 4 10.2228 4.3342 10.5937 4.8906L11.4063 6.1094C11.7772 6.6658 12.4017 7 13.0704 7H17C19.2091 7 21 8.79086 21 11V16C21 18.2091 19.2091 20 17 20H7C4.79086 20 3 18.2091 3 16V6Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default FolderEmptyIcon;
