import * as React from 'react';
export const Shrink2Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M18 8L14 12L18 16M6 8L10 12L6 16" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Shrink2Icon;
