import * as React from 'react';
export const SpeakerOffIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M16.7322 13.2678L18.5 11.5M18.5 11.5L20.2677 9.73224M18.5 11.5L20.2677 13.2678M18.5 11.5L16.7322 9.73224M6.80932 15.4367L10.5572 17.2875C11.2218 17.6157 12 17.1321 12 16.3909V7.60912C12 6.8679 11.2218 6.38429 10.5572 6.71249L6.80932 8.5633C6.67163 8.6313 6.52012 8.66667 6.36654 8.66667H4C3.44772 8.66667 3 9.11439 3 9.66667V14.3333C3 14.8856 3.44772 15.3333 4 15.3333H6.36654C6.52012 15.3333 6.67163 15.3687 6.80932 15.4367Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default SpeakerOffIcon;
