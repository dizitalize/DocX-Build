import * as React from 'react';
export const DesktopIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M10 7H5C3.89543 7 3 7.89543 3 9V15C3 16.1046 3.89543 17 5 17H10M3 21H10M17 17V7M15 21H19C20.1046 21 21 20.1046 21 19V5C21 3.89543 20.1046 3 19 3H15C13.8954 3 13 3.89543 13 5V19C13 20.1046 13.8954 21 15 21Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default DesktopIcon;
