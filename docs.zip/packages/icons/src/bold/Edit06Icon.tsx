import * as React from 'react';
export const Edit06Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M21 14V17C21 19.2091 19.2091 21 17 21H7C4.79086 21 3 19.2091 3 17V7C3 4.79086 4.79086 3 7 3H10M19 10L20.5858 8.41422C21.3668 7.63317 21.3668 6.36684 20.5858 5.58579L18.4142 3.41422C17.6332 2.63317 16.3668 2.63317 15.5858 3.41422L14 5M19 10L13 16H8V11L14 5M19 10L14 5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Edit06Icon;
