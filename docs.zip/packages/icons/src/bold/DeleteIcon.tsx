import * as React from 'react';
export const DeleteIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M12 14L14 12M14 12L16 10M14 12L16 14M14 12L12 10M3.53584 10.7778L7.52774 7.00626C7.87084 6.68211 8.33618 6.5 8.82139 6.5L19.1705 6.5C20.1809 6.5 21 7.27387 21 8.22848V15.7715C21 16.7261 20.1809 17.5 19.1705 17.5L8.82138 17.5C8.33617 17.5 7.87084 17.3179 7.52774 16.9937L3.53584 13.2222C2.82139 12.5472 2.82139 11.4528 3.53584 10.7778Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default DeleteIcon;
