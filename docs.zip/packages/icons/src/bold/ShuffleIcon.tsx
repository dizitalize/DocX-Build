import * as React from 'react';
export const ShuffleIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M21 16.3741L18 18.9985M21 16.3741L18 13.7496M21 16.3741L17.4223 16.3741C16.2073 16.3741 15.0581 15.8219 14.299 14.8732L9.70097 9.12682C8.94188 8.17815 7.79275 7.62592 6.57776 7.62592H3M21 7.62592L18 10.2504M21 7.62592L18 5.00146M21 7.62592H17.214C16.1195 7.62592 15.0727 8.07446 14.3178 8.867L14.25 8.93814M3.00001 16.3741H6.78597C7.88054 16.3741 8.92729 15.9255 9.68224 15.133L9.75001 15.0619" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default ShuffleIcon;
