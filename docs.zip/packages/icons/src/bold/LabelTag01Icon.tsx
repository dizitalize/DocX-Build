import * as React from 'react';
export const LabelTag01Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M12.7758 4H18C19.1046 4 20 4.89543 20 6V11.2242C20 11.7546 19.7893 12.2633 19.4142 12.6384L12.4668 19.5858C11.6858 20.3668 10.4195 20.3668 9.63842 19.5858L4.41422 14.3616C3.63317 13.5805 3.63317 12.3142 4.41422 11.5332L11.3616 4.58579C11.7367 4.21071 12.2454 4 12.7758 4Z" stroke-width="2" stroke-linejoin="round"/>
<path d="M14 8.5C14 9.32843 14.6716 10 15.5 10C16.3284 10 17 9.32843 17 8.5C17 7.67157 16.3284 7 15.5 7C14.6716 7 14 7.67157 14 8.5Z" stroke-width="2" stroke-linejoin="round"/>
</svg>);
export default LabelTag01Icon;
