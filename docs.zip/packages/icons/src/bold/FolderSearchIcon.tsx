import * as React from 'react';
export const FolderSearchIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M6.98584 16.0142C8.36166 17.39 10.5923 17.39 11.9681 16.0142C13.344 14.6383 13.344 12.4077 11.9681 11.0319C10.5923 9.65604 8.36166 9.65604 6.98584 11.0319C5.61001 12.4077 5.61001 14.6383 6.98584 16.0142ZM6.98584 16.0142L3 20M3 14V6C3 4.89543 3.89543 4 5 4H8.92963C9.59834 4 10.2228 4.3342 10.5937 4.8906L11.4063 6.1094C11.7772 6.6658 12.4017 7 13.0704 7H17C19.2091 7 21 8.79086 21 11V16C21 18.2091 19.2091 20 17 20H10" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default FolderSearchIcon;
