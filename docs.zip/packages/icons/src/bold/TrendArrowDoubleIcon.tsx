import * as React from 'react';
export const TrendArrowDoubleIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M3 20.5L8.52099 12H14.042L19.563 3.5M19.563 3.5L21 9.88876M19.563 3.5L13.3384 4.97496M3 3.5L5.76049 7.75M16.8025 16.25L19.563 20.5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default TrendArrowDoubleIcon;
