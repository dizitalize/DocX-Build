import * as React from 'react';
export const KeyboardIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M9 15H15M5 12H19M5 9H19M5 15H6M18 15H19M4 18H20C21.1046 18 22 17.1046 22 16V8C22 6.89543 21.1046 6 20 6H4C2.89543 6 2 6.89543 2 8V16C2 17.1046 2.89543 18 4 18Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default KeyboardIcon;
