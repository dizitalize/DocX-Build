import * as React from 'react';
export const PieChart01Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke-width="2"/>
<path d="M12 5C12 3.89543 12.9062 2.97785 13.9836 3.22131C15.2459 3.50655 16.4397 4.06248 17.4789 4.85982C18.518 5.65715 19.3639 6.66643 19.9662 7.81188C20.4802 8.78956 19.8284 9.90238 18.7615 10.1883L14.5176 11.3254C13.2474 11.6658 12 10.7086 12 9.39355V5Z" stroke-width="2"/>
</svg>);
export default PieChart01Icon;
