import * as React from 'react';
export const AttentionTriangleIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<circle cx="12" cy="18" r="1" fill="black"/>
<path d="M12 10V14M2 21L12 3L22 21H2Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default AttentionTriangleIcon;
