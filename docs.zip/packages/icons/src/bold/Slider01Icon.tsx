import * as React from 'react';
export const Slider01Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M13 16C13 17.1046 13.8954 18 15 18C16.1046 18 17 17.1046 17 16M13 16C13 14.8954 13.8954 14 15 14C16.1046 14 17 14.8954 17 16M13 16L3 16M17 16H21M11 8C11 9.10457 10.1046 10 9 10C7.89543 10 7 9.10457 7 8M11 8C11 6.89543 10.1046 6 9 6C7.89543 6 7 6.89543 7 8M11 8L21 8M7 8H3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Slider01Icon;
