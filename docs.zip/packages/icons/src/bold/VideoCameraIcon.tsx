import * as React from 'react';
export const VideoCameraIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M2 10C2 7.79086 3.79086 6 6 6H13C15.2091 6 17 7.79086 17 10V14C17 16.2091 15.2091 18 13 18H6C3.79086 18 2 16.2091 2 14V10Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M22 16L17 12L22 8V16Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default VideoCameraIcon;
