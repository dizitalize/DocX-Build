import * as React from 'react';
export const ToggleOffOulineIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M3 12C3 9.23858 5.23858 7 8 7H16C18.7614 7 21 9.23858 21 12C21 14.7614 18.7614 17 16 17H8C5.23858 17 3 14.7614 3 12Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<circle cx="8" cy="12" r="3" fill="black"/>
</svg>);
export default ToggleOffOulineIcon;
