import * as React from 'react';
export const SendIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M4.58867 13.1879C2.56119 12.5189 2.44466 9.69477 4.41012 8.86094L17.7759 3.19061C19.691 2.37814 21.6219 4.30899 20.8094 6.22409L15.1391 19.5899C14.3052 21.5553 11.4811 21.4388 10.8121 19.4113L9.26792 14.7321L4.58867 13.1879Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default SendIcon;
