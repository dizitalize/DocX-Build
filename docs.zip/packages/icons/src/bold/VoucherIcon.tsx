import * as React from 'react';
export const VoucherIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M15 6V18M2 16C2 17.1046 2.89543 18 4 18L20 18C21.1046 18 22 17.1046 22 16V15C20.3431 15 19 13.6569 19 12C19 10.3431 20.3431 9 22 9V8C22 6.89543 21.1046 6 20 6H4C2.89543 6 2 6.89543 2 8V9C3.65685 9 5 10.3431 5 12C5 13.6569 3.65685 15 2 15V16Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default VoucherIcon;
