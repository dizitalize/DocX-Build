import * as React from 'react';
export const HeartOutlineIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M10.4559 6.13857C8.75023 4.43294 5.98486 4.43294 4.27922 6.13857C2.57359 7.8442 2.57359 10.6096 4.27922 12.3152L10.4714 18.5074C11.3156 19.3516 12.6844 19.3516 13.5286 18.5074L19.7208 12.3152C21.4264 10.6096 21.4264 7.84423 19.7208 6.1386C18.0151 4.43297 15.2498 4.43297 13.5441 6.1386L12 7.68273L10.4559 6.13857Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default HeartOutlineIcon;
