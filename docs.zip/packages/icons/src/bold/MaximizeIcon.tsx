import * as React from 'react';
export const MaximizeIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M3.5 20.5L9.52574 14.4743M9.52574 14.4743C8.3624 13.3109 7.64286 11.7038 7.64286 9.92857C7.64286 6.37817 10.521 3.5 14.0714 3.5C17.6218 3.5 20.5 6.37817 20.5 9.92857C20.5 13.479 17.6218 16.3571 14.0714 16.3571C12.2962 16.3571 10.6891 15.6376 9.52574 14.4743ZM14 7.5V10M14 10V12.5M14 10H11.5M14 10H16.5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default MaximizeIcon;
