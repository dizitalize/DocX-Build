import * as React from 'react';
export const BellNotification03Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<circle cx="16.5" cy="8.5" r="2.5" fill="black"/>
<path d="M13.4319 5.20805C12.9783 5.0727 12.4976 5 12 5M12 5C9.23858 5 7 7.23858 7 10V15H6.5C5.67157 15 5 15.6716 5 16.5C5 17.3284 5.67157 18 6.5 18H17.5C18.3284 18 19 17.3284 19 16.5C19 15.6716 18.3284 15 17.5 15H17V12.9725M12 5V3M14 18V19C14 20.1046 13.1046 21 12 21C10.8954 21 10 20.1046 10 19V18" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default BellNotification03Icon;
