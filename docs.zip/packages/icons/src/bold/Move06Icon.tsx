import * as React from 'react';
export const Move06Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M15 9L21 3M15 9L15 4.75738M15 9L19.2426 9.00002M9 9L3 3M9 9V4.75739M9 9L4.75736 9.00003M3 21L9 15M9 15L9 19.2427M9 15L4.75736 15M21 21L15 15M15 15L15 19.2426M15 15H19.2426" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Move06Icon;
