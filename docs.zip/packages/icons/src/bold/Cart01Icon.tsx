import * as React from 'react';
export const Cart01Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M5 5H18.5068C19.7863 5 20.7367 6.18483 20.4591 7.43386L19.348 12.4339C19.1447 13.3489 18.3331 14 17.3957 14H8.60434C7.66695 14 6.85532 13.3489 6.65197 12.4339L5 5ZM5 5L4.55279 4.10557C4.214 3.428 3.52148 3 2.76393 3H2M11 19C11 20.1046 10.1046 21 9 21C7.89543 21 7 20.1046 7 19C7 17.8954 7.89543 17 9 17C10.1046 17 11 17.8954 11 19ZM19 19C19 20.1046 18.1046 21 17 21C15.8954 21 15 20.1046 15 19C15 17.8954 15.8954 17 17 17C18.1046 17 19 17.8954 19 19Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Cart01Icon;
