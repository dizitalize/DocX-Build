import * as React from 'react';
export const Layers02Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M20 11.441L21 11.941L12.8944 15.9938C12.3314 16.2753 11.6686 16.2753 11.1056 15.9938L3 11.941L4 11.441M20 15.441L21 15.941L12.8944 19.9938C12.3314 20.2753 11.6686 20.2753 11.1056 19.9938L3 15.941L4 15.441M3 7.941L10.6584 4.11182C11.5029 3.68953 12.4971 3.68953 13.3416 4.11182L21 7.941L13.3416 11.7702C12.4971 12.1925 11.5029 12.1925 10.6584 11.7702L3 7.941Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Layers02Icon;
