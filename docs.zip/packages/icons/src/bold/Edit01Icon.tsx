import * as React from 'react';
export const Edit01Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M9 20H4V15L13 6M9 20H21M9 20L18 11M18 11L19.5858 9.41422C20.3668 8.63317 20.3668 7.36684 19.5858 6.58579L17.4142 4.41422C16.6332 3.63317 15.3668 3.63317 14.5858 4.41422L13 6M18 11L13 6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Edit01Icon;
