import * as React from 'react';
export const Slider02Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M13 19C13 20.1046 13.8954 21 15 21C16.1046 21 17 20.1046 17 19M13 19C13 17.8954 13.8954 17 15 17C16.1046 17 17 17.8954 17 19M13 19H3M17 19H21M13 5C13 6.10457 13.8954 7 15 7C16.1046 7 17 6.10457 17 5M13 5C13 3.89543 13.8954 3 15 3C16.1046 3 17 3.89543 17 5M13 5L3 5M17 5H21M11 12C11 13.1046 10.1046 14 9 14C7.89543 14 7 13.1046 7 12M11 12C11 10.8954 10.1046 10 9 10C7.89543 10 7 10.8954 7 12M11 12L21 12M7 12H3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Slider02Icon;
