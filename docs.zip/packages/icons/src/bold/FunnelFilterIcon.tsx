import * as React from 'react';
export const FunnelFilterIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M3 4.89835C3 3.84992 3.84992 3 4.89835 3H19.1017C20.1501 3 21 3.84992 21 4.89835C21 5.57958 20.635 6.20859 20.0435 6.54657L15.0077 9.42416C14.3846 9.78024 14 10.4429 14 11.1606V19.382C14 19.7607 13.786 20.107 13.4472 20.2764L11.4472 21.2764C10.7823 21.6088 10 21.1253 10 20.382V11.1606C10 10.4429 9.61543 9.78024 8.99228 9.42416L3.9565 6.54657C3.36503 6.20859 3 5.57958 3 4.89835Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default FunnelFilterIcon;
