import * as React from 'react';
export const BarChart01Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M15 21V9C15 7.89543 15.8954 7 17 7H19C20.1046 7 21 7.89543 21 9V19C21 20.1046 20.1046 21 19 21H15ZM15 21H9M15 21V5C15 3.89543 14.1046 3 13 3H11C9.89543 3 9 3.89543 9 5V21M9 21H5C3.89543 21 3 20.1046 3 19V13C3 11.8954 3.89543 11 5 11H7C8.10457 11 9 11.8954 9 13V21Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default BarChart01Icon;
