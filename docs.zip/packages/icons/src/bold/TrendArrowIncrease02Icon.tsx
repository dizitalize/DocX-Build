import * as React from 'react';
export const TrendArrowIncrease02Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M3 20.5L8.52098 12H14.042L19.5629 3.5M19.5629 3.5L21 9.88878M19.5629 3.5L13.3385 4.97498" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default TrendArrowIncrease02Icon;
