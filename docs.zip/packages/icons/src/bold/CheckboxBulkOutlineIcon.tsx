import * as React from 'react';
export const CheckboxBulkOutlineIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M3 7C3 4.79086 4.79086 3 7 3H17C19.2091 3 21 4.79086 21 7V17C21 19.2091 19.2091 21 17 21H7C4.79086 21 3 19.2091 3 17V7Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M7.75732 12H16.2426" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default CheckboxBulkOutlineIcon;
