import * as React from 'react';
export const DevicesIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M10 17H7C4.79086 17 3 15.2091 3 13V7C3 4.79086 4.79086 3 7 3H17C19.2091 3 21 4.79086 21 7M3 21H10M16 21H19C20.1046 21 21 20.1046 21 19V12C21 10.8954 20.1046 10 19 10H16C14.8954 10 14 10.8954 14 12V19C14 20.1046 14.8954 21 16 21Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default DevicesIcon;
