/* AUTO-GENERATED FILE: icon registry */
/* Stroke icons with weight variants: regular, bold, solid */
import React from "react";
import { AddCircleIcon as AddCircleIcon_regular } from './regular/AddCircleIcon';
import { AddCircleIcon as AddCircleIcon_bold } from './bold/AddCircleIcon';
import { AddCircleIcon as AddCircleIcon_solid } from './solid/AddCircleIcon';
import { AddSquareIcon as AddSquareIcon_regular } from './regular/AddSquareIcon';
import { AddSquareIcon as AddSquareIcon_bold } from './bold/AddSquareIcon';
import { AddSquareIcon as AddSquareIcon_solid } from './solid/AddSquareIcon';
import { AddIcon as AddIcon_regular } from './regular/AddIcon';
import { AddIcon as AddIcon_bold } from './bold/AddIcon';
import { AddIcon as AddIcon_solid } from './solid/AddIcon';
import { AirplayIcon as AirplayIcon_regular } from './regular/AirplayIcon';
import { AirplayIcon as AirplayIcon_bold } from './bold/AirplayIcon';
import { AirplayIcon as AirplayIcon_solid } from './solid/AirplayIcon';
import { AlarmIcon as AlarmIcon_regular } from './regular/AlarmIcon';
import { AlarmIcon as AlarmIcon_bold } from './bold/AlarmIcon';
import { AlarmIcon as AlarmIcon_solid } from './solid/AlarmIcon';
import { AlignCenterIcon as AlignCenterIcon_regular } from './regular/AlignCenterIcon';
import { AlignCenterIcon as AlignCenterIcon_bold } from './bold/AlignCenterIcon';
import { AlignCenterIcon as AlignCenterIcon_solid } from './solid/AlignCenterIcon';
import { AlignJustifyIcon as AlignJustifyIcon_regular } from './regular/AlignJustifyIcon';
import { AlignJustifyIcon as AlignJustifyIcon_bold } from './bold/AlignJustifyIcon';
import { AlignJustifyIcon as AlignJustifyIcon_solid } from './solid/AlignJustifyIcon';
import { AlignLeftIcon as AlignLeftIcon_regular } from './regular/AlignLeftIcon';
import { AlignLeftIcon as AlignLeftIcon_bold } from './bold/AlignLeftIcon';
import { AlignLeftIcon as AlignLeftIcon_solid } from './solid/AlignLeftIcon';
import { AlignRightIcon as AlignRightIcon_regular } from './regular/AlignRightIcon';
import { AlignRightIcon as AlignRightIcon_bold } from './bold/AlignRightIcon';
import { AlignRightIcon as AlignRightIcon_solid } from './solid/AlignRightIcon';
import { AngleBottomLeftIcon as AngleBottomLeftIcon_regular } from './regular/AngleBottomLeftIcon';
import { AngleBottomLeftIcon as AngleBottomLeftIcon_bold } from './bold/AngleBottomLeftIcon';
import { AngleBottomLeftIcon as AngleBottomLeftIcon_solid } from './solid/AngleBottomLeftIcon';
import { AngleBottomRightIcon as AngleBottomRightIcon_regular } from './regular/AngleBottomRightIcon';
import { AngleBottomRightIcon as AngleBottomRightIcon_bold } from './bold/AngleBottomRightIcon';
import { AngleBottomRightIcon as AngleBottomRightIcon_solid } from './solid/AngleBottomRightIcon';
import { AngleTopLeftIcon as AngleTopLeftIcon_regular } from './regular/AngleTopLeftIcon';
import { AngleTopLeftIcon as AngleTopLeftIcon_bold } from './bold/AngleTopLeftIcon';
import { AngleTopLeftIcon as AngleTopLeftIcon_solid } from './solid/AngleTopLeftIcon';
import { AngleTopRightIcon as AngleTopRightIcon_regular } from './regular/AngleTopRightIcon';
import { AngleTopRightIcon as AngleTopRightIcon_bold } from './bold/AngleTopRightIcon';
import { AngleTopRightIcon as AngleTopRightIcon_solid } from './solid/AngleTopRightIcon';
import { ArrowBottomCircleIcon as ArrowBottomCircleIcon_regular } from './regular/ArrowBottomCircleIcon';
import { ArrowBottomCircleIcon as ArrowBottomCircleIcon_bold } from './bold/ArrowBottomCircleIcon';
import { ArrowBottomCircleIcon as ArrowBottomCircleIcon_solid } from './solid/ArrowBottomCircleIcon';
import { ArrowBottomLargeIcon as ArrowBottomLargeIcon_regular } from './regular/ArrowBottomLargeIcon';
import { ArrowBottomLargeIcon as ArrowBottomLargeIcon_bold } from './bold/ArrowBottomLargeIcon';
import { ArrowBottomLargeIcon as ArrowBottomLargeIcon_solid } from './solid/ArrowBottomLargeIcon';
import { ArrowBottomLeftCircleIcon as ArrowBottomLeftCircleIcon_regular } from './regular/ArrowBottomLeftCircleIcon';
import { ArrowBottomLeftCircleIcon as ArrowBottomLeftCircleIcon_bold } from './bold/ArrowBottomLeftCircleIcon';
import { ArrowBottomLeftCircleIcon as ArrowBottomLeftCircleIcon_solid } from './solid/ArrowBottomLeftCircleIcon';
import { ArrowBottomLeftLargeIcon as ArrowBottomLeftLargeIcon_regular } from './regular/ArrowBottomLeftLargeIcon';
import { ArrowBottomLeftLargeIcon as ArrowBottomLeftLargeIcon_bold } from './bold/ArrowBottomLeftLargeIcon';
import { ArrowBottomLeftLargeIcon as ArrowBottomLeftLargeIcon_solid } from './solid/ArrowBottomLeftLargeIcon';
import { ArrowBottomLeftNormalIcon as ArrowBottomLeftNormalIcon_regular } from './regular/ArrowBottomLeftNormalIcon';
import { ArrowBottomLeftNormalIcon as ArrowBottomLeftNormalIcon_bold } from './bold/ArrowBottomLeftNormalIcon';
import { ArrowBottomLeftNormalIcon as ArrowBottomLeftNormalIcon_solid } from './solid/ArrowBottomLeftNormalIcon';
import { ArrowBottomLeftSquareIcon as ArrowBottomLeftSquareIcon_regular } from './regular/ArrowBottomLeftSquareIcon';
import { ArrowBottomLeftSquareIcon as ArrowBottomLeftSquareIcon_bold } from './bold/ArrowBottomLeftSquareIcon';
import { ArrowBottomLeftSquareIcon as ArrowBottomLeftSquareIcon_solid } from './solid/ArrowBottomLeftSquareIcon';
import { ArrowBottomNormalIcon as ArrowBottomNormalIcon_regular } from './regular/ArrowBottomNormalIcon';
import { ArrowBottomNormalIcon as ArrowBottomNormalIcon_bold } from './bold/ArrowBottomNormalIcon';
import { ArrowBottomNormalIcon as ArrowBottomNormalIcon_solid } from './solid/ArrowBottomNormalIcon';
import { ArrowBottomRightCircleIcon as ArrowBottomRightCircleIcon_regular } from './regular/ArrowBottomRightCircleIcon';
import { ArrowBottomRightCircleIcon as ArrowBottomRightCircleIcon_bold } from './bold/ArrowBottomRightCircleIcon';
import { ArrowBottomRightCircleIcon as ArrowBottomRightCircleIcon_solid } from './solid/ArrowBottomRightCircleIcon';
import { ArrowBottomRightLargeIcon as ArrowBottomRightLargeIcon_regular } from './regular/ArrowBottomRightLargeIcon';
import { ArrowBottomRightLargeIcon as ArrowBottomRightLargeIcon_bold } from './bold/ArrowBottomRightLargeIcon';
import { ArrowBottomRightLargeIcon as ArrowBottomRightLargeIcon_solid } from './solid/ArrowBottomRightLargeIcon';
import { ArrowBottomRightNormalIcon as ArrowBottomRightNormalIcon_regular } from './regular/ArrowBottomRightNormalIcon';
import { ArrowBottomRightNormalIcon as ArrowBottomRightNormalIcon_bold } from './bold/ArrowBottomRightNormalIcon';
import { ArrowBottomRightNormalIcon as ArrowBottomRightNormalIcon_solid } from './solid/ArrowBottomRightNormalIcon';
import { ArrowBottomRightSquareIcon as ArrowBottomRightSquareIcon_regular } from './regular/ArrowBottomRightSquareIcon';
import { ArrowBottomRightSquareIcon as ArrowBottomRightSquareIcon_bold } from './bold/ArrowBottomRightSquareIcon';
import { ArrowBottomRightSquareIcon as ArrowBottomRightSquareIcon_solid } from './solid/ArrowBottomRightSquareIcon';
import { ArrowBottomSquareIcon as ArrowBottomSquareIcon_regular } from './regular/ArrowBottomSquareIcon';
import { ArrowBottomSquareIcon as ArrowBottomSquareIcon_bold } from './bold/ArrowBottomSquareIcon';
import { ArrowBottomSquareIcon as ArrowBottomSquareIcon_solid } from './solid/ArrowBottomSquareIcon';
import { ArrowLeftCircleIcon as ArrowLeftCircleIcon_regular } from './regular/ArrowLeftCircleIcon';
import { ArrowLeftCircleIcon as ArrowLeftCircleIcon_bold } from './bold/ArrowLeftCircleIcon';
import { ArrowLeftCircleIcon as ArrowLeftCircleIcon_solid } from './solid/ArrowLeftCircleIcon';
import { ArrowLeftLargeIcon as ArrowLeftLargeIcon_regular } from './regular/ArrowLeftLargeIcon';
import { ArrowLeftLargeIcon as ArrowLeftLargeIcon_bold } from './bold/ArrowLeftLargeIcon';
import { ArrowLeftLargeIcon as ArrowLeftLargeIcon_solid } from './solid/ArrowLeftLargeIcon';
import { ArrowLeftNormalIcon as ArrowLeftNormalIcon_regular } from './regular/ArrowLeftNormalIcon';
import { ArrowLeftNormalIcon as ArrowLeftNormalIcon_bold } from './bold/ArrowLeftNormalIcon';
import { ArrowLeftNormalIcon as ArrowLeftNormalIcon_solid } from './solid/ArrowLeftNormalIcon';
import { ArrowLeftSquareIcon as ArrowLeftSquareIcon_regular } from './regular/ArrowLeftSquareIcon';
import { ArrowLeftSquareIcon as ArrowLeftSquareIcon_bold } from './bold/ArrowLeftSquareIcon';
import { ArrowLeftSquareIcon as ArrowLeftSquareIcon_solid } from './solid/ArrowLeftSquareIcon';
import { ArrowRightCircleIcon as ArrowRightCircleIcon_regular } from './regular/ArrowRightCircleIcon';
import { ArrowRightCircleIcon as ArrowRightCircleIcon_bold } from './bold/ArrowRightCircleIcon';
import { ArrowRightCircleIcon as ArrowRightCircleIcon_solid } from './solid/ArrowRightCircleIcon';
import { ArrowRightLargeIcon as ArrowRightLargeIcon_regular } from './regular/ArrowRightLargeIcon';
import { ArrowRightLargeIcon as ArrowRightLargeIcon_bold } from './bold/ArrowRightLargeIcon';
import { ArrowRightLargeIcon as ArrowRightLargeIcon_solid } from './solid/ArrowRightLargeIcon';
import { ArrowRightNormalIcon as ArrowRightNormalIcon_regular } from './regular/ArrowRightNormalIcon';
import { ArrowRightNormalIcon as ArrowRightNormalIcon_bold } from './bold/ArrowRightNormalIcon';
import { ArrowRightNormalIcon as ArrowRightNormalIcon_solid } from './solid/ArrowRightNormalIcon';
import { ArrowRightSquareIcon as ArrowRightSquareIcon_regular } from './regular/ArrowRightSquareIcon';
import { ArrowRightSquareIcon as ArrowRightSquareIcon_bold } from './bold/ArrowRightSquareIcon';
import { ArrowRightSquareIcon as ArrowRightSquareIcon_solid } from './solid/ArrowRightSquareIcon';
import { ArrowTopCircleIcon as ArrowTopCircleIcon_regular } from './regular/ArrowTopCircleIcon';
import { ArrowTopCircleIcon as ArrowTopCircleIcon_bold } from './bold/ArrowTopCircleIcon';
import { ArrowTopCircleIcon as ArrowTopCircleIcon_solid } from './solid/ArrowTopCircleIcon';
import { ArrowTopLargeIcon as ArrowTopLargeIcon_regular } from './regular/ArrowTopLargeIcon';
import { ArrowTopLargeIcon as ArrowTopLargeIcon_bold } from './bold/ArrowTopLargeIcon';
import { ArrowTopLargeIcon as ArrowTopLargeIcon_solid } from './solid/ArrowTopLargeIcon';
import { ArrowTopLeftCircleIcon as ArrowTopLeftCircleIcon_regular } from './regular/ArrowTopLeftCircleIcon';
import { ArrowTopLeftCircleIcon as ArrowTopLeftCircleIcon_bold } from './bold/ArrowTopLeftCircleIcon';
import { ArrowTopLeftCircleIcon as ArrowTopLeftCircleIcon_solid } from './solid/ArrowTopLeftCircleIcon';
import { ArrowTopLeftLargeIcon as ArrowTopLeftLargeIcon_regular } from './regular/ArrowTopLeftLargeIcon';
import { ArrowTopLeftLargeIcon as ArrowTopLeftLargeIcon_bold } from './bold/ArrowTopLeftLargeIcon';
import { ArrowTopLeftLargeIcon as ArrowTopLeftLargeIcon_solid } from './solid/ArrowTopLeftLargeIcon';
import { ArrowTopLeftNormalIcon as ArrowTopLeftNormalIcon_regular } from './regular/ArrowTopLeftNormalIcon';
import { ArrowTopLeftNormalIcon as ArrowTopLeftNormalIcon_bold } from './bold/ArrowTopLeftNormalIcon';
import { ArrowTopLeftNormalIcon as ArrowTopLeftNormalIcon_solid } from './solid/ArrowTopLeftNormalIcon';
import { ArrowTopLeftSquareIcon as ArrowTopLeftSquareIcon_regular } from './regular/ArrowTopLeftSquareIcon';
import { ArrowTopLeftSquareIcon as ArrowTopLeftSquareIcon_bold } from './bold/ArrowTopLeftSquareIcon';
import { ArrowTopLeftSquareIcon as ArrowTopLeftSquareIcon_solid } from './solid/ArrowTopLeftSquareIcon';
import { ArrowTopNormalIcon as ArrowTopNormalIcon_regular } from './regular/ArrowTopNormalIcon';
import { ArrowTopNormalIcon as ArrowTopNormalIcon_bold } from './bold/ArrowTopNormalIcon';
import { ArrowTopNormalIcon as ArrowTopNormalIcon_solid } from './solid/ArrowTopNormalIcon';
import { ArrowTopRightCircleIcon as ArrowTopRightCircleIcon_regular } from './regular/ArrowTopRightCircleIcon';
import { ArrowTopRightCircleIcon as ArrowTopRightCircleIcon_bold } from './bold/ArrowTopRightCircleIcon';
import { ArrowTopRightCircleIcon as ArrowTopRightCircleIcon_solid } from './solid/ArrowTopRightCircleIcon';
import { ArrowTopRightLargeIcon as ArrowTopRightLargeIcon_regular } from './regular/ArrowTopRightLargeIcon';
import { ArrowTopRightLargeIcon as ArrowTopRightLargeIcon_bold } from './bold/ArrowTopRightLargeIcon';
import { ArrowTopRightLargeIcon as ArrowTopRightLargeIcon_solid } from './solid/ArrowTopRightLargeIcon';
import { ArrowTopRightNormalIcon as ArrowTopRightNormalIcon_regular } from './regular/ArrowTopRightNormalIcon';
import { ArrowTopRightNormalIcon as ArrowTopRightNormalIcon_bold } from './bold/ArrowTopRightNormalIcon';
import { ArrowTopRightNormalIcon as ArrowTopRightNormalIcon_solid } from './solid/ArrowTopRightNormalIcon';
import { ArrowTopRightSquareIcon as ArrowTopRightSquareIcon_regular } from './regular/ArrowTopRightSquareIcon';
import { ArrowTopRightSquareIcon as ArrowTopRightSquareIcon_bold } from './bold/ArrowTopRightSquareIcon';
import { ArrowTopRightSquareIcon as ArrowTopRightSquareIcon_solid } from './solid/ArrowTopRightSquareIcon';
import { ArrowTopSquareIcon as ArrowTopSquareIcon_regular } from './regular/ArrowTopSquareIcon';
import { ArrowTopSquareIcon as ArrowTopSquareIcon_bold } from './bold/ArrowTopSquareIcon';
import { ArrowTopSquareIcon as ArrowTopSquareIcon_solid } from './solid/ArrowTopSquareIcon';
import { AtSignIcon as AtSignIcon_regular } from './regular/AtSignIcon';
import { AtSignIcon as AtSignIcon_bold } from './bold/AtSignIcon';
import { AtSignIcon as AtSignIcon_solid } from './solid/AtSignIcon';
import { Attachments01Icon as Attachments01Icon_regular } from './regular/Attachments01Icon';
import { Attachments01Icon as Attachments01Icon_bold } from './bold/Attachments01Icon';
import { Attachments01Icon as Attachments01Icon_solid } from './solid/Attachments01Icon';
import { Attachments02Icon as Attachments02Icon_regular } from './regular/Attachments02Icon';
import { Attachments02Icon as Attachments02Icon_bold } from './bold/Attachments02Icon';
import { Attachments02Icon as Attachments02Icon_solid } from './solid/Attachments02Icon';
import { AttentionCircleIcon as AttentionCircleIcon_regular } from './regular/AttentionCircleIcon';
import { AttentionCircleIcon as AttentionCircleIcon_bold } from './bold/AttentionCircleIcon';
import { AttentionCircleIcon as AttentionCircleIcon_solid } from './solid/AttentionCircleIcon';
import { AttentionSecurityShieldIcon as AttentionSecurityShieldIcon_regular } from './regular/AttentionSecurityShieldIcon';
import { AttentionSecurityShieldIcon as AttentionSecurityShieldIcon_bold } from './bold/AttentionSecurityShieldIcon';
import { AttentionSecurityShieldIcon as AttentionSecurityShieldIcon_solid } from './solid/AttentionSecurityShieldIcon';
import { AttentionSquareIcon as AttentionSquareIcon_regular } from './regular/AttentionSquareIcon';
import { AttentionSquareIcon as AttentionSquareIcon_bold } from './bold/AttentionSquareIcon';
import { AttentionSquareIcon as AttentionSquareIcon_solid } from './solid/AttentionSquareIcon';
import { AttentionStopIcon as AttentionStopIcon_regular } from './regular/AttentionStopIcon';
import { AttentionStopIcon as AttentionStopIcon_bold } from './bold/AttentionStopIcon';
import { AttentionStopIcon as AttentionStopIcon_solid } from './solid/AttentionStopIcon';
import { AttentionTriangleIcon as AttentionTriangleIcon_regular } from './regular/AttentionTriangleIcon';
import { AttentionTriangleIcon as AttentionTriangleIcon_bold } from './bold/AttentionTriangleIcon';
import { AttentionTriangleIcon as AttentionTriangleIcon_solid } from './solid/AttentionTriangleIcon';
import { Bag01Icon as Bag01Icon_regular } from './regular/Bag01Icon';
import { Bag01Icon as Bag01Icon_bold } from './bold/Bag01Icon';
import { Bag01Icon as Bag01Icon_solid } from './solid/Bag01Icon';
import { Bag02Icon as Bag02Icon_regular } from './regular/Bag02Icon';
import { Bag02Icon as Bag02Icon_bold } from './bold/Bag02Icon';
import { Bag02Icon as Bag02Icon_solid } from './solid/Bag02Icon';
import { Bag03Icon as Bag03Icon_regular } from './regular/Bag03Icon';
import { Bag03Icon as Bag03Icon_bold } from './bold/Bag03Icon';
import { Bag03Icon as Bag03Icon_solid } from './solid/Bag03Icon';
import { BarChart01Icon as BarChart01Icon_regular } from './regular/BarChart01Icon';
import { BarChart01Icon as BarChart01Icon_bold } from './bold/BarChart01Icon';
import { BarChart01Icon as BarChart01Icon_solid } from './solid/BarChart01Icon';
import { BarChart02Icon as BarChart02Icon_regular } from './regular/BarChart02Icon';
import { BarChart02Icon as BarChart02Icon_bold } from './bold/BarChart02Icon';
import { BarChart02Icon as BarChart02Icon_solid } from './solid/BarChart02Icon';
import { BellNotification01Icon as BellNotification01Icon_regular } from './regular/BellNotification01Icon';
import { BellNotification01Icon as BellNotification01Icon_bold } from './bold/BellNotification01Icon';
import { BellNotification01Icon as BellNotification01Icon_solid } from './solid/BellNotification01Icon';
import { BellNotification03Icon as BellNotification03Icon_regular } from './regular/BellNotification03Icon';
import { BellNotification03Icon as BellNotification03Icon_bold } from './bold/BellNotification03Icon';
import { BellNotification03Icon as BellNotification03Icon_solid } from './solid/BellNotification03Icon';
import { BellNotificationOff01Icon as BellNotificationOff01Icon_regular } from './regular/BellNotificationOff01Icon';
import { BellNotificationOff01Icon as BellNotificationOff01Icon_bold } from './bold/BellNotificationOff01Icon';
import { BellNotificationOff01Icon as BellNotificationOff01Icon_solid } from './solid/BellNotificationOff01Icon';
import { BellNotificationOff02Icon as BellNotificationOff02Icon_regular } from './regular/BellNotificationOff02Icon';
import { BellNotificationOff02Icon as BellNotificationOff02Icon_bold } from './bold/BellNotificationOff02Icon';
import { BellNotificationOff02Icon as BellNotificationOff02Icon_solid } from './solid/BellNotificationOff02Icon';
import { BellNotificationOn01Icon as BellNotificationOn01Icon_regular } from './regular/BellNotificationOn01Icon';
import { BellNotificationOn01Icon as BellNotificationOn01Icon_bold } from './bold/BellNotificationOn01Icon';
import { BellNotificationOn01Icon as BellNotificationOn01Icon_solid } from './solid/BellNotificationOn01Icon';
import { BellNotificationOn02Icon as BellNotificationOn02Icon_regular } from './regular/BellNotificationOn02Icon';
import { BellNotificationOn02Icon as BellNotificationOn02Icon_bold } from './bold/BellNotificationOn02Icon';
import { BellNotificationOn02Icon as BellNotificationOn02Icon_solid } from './solid/BellNotificationOn02Icon';
import { Book01Icon as Book01Icon_regular } from './regular/Book01Icon';
import { Book01Icon as Book01Icon_bold } from './bold/Book01Icon';
import { Book01Icon as Book01Icon_solid } from './solid/Book01Icon';
import { Book02Icon as Book02Icon_regular } from './regular/Book02Icon';
import { Book02Icon as Book02Icon_bold } from './bold/Book02Icon';
import { Book02Icon as Book02Icon_solid } from './solid/Book02Icon';
import { Book03Icon as Book03Icon_regular } from './regular/Book03Icon';
import { Book03Icon as Book03Icon_bold } from './bold/Book03Icon';
import { Book03Icon as Book03Icon_solid } from './solid/Book03Icon';
import { BookmarkFilledIcon as BookmarkFilledIcon_regular } from './regular/BookmarkFilledIcon';
import { BookmarkFilledIcon as BookmarkFilledIcon_bold } from './bold/BookmarkFilledIcon';
import { BookmarkFilledIcon as BookmarkFilledIcon_solid } from './solid/BookmarkFilledIcon';
import { BookmarkOutlineIcon as BookmarkOutlineIcon_regular } from './regular/BookmarkOutlineIcon';
import { BookmarkOutlineIcon as BookmarkOutlineIcon_bold } from './bold/BookmarkOutlineIcon';
import { BookmarkOutlineIcon as BookmarkOutlineIcon_solid } from './solid/BookmarkOutlineIcon';
import { BookmarkTonedIcon as BookmarkTonedIcon_regular } from './regular/BookmarkTonedIcon';
import { BookmarkTonedIcon as BookmarkTonedIcon_bold } from './bold/BookmarkTonedIcon';
import { BookmarkTonedIcon as BookmarkTonedIcon_solid } from './solid/BookmarkTonedIcon';
import { CalendarAddIcon as CalendarAddIcon_regular } from './regular/CalendarAddIcon';
import { CalendarAddIcon as CalendarAddIcon_bold } from './bold/CalendarAddIcon';
import { CalendarAddIcon as CalendarAddIcon_solid } from './solid/CalendarAddIcon';
import { CalendarCheckIcon as CalendarCheckIcon_regular } from './regular/CalendarCheckIcon';
import { CalendarCheckIcon as CalendarCheckIcon_bold } from './bold/CalendarCheckIcon';
import { CalendarCheckIcon as CalendarCheckIcon_solid } from './solid/CalendarCheckIcon';
import { CalendarCloseIcon as CalendarCloseIcon_regular } from './regular/CalendarCloseIcon';
import { CalendarCloseIcon as CalendarCloseIcon_bold } from './bold/CalendarCloseIcon';
import { CalendarCloseIcon as CalendarCloseIcon_solid } from './solid/CalendarCloseIcon';
import { CalendarDayIcon as CalendarDayIcon_regular } from './regular/CalendarDayIcon';
import { CalendarDayIcon as CalendarDayIcon_bold } from './bold/CalendarDayIcon';
import { CalendarDayIcon as CalendarDayIcon_solid } from './solid/CalendarDayIcon';
import { CalendarEmptyIcon as CalendarEmptyIcon_regular } from './regular/CalendarEmptyIcon';
import { CalendarEmptyIcon as CalendarEmptyIcon_bold } from './bold/CalendarEmptyIcon';
import { CalendarEmptyIcon as CalendarEmptyIcon_solid } from './solid/CalendarEmptyIcon';
import { CalendarMonthIcon as CalendarMonthIcon_regular } from './regular/CalendarMonthIcon';
import { CalendarMonthIcon as CalendarMonthIcon_bold } from './bold/CalendarMonthIcon';
import { CalendarMonthIcon as CalendarMonthIcon_solid } from './solid/CalendarMonthIcon';
import { CalendarRemoveIcon as CalendarRemoveIcon_regular } from './regular/CalendarRemoveIcon';
import { CalendarRemoveIcon as CalendarRemoveIcon_bold } from './bold/CalendarRemoveIcon';
import { CalendarRemoveIcon as CalendarRemoveIcon_solid } from './solid/CalendarRemoveIcon';
import { CalendarWeekIcon as CalendarWeekIcon_regular } from './regular/CalendarWeekIcon';
import { CalendarWeekIcon as CalendarWeekIcon_bold } from './bold/CalendarWeekIcon';
import { CalendarWeekIcon as CalendarWeekIcon_solid } from './solid/CalendarWeekIcon';
import { CallPhoneIcon as CallPhoneIcon_regular } from './regular/CallPhoneIcon';
import { CallPhoneIcon as CallPhoneIcon_bold } from './bold/CallPhoneIcon';
import { CallPhoneIcon as CallPhoneIcon_solid } from './solid/CallPhoneIcon';
import { Cart01Icon as Cart01Icon_regular } from './regular/Cart01Icon';
import { Cart01Icon as Cart01Icon_bold } from './bold/Cart01Icon';
import { Cart01Icon as Cart01Icon_solid } from './solid/Cart01Icon';
import { Cart02Icon as Cart02Icon_regular } from './regular/Cart02Icon';
import { Cart02Icon as Cart02Icon_bold } from './bold/Cart02Icon';
import { Cart02Icon as Cart02Icon_solid } from './solid/Cart02Icon';
import { ChatConversationIcon as ChatConversationIcon_regular } from './regular/ChatConversationIcon';
import { ChatConversationIcon as ChatConversationIcon_bold } from './bold/ChatConversationIcon';
import { ChatConversationIcon as ChatConversationIcon_solid } from './solid/ChatConversationIcon';
import { CheckDoubleIcon as CheckDoubleIcon_regular } from './regular/CheckDoubleIcon';
import { CheckDoubleIcon as CheckDoubleIcon_bold } from './bold/CheckDoubleIcon';
import { CheckDoubleIcon as CheckDoubleIcon_solid } from './solid/CheckDoubleIcon';
import { CheckSingleIcon as CheckSingleIcon_regular } from './regular/CheckSingleIcon';
import { CheckSingleIcon as CheckSingleIcon_bold } from './bold/CheckSingleIcon';
import { CheckSingleIcon as CheckSingleIcon_solid } from './solid/CheckSingleIcon';
import { CheckboxAddFilledIcon as CheckboxAddFilledIcon_regular } from './regular/CheckboxAddFilledIcon';
import { CheckboxAddFilledIcon as CheckboxAddFilledIcon_bold } from './bold/CheckboxAddFilledIcon';
import { CheckboxAddFilledIcon as CheckboxAddFilledIcon_solid } from './solid/CheckboxAddFilledIcon';
import { CheckboxAddOutlineIcon as CheckboxAddOutlineIcon_regular } from './regular/CheckboxAddOutlineIcon';
import { CheckboxAddOutlineIcon as CheckboxAddOutlineIcon_bold } from './bold/CheckboxAddOutlineIcon';
import { CheckboxAddOutlineIcon as CheckboxAddOutlineIcon_solid } from './solid/CheckboxAddOutlineIcon';
import { CheckboxAddTonedIcon as CheckboxAddTonedIcon_regular } from './regular/CheckboxAddTonedIcon';
import { CheckboxAddTonedIcon as CheckboxAddTonedIcon_bold } from './bold/CheckboxAddTonedIcon';
import { CheckboxAddTonedIcon as CheckboxAddTonedIcon_solid } from './solid/CheckboxAddTonedIcon';
import { CheckboxBulkFilledIcon as CheckboxBulkFilledIcon_regular } from './regular/CheckboxBulkFilledIcon';
import { CheckboxBulkFilledIcon as CheckboxBulkFilledIcon_bold } from './bold/CheckboxBulkFilledIcon';
import { CheckboxBulkFilledIcon as CheckboxBulkFilledIcon_solid } from './solid/CheckboxBulkFilledIcon';
import { CheckboxBulkOutlineIcon as CheckboxBulkOutlineIcon_regular } from './regular/CheckboxBulkOutlineIcon';
import { CheckboxBulkOutlineIcon as CheckboxBulkOutlineIcon_bold } from './bold/CheckboxBulkOutlineIcon';
import { CheckboxBulkOutlineIcon as CheckboxBulkOutlineIcon_solid } from './solid/CheckboxBulkOutlineIcon';
import { CheckboxBulkTonedIcon as CheckboxBulkTonedIcon_regular } from './regular/CheckboxBulkTonedIcon';
import { CheckboxBulkTonedIcon as CheckboxBulkTonedIcon_bold } from './bold/CheckboxBulkTonedIcon';
import { CheckboxBulkTonedIcon as CheckboxBulkTonedIcon_solid } from './solid/CheckboxBulkTonedIcon';
import { CheckboxCheckedFilledIcon as CheckboxCheckedFilledIcon_regular } from './regular/CheckboxCheckedFilledIcon';
import { CheckboxCheckedFilledIcon as CheckboxCheckedFilledIcon_bold } from './bold/CheckboxCheckedFilledIcon';
import { CheckboxCheckedFilledIcon as CheckboxCheckedFilledIcon_solid } from './solid/CheckboxCheckedFilledIcon';
import { CheckboxCheckedOutlineIcon as CheckboxCheckedOutlineIcon_regular } from './regular/CheckboxCheckedOutlineIcon';
import { CheckboxCheckedOutlineIcon as CheckboxCheckedOutlineIcon_bold } from './bold/CheckboxCheckedOutlineIcon';
import { CheckboxCheckedOutlineIcon as CheckboxCheckedOutlineIcon_solid } from './solid/CheckboxCheckedOutlineIcon';
import { CheckboxCheckedTonedIcon as CheckboxCheckedTonedIcon_regular } from './regular/CheckboxCheckedTonedIcon';
import { CheckboxCheckedTonedIcon as CheckboxCheckedTonedIcon_bold } from './bold/CheckboxCheckedTonedIcon';
import { CheckboxCheckedTonedIcon as CheckboxCheckedTonedIcon_solid } from './solid/CheckboxCheckedTonedIcon';
import { CheckboxDotFilledIcon as CheckboxDotFilledIcon_regular } from './regular/CheckboxDotFilledIcon';
import { CheckboxDotFilledIcon as CheckboxDotFilledIcon_bold } from './bold/CheckboxDotFilledIcon';
import { CheckboxDotFilledIcon as CheckboxDotFilledIcon_solid } from './solid/CheckboxDotFilledIcon';
import { CheckboxDotOutlineIcon as CheckboxDotOutlineIcon_regular } from './regular/CheckboxDotOutlineIcon';
import { CheckboxDotOutlineIcon as CheckboxDotOutlineIcon_bold } from './bold/CheckboxDotOutlineIcon';
import { CheckboxDotOutlineIcon as CheckboxDotOutlineIcon_solid } from './solid/CheckboxDotOutlineIcon';
import { CheckboxDotTonedIcon as CheckboxDotTonedIcon_regular } from './regular/CheckboxDotTonedIcon';
import { CheckboxDotTonedIcon as CheckboxDotTonedIcon_bold } from './bold/CheckboxDotTonedIcon';
import { CheckboxDotTonedIcon as CheckboxDotTonedIcon_solid } from './solid/CheckboxDotTonedIcon';
import { CheckboxEmptyFilledIcon as CheckboxEmptyFilledIcon_regular } from './regular/CheckboxEmptyFilledIcon';
import { CheckboxEmptyFilledIcon as CheckboxEmptyFilledIcon_bold } from './bold/CheckboxEmptyFilledIcon';
import { CheckboxEmptyFilledIcon as CheckboxEmptyFilledIcon_solid } from './solid/CheckboxEmptyFilledIcon';
import { CheckboxEmptyOutlineIcon as CheckboxEmptyOutlineIcon_regular } from './regular/CheckboxEmptyOutlineIcon';
import { CheckboxEmptyOutlineIcon as CheckboxEmptyOutlineIcon_bold } from './bold/CheckboxEmptyOutlineIcon';
import { CheckboxEmptyOutlineIcon as CheckboxEmptyOutlineIcon_solid } from './solid/CheckboxEmptyOutlineIcon';
import { CheckboxEmptyTonedIcon as CheckboxEmptyTonedIcon_regular } from './regular/CheckboxEmptyTonedIcon';
import { CheckboxEmptyTonedIcon as CheckboxEmptyTonedIcon_bold } from './bold/CheckboxEmptyTonedIcon';
import { CheckboxEmptyTonedIcon as CheckboxEmptyTonedIcon_solid } from './solid/CheckboxEmptyTonedIcon';
import { CheckboxExcludedFilledIcon as CheckboxExcludedFilledIcon_regular } from './regular/CheckboxExcludedFilledIcon';
import { CheckboxExcludedFilledIcon as CheckboxExcludedFilledIcon_bold } from './bold/CheckboxExcludedFilledIcon';
import { CheckboxExcludedFilledIcon as CheckboxExcludedFilledIcon_solid } from './solid/CheckboxExcludedFilledIcon';
import { CheckboxExcludedOutlineIcon as CheckboxExcludedOutlineIcon_regular } from './regular/CheckboxExcludedOutlineIcon';
import { CheckboxExcludedOutlineIcon as CheckboxExcludedOutlineIcon_bold } from './bold/CheckboxExcludedOutlineIcon';
import { CheckboxExcludedOutlineIcon as CheckboxExcludedOutlineIcon_solid } from './solid/CheckboxExcludedOutlineIcon';
import { CheckboxExcludedTonedIcon as CheckboxExcludedTonedIcon_regular } from './regular/CheckboxExcludedTonedIcon';
import { CheckboxExcludedTonedIcon as CheckboxExcludedTonedIcon_bold } from './bold/CheckboxExcludedTonedIcon';
import { CheckboxExcludedTonedIcon as CheckboxExcludedTonedIcon_solid } from './solid/CheckboxExcludedTonedIcon';
import { ChevronBottomCircleIcon as ChevronBottomCircleIcon_regular } from './regular/ChevronBottomCircleIcon';
import { ChevronBottomCircleIcon as ChevronBottomCircleIcon_bold } from './bold/ChevronBottomCircleIcon';
import { ChevronBottomCircleIcon as ChevronBottomCircleIcon_solid } from './solid/ChevronBottomCircleIcon';
import { ChevronBottomDuoIcon as ChevronBottomDuoIcon_regular } from './regular/ChevronBottomDuoIcon';
import { ChevronBottomDuoIcon as ChevronBottomDuoIcon_bold } from './bold/ChevronBottomDuoIcon';
import { ChevronBottomDuoIcon as ChevronBottomDuoIcon_solid } from './solid/ChevronBottomDuoIcon';
import { ChevronBottomLeftCircleIcon as ChevronBottomLeftCircleIcon_regular } from './regular/ChevronBottomLeftCircleIcon';
import { ChevronBottomLeftCircleIcon as ChevronBottomLeftCircleIcon_bold } from './bold/ChevronBottomLeftCircleIcon';
import { ChevronBottomLeftCircleIcon as ChevronBottomLeftCircleIcon_solid } from './solid/ChevronBottomLeftCircleIcon';
import { ChevronBottomLeftDuoIcon as ChevronBottomLeftDuoIcon_regular } from './regular/ChevronBottomLeftDuoIcon';
import { ChevronBottomLeftDuoIcon as ChevronBottomLeftDuoIcon_bold } from './bold/ChevronBottomLeftDuoIcon';
import { ChevronBottomLeftDuoIcon as ChevronBottomLeftDuoIcon_solid } from './solid/ChevronBottomLeftDuoIcon';
import { ChevronBottomLeftNormalIcon as ChevronBottomLeftNormalIcon_regular } from './regular/ChevronBottomLeftNormalIcon';
import { ChevronBottomLeftNormalIcon as ChevronBottomLeftNormalIcon_bold } from './bold/ChevronBottomLeftNormalIcon';
import { ChevronBottomLeftNormalIcon as ChevronBottomLeftNormalIcon_solid } from './solid/ChevronBottomLeftNormalIcon';
import { ChevronBottomLeftSquareIcon as ChevronBottomLeftSquareIcon_regular } from './regular/ChevronBottomLeftSquareIcon';
import { ChevronBottomLeftSquareIcon as ChevronBottomLeftSquareIcon_bold } from './bold/ChevronBottomLeftSquareIcon';
import { ChevronBottomLeftSquareIcon as ChevronBottomLeftSquareIcon_solid } from './solid/ChevronBottomLeftSquareIcon';
import { ChevronBottomNormalIcon as ChevronBottomNormalIcon_regular } from './regular/ChevronBottomNormalIcon';
import { ChevronBottomNormalIcon as ChevronBottomNormalIcon_bold } from './bold/ChevronBottomNormalIcon';
import { ChevronBottomNormalIcon as ChevronBottomNormalIcon_solid } from './solid/ChevronBottomNormalIcon';
import { ChevronBottomRightCircleIcon as ChevronBottomRightCircleIcon_regular } from './regular/ChevronBottomRightCircleIcon';
import { ChevronBottomRightCircleIcon as ChevronBottomRightCircleIcon_bold } from './bold/ChevronBottomRightCircleIcon';
import { ChevronBottomRightCircleIcon as ChevronBottomRightCircleIcon_solid } from './solid/ChevronBottomRightCircleIcon';
import { ChevronBottomRightDuoIcon as ChevronBottomRightDuoIcon_regular } from './regular/ChevronBottomRightDuoIcon';
import { ChevronBottomRightDuoIcon as ChevronBottomRightDuoIcon_bold } from './bold/ChevronBottomRightDuoIcon';
import { ChevronBottomRightDuoIcon as ChevronBottomRightDuoIcon_solid } from './solid/ChevronBottomRightDuoIcon';
import { ChevronBottomRightNormalIcon as ChevronBottomRightNormalIcon_regular } from './regular/ChevronBottomRightNormalIcon';
import { ChevronBottomRightNormalIcon as ChevronBottomRightNormalIcon_bold } from './bold/ChevronBottomRightNormalIcon';
import { ChevronBottomRightNormalIcon as ChevronBottomRightNormalIcon_solid } from './solid/ChevronBottomRightNormalIcon';
import { ChevronBottomRightSquareIcon as ChevronBottomRightSquareIcon_regular } from './regular/ChevronBottomRightSquareIcon';
import { ChevronBottomRightSquareIcon as ChevronBottomRightSquareIcon_bold } from './bold/ChevronBottomRightSquareIcon';
import { ChevronBottomRightSquareIcon as ChevronBottomRightSquareIcon_solid } from './solid/ChevronBottomRightSquareIcon';
import { ChevronBottomSquareIcon as ChevronBottomSquareIcon_regular } from './regular/ChevronBottomSquareIcon';
import { ChevronBottomSquareIcon as ChevronBottomSquareIcon_bold } from './bold/ChevronBottomSquareIcon';
import { ChevronBottomSquareIcon as ChevronBottomSquareIcon_solid } from './solid/ChevronBottomSquareIcon';
import { ChevronLeftCircleIcon as ChevronLeftCircleIcon_regular } from './regular/ChevronLeftCircleIcon';
import { ChevronLeftCircleIcon as ChevronLeftCircleIcon_bold } from './bold/ChevronLeftCircleIcon';
import { ChevronLeftCircleIcon as ChevronLeftCircleIcon_solid } from './solid/ChevronLeftCircleIcon';
import { ChevronLeftDuoIcon as ChevronLeftDuoIcon_regular } from './regular/ChevronLeftDuoIcon';
import { ChevronLeftDuoIcon as ChevronLeftDuoIcon_bold } from './bold/ChevronLeftDuoIcon';
import { ChevronLeftDuoIcon as ChevronLeftDuoIcon_solid } from './solid/ChevronLeftDuoIcon';
import { ChevronLeftNormalIcon as ChevronLeftNormalIcon_regular } from './regular/ChevronLeftNormalIcon';
import { ChevronLeftNormalIcon as ChevronLeftNormalIcon_bold } from './bold/ChevronLeftNormalIcon';
import { ChevronLeftNormalIcon as ChevronLeftNormalIcon_solid } from './solid/ChevronLeftNormalIcon';
import { ChevronLeftSquareIcon as ChevronLeftSquareIcon_regular } from './regular/ChevronLeftSquareIcon';
import { ChevronLeftSquareIcon as ChevronLeftSquareIcon_bold } from './bold/ChevronLeftSquareIcon';
import { ChevronLeftSquareIcon as ChevronLeftSquareIcon_solid } from './solid/ChevronLeftSquareIcon';
import { ChevronRightCircleIcon as ChevronRightCircleIcon_regular } from './regular/ChevronRightCircleIcon';
import { ChevronRightCircleIcon as ChevronRightCircleIcon_bold } from './bold/ChevronRightCircleIcon';
import { ChevronRightCircleIcon as ChevronRightCircleIcon_solid } from './solid/ChevronRightCircleIcon';
import { ChevronRightDuoIcon as ChevronRightDuoIcon_regular } from './regular/ChevronRightDuoIcon';
import { ChevronRightDuoIcon as ChevronRightDuoIcon_bold } from './bold/ChevronRightDuoIcon';
import { ChevronRightDuoIcon as ChevronRightDuoIcon_solid } from './solid/ChevronRightDuoIcon';
import { ChevronRightNormalIcon as ChevronRightNormalIcon_regular } from './regular/ChevronRightNormalIcon';
import { ChevronRightNormalIcon as ChevronRightNormalIcon_bold } from './bold/ChevronRightNormalIcon';
import { ChevronRightNormalIcon as ChevronRightNormalIcon_solid } from './solid/ChevronRightNormalIcon';
import { ChevronRightSquareIcon as ChevronRightSquareIcon_regular } from './regular/ChevronRightSquareIcon';
import { ChevronRightSquareIcon as ChevronRightSquareIcon_bold } from './bold/ChevronRightSquareIcon';
import { ChevronRightSquareIcon as ChevronRightSquareIcon_solid } from './solid/ChevronRightSquareIcon';
import { ChevronTopCircleIcon as ChevronTopCircleIcon_regular } from './regular/ChevronTopCircleIcon';
import { ChevronTopCircleIcon as ChevronTopCircleIcon_bold } from './bold/ChevronTopCircleIcon';
import { ChevronTopCircleIcon as ChevronTopCircleIcon_solid } from './solid/ChevronTopCircleIcon';
import { ChevronTopDuoIcon as ChevronTopDuoIcon_regular } from './regular/ChevronTopDuoIcon';
import { ChevronTopDuoIcon as ChevronTopDuoIcon_bold } from './bold/ChevronTopDuoIcon';
import { ChevronTopDuoIcon as ChevronTopDuoIcon_solid } from './solid/ChevronTopDuoIcon';
import { ChevronTopLeftCircleIcon as ChevronTopLeftCircleIcon_regular } from './regular/ChevronTopLeftCircleIcon';
import { ChevronTopLeftCircleIcon as ChevronTopLeftCircleIcon_bold } from './bold/ChevronTopLeftCircleIcon';
import { ChevronTopLeftCircleIcon as ChevronTopLeftCircleIcon_solid } from './solid/ChevronTopLeftCircleIcon';
import { ChevronTopLeftDuoIcon as ChevronTopLeftDuoIcon_regular } from './regular/ChevronTopLeftDuoIcon';
import { ChevronTopLeftDuoIcon as ChevronTopLeftDuoIcon_bold } from './bold/ChevronTopLeftDuoIcon';
import { ChevronTopLeftDuoIcon as ChevronTopLeftDuoIcon_solid } from './solid/ChevronTopLeftDuoIcon';
import { ChevronTopLeftNormalIcon as ChevronTopLeftNormalIcon_regular } from './regular/ChevronTopLeftNormalIcon';
import { ChevronTopLeftNormalIcon as ChevronTopLeftNormalIcon_bold } from './bold/ChevronTopLeftNormalIcon';
import { ChevronTopLeftNormalIcon as ChevronTopLeftNormalIcon_solid } from './solid/ChevronTopLeftNormalIcon';
import { ChevronTopLeftSquareIcon as ChevronTopLeftSquareIcon_regular } from './regular/ChevronTopLeftSquareIcon';
import { ChevronTopLeftSquareIcon as ChevronTopLeftSquareIcon_bold } from './bold/ChevronTopLeftSquareIcon';
import { ChevronTopLeftSquareIcon as ChevronTopLeftSquareIcon_solid } from './solid/ChevronTopLeftSquareIcon';
import { ChevronTopNormalIcon as ChevronTopNormalIcon_regular } from './regular/ChevronTopNormalIcon';
import { ChevronTopNormalIcon as ChevronTopNormalIcon_bold } from './bold/ChevronTopNormalIcon';
import { ChevronTopNormalIcon as ChevronTopNormalIcon_solid } from './solid/ChevronTopNormalIcon';
import { ChevronTopRightCircleIcon as ChevronTopRightCircleIcon_regular } from './regular/ChevronTopRightCircleIcon';
import { ChevronTopRightCircleIcon as ChevronTopRightCircleIcon_bold } from './bold/ChevronTopRightCircleIcon';
import { ChevronTopRightCircleIcon as ChevronTopRightCircleIcon_solid } from './solid/ChevronTopRightCircleIcon';
import { ChevronTopRightDuoIcon as ChevronTopRightDuoIcon_regular } from './regular/ChevronTopRightDuoIcon';
import { ChevronTopRightDuoIcon as ChevronTopRightDuoIcon_bold } from './bold/ChevronTopRightDuoIcon';
import { ChevronTopRightDuoIcon as ChevronTopRightDuoIcon_solid } from './solid/ChevronTopRightDuoIcon';
import { ChevronTopRightNormalIcon as ChevronTopRightNormalIcon_regular } from './regular/ChevronTopRightNormalIcon';
import { ChevronTopRightNormalIcon as ChevronTopRightNormalIcon_bold } from './bold/ChevronTopRightNormalIcon';
import { ChevronTopRightNormalIcon as ChevronTopRightNormalIcon_solid } from './solid/ChevronTopRightNormalIcon';
import { ChevronTopRightSquareIcon as ChevronTopRightSquareIcon_regular } from './regular/ChevronTopRightSquareIcon';
import { ChevronTopRightSquareIcon as ChevronTopRightSquareIcon_bold } from './bold/ChevronTopRightSquareIcon';
import { ChevronTopRightSquareIcon as ChevronTopRightSquareIcon_solid } from './solid/ChevronTopRightSquareIcon';
import { ChevronTopSquareIcon as ChevronTopSquareIcon_regular } from './regular/ChevronTopSquareIcon';
import { ChevronTopSquareIcon as ChevronTopSquareIcon_bold } from './bold/ChevronTopSquareIcon';
import { ChevronTopSquareIcon as ChevronTopSquareIcon_solid } from './solid/ChevronTopSquareIcon';
import { ChromecastIcon as ChromecastIcon_regular } from './regular/ChromecastIcon';
import { ChromecastIcon as ChromecastIcon_bold } from './bold/ChromecastIcon';
import { ChromecastIcon as ChromecastIcon_solid } from './solid/ChromecastIcon';
import { ClockIcon as ClockIcon_regular } from './regular/ClockIcon';
import { ClockIcon as ClockIcon_bold } from './bold/ClockIcon';
import { ClockIcon as ClockIcon_solid } from './solid/ClockIcon';
import { CloseCircleIcon as CloseCircleIcon_regular } from './regular/CloseCircleIcon';
import { CloseCircleIcon as CloseCircleIcon_bold } from './bold/CloseCircleIcon';
import { CloseCircleIcon as CloseCircleIcon_solid } from './solid/CloseCircleIcon';
import { CloseSquareIcon as CloseSquareIcon_regular } from './regular/CloseSquareIcon';
import { CloseSquareIcon as CloseSquareIcon_bold } from './bold/CloseSquareIcon';
import { CloseSquareIcon as CloseSquareIcon_solid } from './solid/CloseSquareIcon';
import { CloseIcon as CloseIcon_regular } from './regular/CloseIcon';
import { CloseIcon as CloseIcon_bold } from './bold/CloseIcon';
import { CloseIcon as CloseIcon_solid } from './solid/CloseIcon';
import { CommandIcon as CommandIcon_regular } from './regular/CommandIcon';
import { CommandIcon as CommandIcon_bold } from './bold/CommandIcon';
import { CommandIcon as CommandIcon_solid } from './solid/CommandIcon';
import { CompassLocationIcon as CompassLocationIcon_regular } from './regular/CompassLocationIcon';
import { CompassLocationIcon as CompassLocationIcon_bold } from './bold/CompassLocationIcon';
import { CompassLocationIcon as CompassLocationIcon_solid } from './solid/CompassLocationIcon';
import { CopyAddIcon as CopyAddIcon_regular } from './regular/CopyAddIcon';
import { CopyAddIcon as CopyAddIcon_bold } from './bold/CopyAddIcon';
import { CopyAddIcon as CopyAddIcon_solid } from './solid/CopyAddIcon';
import { CopyCheckIcon as CopyCheckIcon_regular } from './regular/CopyCheckIcon';
import { CopyCheckIcon as CopyCheckIcon_bold } from './bold/CopyCheckIcon';
import { CopyCheckIcon as CopyCheckIcon_solid } from './solid/CopyCheckIcon';
import { CopyDuplicateIcon as CopyDuplicateIcon_regular } from './regular/CopyDuplicateIcon';
import { CopyDuplicateIcon as CopyDuplicateIcon_bold } from './bold/CopyDuplicateIcon';
import { CopyDuplicateIcon as CopyDuplicateIcon_solid } from './solid/CopyDuplicateIcon';
import { CopyRemoveIcon as CopyRemoveIcon_regular } from './regular/CopyRemoveIcon';
import { CopyRemoveIcon as CopyRemoveIcon_bold } from './bold/CopyRemoveIcon';
import { CopyRemoveIcon as CopyRemoveIcon_solid } from './solid/CopyRemoveIcon';
import { CreditCard01Icon as CreditCard01Icon_regular } from './regular/CreditCard01Icon';
import { CreditCard01Icon as CreditCard01Icon_bold } from './bold/CreditCard01Icon';
import { CreditCard01Icon as CreditCard01Icon_solid } from './solid/CreditCard01Icon';
import { CreditCard02Icon as CreditCard02Icon_regular } from './regular/CreditCard02Icon';
import { CreditCard02Icon as CreditCard02Icon_bold } from './bold/CreditCard02Icon';
import { CreditCard02Icon as CreditCard02Icon_solid } from './solid/CreditCard02Icon';
import { DeleteIcon as DeleteIcon_regular } from './regular/DeleteIcon';
import { DeleteIcon as DeleteIcon_bold } from './bold/DeleteIcon';
import { DeleteIcon as DeleteIcon_solid } from './solid/DeleteIcon';
import { DesktopIcon as DesktopIcon_regular } from './regular/DesktopIcon';
import { DesktopIcon as DesktopIcon_bold } from './bold/DesktopIcon';
import { DesktopIcon as DesktopIcon_solid } from './solid/DesktopIcon';
import { DevicesIcon as DevicesIcon_regular } from './regular/DevicesIcon';
import { DevicesIcon as DevicesIcon_bold } from './bold/DevicesIcon';
import { DevicesIcon as DevicesIcon_solid } from './solid/DevicesIcon';
import { Direction01Icon as Direction01Icon_regular } from './regular/Direction01Icon';
import { Direction01Icon as Direction01Icon_bold } from './bold/Direction01Icon';
import { Direction01Icon as Direction01Icon_solid } from './solid/Direction01Icon';
import { Direction02Icon as Direction02Icon_regular } from './regular/Direction02Icon';
import { Direction02Icon as Direction02Icon_bold } from './bold/Direction02Icon';
import { Direction02Icon as Direction02Icon_solid } from './solid/Direction02Icon';
import { DisplayIcon as DisplayIcon_regular } from './regular/DisplayIcon';
import { DisplayIcon as DisplayIcon_bold } from './bold/DisplayIcon';
import { DisplayIcon as DisplayIcon_solid } from './solid/DisplayIcon';
import { DownloadIcon as DownloadIcon_regular } from './regular/DownloadIcon';
import { DownloadIcon as DownloadIcon_bold } from './bold/DownloadIcon';
import { DownloadIcon as DownloadIcon_solid } from './solid/DownloadIcon';
import { DragVerticalIcon as DragVerticalIcon_regular } from './regular/DragVerticalIcon';
import { DragVerticalIcon as DragVerticalIcon_bold } from './bold/DragVerticalIcon';
import { DragVerticalIcon as DragVerticalIcon_solid } from './solid/DragVerticalIcon';
import { Edit01Icon as Edit01Icon_regular } from './regular/Edit01Icon';
import { Edit01Icon as Edit01Icon_bold } from './bold/Edit01Icon';
import { Edit01Icon as Edit01Icon_solid } from './solid/Edit01Icon';
import { Edit02Icon as Edit02Icon_regular } from './regular/Edit02Icon';
import { Edit02Icon as Edit02Icon_bold } from './bold/Edit02Icon';
import { Edit02Icon as Edit02Icon_solid } from './solid/Edit02Icon';
import { Edit03Icon as Edit03Icon_regular } from './regular/Edit03Icon';
import { Edit03Icon as Edit03Icon_bold } from './bold/Edit03Icon';
import { Edit03Icon as Edit03Icon_solid } from './solid/Edit03Icon';
import { Edit04Icon as Edit04Icon_regular } from './regular/Edit04Icon';
import { Edit04Icon as Edit04Icon_bold } from './bold/Edit04Icon';
import { Edit04Icon as Edit04Icon_solid } from './solid/Edit04Icon';
import { Edit05Icon as Edit05Icon_regular } from './regular/Edit05Icon';
import { Edit05Icon as Edit05Icon_bold } from './bold/Edit05Icon';
import { Edit05Icon as Edit05Icon_solid } from './solid/Edit05Icon';
import { Edit06Icon as Edit06Icon_regular } from './regular/Edit06Icon';
import { Edit06Icon as Edit06Icon_bold } from './bold/Edit06Icon';
import { Edit06Icon as Edit06Icon_solid } from './solid/Edit06Icon';
import { EqualCircleIcon as EqualCircleIcon_regular } from './regular/EqualCircleIcon';
import { EqualCircleIcon as EqualCircleIcon_bold } from './bold/EqualCircleIcon';
import { EqualCircleIcon as EqualCircleIcon_solid } from './solid/EqualCircleIcon';
import { EqualSquareIcon as EqualSquareIcon_regular } from './regular/EqualSquareIcon';
import { EqualSquareIcon as EqualSquareIcon_bold } from './bold/EqualSquareIcon';
import { EqualSquareIcon as EqualSquareIcon_solid } from './solid/EqualSquareIcon';
import { EqualIcon as EqualIcon_regular } from './regular/EqualIcon';
import { EqualIcon as EqualIcon_bold } from './bold/EqualIcon';
import { EqualIcon as EqualIcon_solid } from './solid/EqualIcon';
import { Expand1CircleIcon as Expand1CircleIcon_regular } from './regular/Expand1CircleIcon';
import { Expand1CircleIcon as Expand1CircleIcon_bold } from './bold/Expand1CircleIcon';
import { Expand1CircleIcon as Expand1CircleIcon_solid } from './solid/Expand1CircleIcon';
import { Expand1SquareIcon as Expand1SquareIcon_regular } from './regular/Expand1SquareIcon';
import { Expand1SquareIcon as Expand1SquareIcon_bold } from './bold/Expand1SquareIcon';
import { Expand1SquareIcon as Expand1SquareIcon_solid } from './solid/Expand1SquareIcon';
import { Expand1Icon as Expand1Icon_regular } from './regular/Expand1Icon';
import { Expand1Icon as Expand1Icon_bold } from './bold/Expand1Icon';
import { Expand1Icon as Expand1Icon_solid } from './solid/Expand1Icon';
import { Expand2CircleIcon as Expand2CircleIcon_regular } from './regular/Expand2CircleIcon';
import { Expand2CircleIcon as Expand2CircleIcon_bold } from './bold/Expand2CircleIcon';
import { Expand2CircleIcon as Expand2CircleIcon_solid } from './solid/Expand2CircleIcon';
import { Expand2SquareIcon as Expand2SquareIcon_regular } from './regular/Expand2SquareIcon';
import { Expand2SquareIcon as Expand2SquareIcon_bold } from './bold/Expand2SquareIcon';
import { Expand2SquareIcon as Expand2SquareIcon_solid } from './solid/Expand2SquareIcon';
import { Expand2Icon as Expand2Icon_regular } from './regular/Expand2Icon';
import { Expand2Icon as Expand2Icon_bold } from './bold/Expand2Icon';
import { Expand2Icon as Expand2Icon_solid } from './solid/Expand2Icon';
import { EyeOffIcon as EyeOffIcon_regular } from './regular/EyeOffIcon';
import { EyeOffIcon as EyeOffIcon_bold } from './bold/EyeOffIcon';
import { EyeOffIcon as EyeOffIcon_solid } from './solid/EyeOffIcon';
import { EyeIcon as EyeIcon_regular } from './regular/EyeIcon';
import { EyeIcon as EyeIcon_bold } from './bold/EyeIcon';
import { EyeIcon as EyeIcon_solid } from './solid/EyeIcon';
import { FileAddIcon as FileAddIcon_regular } from './regular/FileAddIcon';
import { FileAddIcon as FileAddIcon_bold } from './bold/FileAddIcon';
import { FileAddIcon as FileAddIcon_solid } from './solid/FileAddIcon';
import { FileCheckIcon as FileCheckIcon_regular } from './regular/FileCheckIcon';
import { FileCheckIcon as FileCheckIcon_bold } from './bold/FileCheckIcon';
import { FileCheckIcon as FileCheckIcon_solid } from './solid/FileCheckIcon';
import { FileCodeIcon as FileCodeIcon_regular } from './regular/FileCodeIcon';
import { FileCodeIcon as FileCodeIcon_bold } from './bold/FileCodeIcon';
import { FileCodeIcon as FileCodeIcon_solid } from './solid/FileCodeIcon';
import { FileDownloadIcon as FileDownloadIcon_regular } from './regular/FileDownloadIcon';
import { FileDownloadIcon as FileDownloadIcon_bold } from './bold/FileDownloadIcon';
import { FileDownloadIcon as FileDownloadIcon_solid } from './solid/FileDownloadIcon';
import { FileEditIcon as FileEditIcon_regular } from './regular/FileEditIcon';
import { FileEditIcon as FileEditIcon_bold } from './bold/FileEditIcon';
import { FileEditIcon as FileEditIcon_solid } from './solid/FileEditIcon';
import { FileEmptyIcon as FileEmptyIcon_regular } from './regular/FileEmptyIcon';
import { FileEmptyIcon as FileEmptyIcon_bold } from './bold/FileEmptyIcon';
import { FileEmptyIcon as FileEmptyIcon_solid } from './solid/FileEmptyIcon';
import { FileFilledIcon as FileFilledIcon_regular } from './regular/FileFilledIcon';
import { FileFilledIcon as FileFilledIcon_bold } from './bold/FileFilledIcon';
import { FileFilledIcon as FileFilledIcon_solid } from './solid/FileFilledIcon';
import { FileMinusIcon as FileMinusIcon_regular } from './regular/FileMinusIcon';
import { FileMinusIcon as FileMinusIcon_bold } from './bold/FileMinusIcon';
import { FileMinusIcon as FileMinusIcon_solid } from './solid/FileMinusIcon';
import { FileRemoveIcon as FileRemoveIcon_regular } from './regular/FileRemoveIcon';
import { FileRemoveIcon as FileRemoveIcon_bold } from './bold/FileRemoveIcon';
import { FileRemoveIcon as FileRemoveIcon_solid } from './solid/FileRemoveIcon';
import { FileSearchIcon as FileSearchIcon_regular } from './regular/FileSearchIcon';
import { FileSearchIcon as FileSearchIcon_bold } from './bold/FileSearchIcon';
import { FileSearchIcon as FileSearchIcon_solid } from './solid/FileSearchIcon';
import { FileUploadIcon as FileUploadIcon_regular } from './regular/FileUploadIcon';
import { FileUploadIcon as FileUploadIcon_bold } from './bold/FileUploadIcon';
import { FileUploadIcon as FileUploadIcon_solid } from './solid/FileUploadIcon';
import { FilesIcon as FilesIcon_regular } from './regular/FilesIcon';
import { FilesIcon as FilesIcon_bold } from './bold/FilesIcon';
import { FilesIcon as FilesIcon_solid } from './solid/FilesIcon';
import { FlagIcon as FlagIcon_regular } from './regular/FlagIcon';
import { FlagIcon as FlagIcon_bold } from './bold/FlagIcon';
import { FlagIcon as FlagIcon_solid } from './solid/FlagIcon';
import { FlashIcon as FlashIcon_regular } from './regular/FlashIcon';
import { FlashIcon as FlashIcon_bold } from './bold/FlashIcon';
import { FlashIcon as FlashIcon_solid } from './solid/FlashIcon';
import { FolderAddIcon as FolderAddIcon_regular } from './regular/FolderAddIcon';
import { FolderAddIcon as FolderAddIcon_bold } from './bold/FolderAddIcon';
import { FolderAddIcon as FolderAddIcon_solid } from './solid/FolderAddIcon';
import { FolderCheckIcon as FolderCheckIcon_regular } from './regular/FolderCheckIcon';
import { FolderCheckIcon as FolderCheckIcon_bold } from './bold/FolderCheckIcon';
import { FolderCheckIcon as FolderCheckIcon_solid } from './solid/FolderCheckIcon';
import { FolderCodeIcon as FolderCodeIcon_regular } from './regular/FolderCodeIcon';
import { FolderCodeIcon as FolderCodeIcon_bold } from './bold/FolderCodeIcon';
import { FolderCodeIcon as FolderCodeIcon_solid } from './solid/FolderCodeIcon';
import { FolderDownloadIcon as FolderDownloadIcon_regular } from './regular/FolderDownloadIcon';
import { FolderDownloadIcon as FolderDownloadIcon_bold } from './bold/FolderDownloadIcon';
import { FolderDownloadIcon as FolderDownloadIcon_solid } from './solid/FolderDownloadIcon';
import { FolderEditIcon as FolderEditIcon_regular } from './regular/FolderEditIcon';
import { FolderEditIcon as FolderEditIcon_bold } from './bold/FolderEditIcon';
import { FolderEditIcon as FolderEditIcon_solid } from './solid/FolderEditIcon';
import { FolderEmptyIcon as FolderEmptyIcon_regular } from './regular/FolderEmptyIcon';
import { FolderEmptyIcon as FolderEmptyIcon_bold } from './bold/FolderEmptyIcon';
import { FolderEmptyIcon as FolderEmptyIcon_solid } from './solid/FolderEmptyIcon';
import { FolderFilledIcon as FolderFilledIcon_regular } from './regular/FolderFilledIcon';
import { FolderFilledIcon as FolderFilledIcon_bold } from './bold/FolderFilledIcon';
import { FolderFilledIcon as FolderFilledIcon_solid } from './solid/FolderFilledIcon';
import { FolderMinusIcon as FolderMinusIcon_regular } from './regular/FolderMinusIcon';
import { FolderMinusIcon as FolderMinusIcon_bold } from './bold/FolderMinusIcon';
import { FolderMinusIcon as FolderMinusIcon_solid } from './solid/FolderMinusIcon';
import { FolderRemoveIcon as FolderRemoveIcon_regular } from './regular/FolderRemoveIcon';
import { FolderRemoveIcon as FolderRemoveIcon_bold } from './bold/FolderRemoveIcon';
import { FolderRemoveIcon as FolderRemoveIcon_solid } from './solid/FolderRemoveIcon';
import { FolderSearchIcon as FolderSearchIcon_regular } from './regular/FolderSearchIcon';
import { FolderSearchIcon as FolderSearchIcon_bold } from './bold/FolderSearchIcon';
import { FolderSearchIcon as FolderSearchIcon_solid } from './solid/FolderSearchIcon';
import { FolderUploadIcon as FolderUploadIcon_regular } from './regular/FolderUploadIcon';
import { FolderUploadIcon as FolderUploadIcon_bold } from './bold/FolderUploadIcon';
import { FolderUploadIcon as FolderUploadIcon_solid } from './solid/FolderUploadIcon';
import { FoldersIcon as FoldersIcon_regular } from './regular/FoldersIcon';
import { FoldersIcon as FoldersIcon_bold } from './bold/FoldersIcon';
import { FoldersIcon as FoldersIcon_solid } from './solid/FoldersIcon';
import { ForwardIcon as ForwardIcon_regular } from './regular/ForwardIcon';
import { ForwardIcon as ForwardIcon_bold } from './bold/ForwardIcon';
import { ForwardIcon as ForwardIcon_solid } from './solid/ForwardIcon';
import { Frame9stopIcon as Frame9stopIcon_regular } from './regular/Frame9stopIcon';
import { Frame9stopIcon as Frame9stopIcon_bold } from './bold/Frame9stopIcon';
import { Frame9stopIcon as Frame9stopIcon_solid } from './solid/Frame9stopIcon';
import { FunnelFilterIcon as FunnelFilterIcon_regular } from './regular/FunnelFilterIcon';
import { FunnelFilterIcon as FunnelFilterIcon_bold } from './bold/FunnelFilterIcon';
import { FunnelFilterIcon as FunnelFilterIcon_solid } from './solid/FunnelFilterIcon';
import { GlobeIcon as GlobeIcon_regular } from './regular/GlobeIcon';
import { GlobeIcon as GlobeIcon_bold } from './bold/GlobeIcon';
import { GlobeIcon as GlobeIcon_solid } from './solid/GlobeIcon';
import { Graph01Icon as Graph01Icon_regular } from './regular/Graph01Icon';
import { Graph01Icon as Graph01Icon_bold } from './bold/Graph01Icon';
import { Graph01Icon as Graph01Icon_solid } from './solid/Graph01Icon';
import { Graph02Icon as Graph02Icon_regular } from './regular/Graph02Icon';
import { Graph02Icon as Graph02Icon_bold } from './bold/Graph02Icon';
import { Graph02Icon as Graph02Icon_solid } from './solid/Graph02Icon';
import { GraphArrowDecrease01Icon as GraphArrowDecrease01Icon_regular } from './regular/GraphArrowDecrease01Icon';
import { GraphArrowDecrease01Icon as GraphArrowDecrease01Icon_bold } from './bold/GraphArrowDecrease01Icon';
import { GraphArrowDecrease01Icon as GraphArrowDecrease01Icon_solid } from './solid/GraphArrowDecrease01Icon';
import { GraphArrowDecrease02Icon as GraphArrowDecrease02Icon_regular } from './regular/GraphArrowDecrease02Icon';
import { GraphArrowDecrease02Icon as GraphArrowDecrease02Icon_bold } from './bold/GraphArrowDecrease02Icon';
import { GraphArrowDecrease02Icon as GraphArrowDecrease02Icon_solid } from './solid/GraphArrowDecrease02Icon';
import { GraphArrowDoubleIcon as GraphArrowDoubleIcon_regular } from './regular/GraphArrowDoubleIcon';
import { GraphArrowDoubleIcon as GraphArrowDoubleIcon_bold } from './bold/GraphArrowDoubleIcon';
import { GraphArrowDoubleIcon as GraphArrowDoubleIcon_solid } from './solid/GraphArrowDoubleIcon';
import { GraphArrowIncrease01Icon as GraphArrowIncrease01Icon_regular } from './regular/GraphArrowIncrease01Icon';
import { GraphArrowIncrease01Icon as GraphArrowIncrease01Icon_bold } from './bold/GraphArrowIncrease01Icon';
import { GraphArrowIncrease01Icon as GraphArrowIncrease01Icon_solid } from './solid/GraphArrowIncrease01Icon';
import { GraphArrowIncrease02Icon as GraphArrowIncrease02Icon_regular } from './regular/GraphArrowIncrease02Icon';
import { GraphArrowIncrease02Icon as GraphArrowIncrease02Icon_bold } from './bold/GraphArrowIncrease02Icon';
import { GraphArrowIncrease02Icon as GraphArrowIncrease02Icon_solid } from './solid/GraphArrowIncrease02Icon';
import { GraphDecreaseIcon as GraphDecreaseIcon_regular } from './regular/GraphDecreaseIcon';
import { GraphDecreaseIcon as GraphDecreaseIcon_bold } from './bold/GraphDecreaseIcon';
import { GraphDecreaseIcon as GraphDecreaseIcon_solid } from './solid/GraphDecreaseIcon';
import { GraphDoubleIcon as GraphDoubleIcon_regular } from './regular/GraphDoubleIcon';
import { GraphDoubleIcon as GraphDoubleIcon_bold } from './bold/GraphDoubleIcon';
import { GraphDoubleIcon as GraphDoubleIcon_solid } from './solid/GraphDoubleIcon';
import { GraphIncreaseIcon as GraphIncreaseIcon_regular } from './regular/GraphIncreaseIcon';
import { GraphIncreaseIcon as GraphIncreaseIcon_bold } from './bold/GraphIncreaseIcon';
import { GraphIncreaseIcon as GraphIncreaseIcon_solid } from './solid/GraphIncreaseIcon';
import { HeadphonesIcon as HeadphonesIcon_regular } from './regular/HeadphonesIcon';
import { HeadphonesIcon as HeadphonesIcon_bold } from './bold/HeadphonesIcon';
import { HeadphonesIcon as HeadphonesIcon_solid } from './solid/HeadphonesIcon';
import { HeartFilledIcon as HeartFilledIcon_regular } from './regular/HeartFilledIcon';
import { HeartFilledIcon as HeartFilledIcon_bold } from './bold/HeartFilledIcon';
import { HeartFilledIcon as HeartFilledIcon_solid } from './solid/HeartFilledIcon';
import { HeartOutlineIcon as HeartOutlineIcon_regular } from './regular/HeartOutlineIcon';
import { HeartOutlineIcon as HeartOutlineIcon_bold } from './bold/HeartOutlineIcon';
import { HeartOutlineIcon as HeartOutlineIcon_solid } from './solid/HeartOutlineIcon';
import { HeartTonedIcon as HeartTonedIcon_regular } from './regular/HeartTonedIcon';
import { HeartTonedIcon as HeartTonedIcon_bold } from './bold/HeartTonedIcon';
import { HeartTonedIcon as HeartTonedIcon_solid } from './solid/HeartTonedIcon';
import { HelpCircleIcon as HelpCircleIcon_regular } from './regular/HelpCircleIcon';
import { HelpCircleIcon as HelpCircleIcon_bold } from './bold/HelpCircleIcon';
import { HelpCircleIcon as HelpCircleIcon_solid } from './solid/HelpCircleIcon';
import { Home01Icon as Home01Icon_regular } from './regular/Home01Icon';
import { Home01Icon as Home01Icon_bold } from './bold/Home01Icon';
import { Home01Icon as Home01Icon_solid } from './solid/Home01Icon';
import { Home02Icon as Home02Icon_regular } from './regular/Home02Icon';
import { Home02Icon as Home02Icon_bold } from './bold/Home02Icon';
import { Home02Icon as Home02Icon_solid } from './solid/Home02Icon';
import { Home03Icon as Home03Icon_regular } from './regular/Home03Icon';
import { Home03Icon as Home03Icon_bold } from './bold/Home03Icon';
import { Home03Icon as Home03Icon_solid } from './solid/Home03Icon';
import { Home04Icon as Home04Icon_regular } from './regular/Home04Icon';
import { Home04Icon as Home04Icon_bold } from './bold/Home04Icon';
import { Home04Icon as Home04Icon_solid } from './solid/Home04Icon';
import { Home05Icon as Home05Icon_regular } from './regular/Home05Icon';
import { Home05Icon as Home05Icon_bold } from './bold/Home05Icon';
import { Home05Icon as Home05Icon_solid } from './solid/Home05Icon';
import { Home06Icon as Home06Icon_regular } from './regular/Home06Icon';
import { Home06Icon as Home06Icon_bold } from './bold/Home06Icon';
import { Home06Icon as Home06Icon_solid } from './solid/Home06Icon';
import { InformationCircleIcon as InformationCircleIcon_regular } from './regular/InformationCircleIcon';
import { InformationCircleIcon as InformationCircleIcon_bold } from './bold/InformationCircleIcon';
import { InformationCircleIcon as InformationCircleIcon_solid } from './solid/InformationCircleIcon';
import { InformationSquareIcon as InformationSquareIcon_regular } from './regular/InformationSquareIcon';
import { InformationSquareIcon as InformationSquareIcon_bold } from './bold/InformationSquareIcon';
import { InformationSquareIcon as InformationSquareIcon_solid } from './solid/InformationSquareIcon';
import { KeyboardIcon as KeyboardIcon_regular } from './regular/KeyboardIcon';
import { KeyboardIcon as KeyboardIcon_bold } from './bold/KeyboardIcon';
import { KeyboardIcon as KeyboardIcon_solid } from './solid/KeyboardIcon';
import { LabelTag01Icon as LabelTag01Icon_regular } from './regular/LabelTag01Icon';
import { LabelTag01Icon as LabelTag01Icon_bold } from './bold/LabelTag01Icon';
import { LabelTag01Icon as LabelTag01Icon_solid } from './solid/LabelTag01Icon';
import { LabelTag02Icon as LabelTag02Icon_regular } from './regular/LabelTag02Icon';
import { LabelTag02Icon as LabelTag02Icon_bold } from './bold/LabelTag02Icon';
import { LabelTag02Icon as LabelTag02Icon_solid } from './solid/LabelTag02Icon';
import { LaptopIcon as LaptopIcon_regular } from './regular/LaptopIcon';
import { LaptopIcon as LaptopIcon_bold } from './bold/LaptopIcon';
import { LaptopIcon as LaptopIcon_solid } from './solid/LaptopIcon';
import { Layers01Icon as Layers01Icon_regular } from './regular/Layers01Icon';
import { Layers01Icon as Layers01Icon_bold } from './bold/Layers01Icon';
import { Layers01Icon as Layers01Icon_solid } from './solid/Layers01Icon';
import { Layers02Icon as Layers02Icon_regular } from './regular/Layers02Icon';
import { Layers02Icon as Layers02Icon_bold } from './bold/Layers02Icon';
import { Layers02Icon as Layers02Icon_solid } from './solid/Layers02Icon';
import { Link01Icon as Link01Icon_regular } from './regular/Link01Icon';
import { Link01Icon as Link01Icon_bold } from './bold/Link01Icon';
import { Link01Icon as Link01Icon_solid } from './solid/Link01Icon';
import { Link02Icon as Link02Icon_regular } from './regular/Link02Icon';
import { Link02Icon as Link02Icon_bold } from './bold/Link02Icon';
import { Link02Icon as Link02Icon_solid } from './solid/Link02Icon';
import { ListAddIcon as ListAddIcon_regular } from './regular/ListAddIcon';
import { ListAddIcon as ListAddIcon_bold } from './bold/ListAddIcon';
import { ListAddIcon as ListAddIcon_solid } from './solid/ListAddIcon';
import { ListCheckIcon as ListCheckIcon_regular } from './regular/ListCheckIcon';
import { ListCheckIcon as ListCheckIcon_bold } from './bold/ListCheckIcon';
import { ListCheckIcon as ListCheckIcon_solid } from './solid/ListCheckIcon';
import { ListDotIcon as ListDotIcon_regular } from './regular/ListDotIcon';
import { ListDotIcon as ListDotIcon_bold } from './bold/ListDotIcon';
import { ListDotIcon as ListDotIcon_solid } from './solid/ListDotIcon';
import { ListNumberIcon as ListNumberIcon_regular } from './regular/ListNumberIcon';
import { ListNumberIcon as ListNumberIcon_bold } from './bold/ListNumberIcon';
import { ListNumberIcon as ListNumberIcon_solid } from './solid/ListNumberIcon';
import { LockIcon as LockIcon_regular } from './regular/LockIcon';
import { LockIcon as LockIcon_bold } from './bold/LockIcon';
import { LockIcon as LockIcon_solid } from './solid/LockIcon';
import { LogInIcon as LogInIcon_regular } from './regular/LogInIcon';
import { LogInIcon as LogInIcon_bold } from './bold/LogInIcon';
import { LogInIcon as LogInIcon_solid } from './solid/LogInIcon';
import { LogOutIcon as LogOutIcon_regular } from './regular/LogOutIcon';
import { LogOutIcon as LogOutIcon_bold } from './bold/LogOutIcon';
import { LogOutIcon as LogOutIcon_solid } from './solid/LogOutIcon';
import { MagnifierSearch01Icon as MagnifierSearch01Icon_regular } from './regular/MagnifierSearch01Icon';
import { MagnifierSearch01Icon as MagnifierSearch01Icon_bold } from './bold/MagnifierSearch01Icon';
import { MagnifierSearch01Icon as MagnifierSearch01Icon_solid } from './solid/MagnifierSearch01Icon';
import { MagnifierSearch02Icon as MagnifierSearch02Icon_regular } from './regular/MagnifierSearch02Icon';
import { MagnifierSearch02Icon as MagnifierSearch02Icon_bold } from './bold/MagnifierSearch02Icon';
import { MagnifierSearch02Icon as MagnifierSearch02Icon_solid } from './solid/MagnifierSearch02Icon';
import { MailOpenIcon as MailOpenIcon_regular } from './regular/MailOpenIcon';
import { MailOpenIcon as MailOpenIcon_bold } from './bold/MailOpenIcon';
import { MailOpenIcon as MailOpenIcon_solid } from './solid/MailOpenIcon';
import { MailIcon as MailIcon_regular } from './regular/MailIcon';
import { MailIcon as MailIcon_bold } from './bold/MailIcon';
import { MailIcon as MailIcon_solid } from './solid/MailIcon';
import { MaximizeIcon as MaximizeIcon_regular } from './regular/MaximizeIcon';
import { MaximizeIcon as MaximizeIcon_bold } from './bold/MaximizeIcon';
import { MaximizeIcon as MaximizeIcon_solid } from './solid/MaximizeIcon';
import { Menu01Icon as Menu01Icon_regular } from './regular/Menu01Icon';
import { Menu01Icon as Menu01Icon_bold } from './bold/Menu01Icon';
import { Menu01Icon as Menu01Icon_solid } from './solid/Menu01Icon';
import { Menu02Icon as Menu02Icon_regular } from './regular/Menu02Icon';
import { Menu02Icon as Menu02Icon_bold } from './bold/Menu02Icon';
import { Menu02Icon as Menu02Icon_solid } from './solid/Menu02Icon';
import { MenuAddIcon as MenuAddIcon_regular } from './regular/MenuAddIcon';
import { MenuAddIcon as MenuAddIcon_bold } from './bold/MenuAddIcon';
import { MenuAddIcon as MenuAddIcon_solid } from './solid/MenuAddIcon';
import { Message1Icon as Message1Icon_regular } from './regular/Message1Icon';
import { Message1Icon as Message1Icon_bold } from './bold/Message1Icon';
import { Message1Icon as Message1Icon_solid } from './solid/Message1Icon';
import { MessageAddIcon as MessageAddIcon_regular } from './regular/MessageAddIcon';
import { MessageAddIcon as MessageAddIcon_bold } from './bold/MessageAddIcon';
import { MessageAddIcon as MessageAddIcon_solid } from './solid/MessageAddIcon';
import { MessageCheckedIcon as MessageCheckedIcon_regular } from './regular/MessageCheckedIcon';
import { MessageCheckedIcon as MessageCheckedIcon_bold } from './bold/MessageCheckedIcon';
import { MessageCheckedIcon as MessageCheckedIcon_solid } from './solid/MessageCheckedIcon';
import { MessageCloseIcon as MessageCloseIcon_regular } from './regular/MessageCloseIcon';
import { MessageCloseIcon as MessageCloseIcon_bold } from './bold/MessageCloseIcon';
import { MessageCloseIcon as MessageCloseIcon_solid } from './solid/MessageCloseIcon';
import { MessageMoreIcon as MessageMoreIcon_regular } from './regular/MessageMoreIcon';
import { MessageMoreIcon as MessageMoreIcon_bold } from './bold/MessageMoreIcon';
import { MessageMoreIcon as MessageMoreIcon_solid } from './solid/MessageMoreIcon';
import { MessageRemoveIcon as MessageRemoveIcon_regular } from './regular/MessageRemoveIcon';
import { MessageRemoveIcon as MessageRemoveIcon_bold } from './bold/MessageRemoveIcon';
import { MessageRemoveIcon as MessageRemoveIcon_solid } from './solid/MessageRemoveIcon';
import { MicOffIcon as MicOffIcon_regular } from './regular/MicOffIcon';
import { MicOffIcon as MicOffIcon_bold } from './bold/MicOffIcon';
import { MicOffIcon as MicOffIcon_solid } from './solid/MicOffIcon';
import { MicOnIcon as MicOnIcon_regular } from './regular/MicOnIcon';
import { MicOnIcon as MicOnIcon_bold } from './bold/MicOnIcon';
import { MicOnIcon as MicOnIcon_solid } from './solid/MicOnIcon';
import { MinimizeIcon as MinimizeIcon_regular } from './regular/MinimizeIcon';
import { MinimizeIcon as MinimizeIcon_bold } from './bold/MinimizeIcon';
import { MinimizeIcon as MinimizeIcon_solid } from './solid/MinimizeIcon';
import { Mobile01Icon as Mobile01Icon_regular } from './regular/Mobile01Icon';
import { Mobile01Icon as Mobile01Icon_bold } from './bold/Mobile01Icon';
import { Mobile01Icon as Mobile01Icon_solid } from './solid/Mobile01Icon';
import { Mobile02Icon as Mobile02Icon_regular } from './regular/Mobile02Icon';
import { Mobile02Icon as Mobile02Icon_bold } from './bold/Mobile02Icon';
import { Mobile02Icon as Mobile02Icon_solid } from './solid/Mobile02Icon';
import { More01Icon as More01Icon_regular } from './regular/More01Icon';
import { More01Icon as More01Icon_bold } from './bold/More01Icon';
import { More01Icon as More01Icon_solid } from './solid/More01Icon';
import { More02Icon as More02Icon_regular } from './regular/More02Icon';
import { More02Icon as More02Icon_bold } from './bold/More02Icon';
import { More02Icon as More02Icon_solid } from './solid/More02Icon';
import { More3Icon as More3Icon_regular } from './regular/More3Icon';
import { More3Icon as More3Icon_bold } from './bold/More3Icon';
import { More3Icon as More3Icon_solid } from './solid/More3Icon';
import { MouseIcon as MouseIcon_regular } from './regular/MouseIcon';
import { MouseIcon as MouseIcon_bold } from './bold/MouseIcon';
import { MouseIcon as MouseIcon_solid } from './solid/MouseIcon';
import { Move01Icon as Move01Icon_regular } from './regular/Move01Icon';
import { Move01Icon as Move01Icon_bold } from './bold/Move01Icon';
import { Move01Icon as Move01Icon_solid } from './solid/Move01Icon';
import { Move02Icon as Move02Icon_regular } from './regular/Move02Icon';
import { Move02Icon as Move02Icon_bold } from './bold/Move02Icon';
import { Move02Icon as Move02Icon_solid } from './solid/Move02Icon';
import { Move03Icon as Move03Icon_regular } from './regular/Move03Icon';
import { Move03Icon as Move03Icon_bold } from './bold/Move03Icon';
import { Move03Icon as Move03Icon_solid } from './solid/Move03Icon';
import { Move04Icon as Move04Icon_regular } from './regular/Move04Icon';
import { Move04Icon as Move04Icon_bold } from './bold/Move04Icon';
import { Move04Icon as Move04Icon_solid } from './solid/Move04Icon';
import { Move05Icon as Move05Icon_regular } from './regular/Move05Icon';
import { Move05Icon as Move05Icon_bold } from './bold/Move05Icon';
import { Move05Icon as Move05Icon_solid } from './solid/Move05Icon';
import { Move06Icon as Move06Icon_regular } from './regular/Move06Icon';
import { Move06Icon as Move06Icon_bold } from './bold/Move06Icon';
import { Move06Icon as Move06Icon_solid } from './solid/Move06Icon';
import { NextIcon as NextIcon_regular } from './regular/NextIcon';
import { NextIcon as NextIcon_bold } from './bold/NextIcon';
import { NextIcon as NextIcon_solid } from './solid/NextIcon';
import { PauseIcon as PauseIcon_regular } from './regular/PauseIcon';
import { PauseIcon as PauseIcon_bold } from './bold/PauseIcon';
import { PauseIcon as PauseIcon_solid } from './solid/PauseIcon';
import { PhotoCamera01Icon as PhotoCamera01Icon_regular } from './regular/PhotoCamera01Icon';
import { PhotoCamera01Icon as PhotoCamera01Icon_bold } from './bold/PhotoCamera01Icon';
import { PhotoCamera01Icon as PhotoCamera01Icon_solid } from './solid/PhotoCamera01Icon';
import { PhotoCamera02Icon as PhotoCamera02Icon_regular } from './regular/PhotoCamera02Icon';
import { PhotoCamera02Icon as PhotoCamera02Icon_bold } from './bold/PhotoCamera02Icon';
import { PhotoCamera02Icon as PhotoCamera02Icon_solid } from './solid/PhotoCamera02Icon';
import { PieChart01Icon as PieChart01Icon_regular } from './regular/PieChart01Icon';
import { PieChart01Icon as PieChart01Icon_bold } from './bold/PieChart01Icon';
import { PieChart01Icon as PieChart01Icon_solid } from './solid/PieChart01Icon';
import { PieChart02Icon as PieChart02Icon_regular } from './regular/PieChart02Icon';
import { PieChart02Icon as PieChart02Icon_bold } from './bold/PieChart02Icon';
import { PieChart02Icon as PieChart02Icon_solid } from './solid/PieChart02Icon';
import { PieChart03Icon as PieChart03Icon_regular } from './regular/PieChart03Icon';
import { PieChart03Icon as PieChart03Icon_bold } from './bold/PieChart03Icon';
import { PieChart03Icon as PieChart03Icon_solid } from './solid/PieChart03Icon';
import { PieChart04Icon as PieChart04Icon_regular } from './regular/PieChart04Icon';
import { PieChart04Icon as PieChart04Icon_bold } from './bold/PieChart04Icon';
import { PieChart04Icon as PieChart04Icon_solid } from './solid/PieChart04Icon';
import { PinLocationIcon as PinLocationIcon_regular } from './regular/PinLocationIcon';
import { PinLocationIcon as PinLocationIcon_bold } from './bold/PinLocationIcon';
import { PinLocationIcon as PinLocationIcon_solid } from './solid/PinLocationIcon';
import { PlayIcon as PlayIcon_regular } from './regular/PlayIcon';
import { PlayIcon as PlayIcon_bold } from './bold/PlayIcon';
import { PlayIcon as PlayIcon_solid } from './solid/PlayIcon';
import { PreviousIcon as PreviousIcon_regular } from './regular/PreviousIcon';
import { PreviousIcon as PreviousIcon_bold } from './bold/PreviousIcon';
import { PreviousIcon as PreviousIcon_solid } from './solid/PreviousIcon';
import { PrintIcon as PrintIcon_regular } from './regular/PrintIcon';
import { PrintIcon as PrintIcon_bold } from './bold/PrintIcon';
import { PrintIcon as PrintIcon_solid } from './solid/PrintIcon';
import { QrIcon as QrIcon_regular } from './regular/QrIcon';
import { QrIcon as QrIcon_bold } from './bold/QrIcon';
import { QrIcon as QrIcon_solid } from './solid/QrIcon';
import { RadioCheckedFilledIcon as RadioCheckedFilledIcon_regular } from './regular/RadioCheckedFilledIcon';
import { RadioCheckedFilledIcon as RadioCheckedFilledIcon_bold } from './bold/RadioCheckedFilledIcon';
import { RadioCheckedFilledIcon as RadioCheckedFilledIcon_solid } from './solid/RadioCheckedFilledIcon';
import { RadioCheckedOutlineIcon as RadioCheckedOutlineIcon_regular } from './regular/RadioCheckedOutlineIcon';
import { RadioCheckedOutlineIcon as RadioCheckedOutlineIcon_bold } from './bold/RadioCheckedOutlineIcon';
import { RadioCheckedOutlineIcon as RadioCheckedOutlineIcon_solid } from './solid/RadioCheckedOutlineIcon';
import { RadioCheckedTonedIcon as RadioCheckedTonedIcon_regular } from './regular/RadioCheckedTonedIcon';
import { RadioCheckedTonedIcon as RadioCheckedTonedIcon_bold } from './bold/RadioCheckedTonedIcon';
import { RadioCheckedTonedIcon as RadioCheckedTonedIcon_solid } from './solid/RadioCheckedTonedIcon';
import { RadioDotFilledIcon as RadioDotFilledIcon_regular } from './regular/RadioDotFilledIcon';
import { RadioDotFilledIcon as RadioDotFilledIcon_bold } from './bold/RadioDotFilledIcon';
import { RadioDotFilledIcon as RadioDotFilledIcon_solid } from './solid/RadioDotFilledIcon';
import { RadioDotOutlineIcon as RadioDotOutlineIcon_regular } from './regular/RadioDotOutlineIcon';
import { RadioDotOutlineIcon as RadioDotOutlineIcon_bold } from './bold/RadioDotOutlineIcon';
import { RadioDotOutlineIcon as RadioDotOutlineIcon_solid } from './solid/RadioDotOutlineIcon';
import { RadioDotTonedIcon as RadioDotTonedIcon_regular } from './regular/RadioDotTonedIcon';
import { RadioDotTonedIcon as RadioDotTonedIcon_bold } from './bold/RadioDotTonedIcon';
import { RadioDotTonedIcon as RadioDotTonedIcon_solid } from './solid/RadioDotTonedIcon';
import { RadioEmptyFilledIcon as RadioEmptyFilledIcon_regular } from './regular/RadioEmptyFilledIcon';
import { RadioEmptyFilledIcon as RadioEmptyFilledIcon_bold } from './bold/RadioEmptyFilledIcon';
import { RadioEmptyFilledIcon as RadioEmptyFilledIcon_solid } from './solid/RadioEmptyFilledIcon';
import { RadioEmptyOutlineIcon as RadioEmptyOutlineIcon_regular } from './regular/RadioEmptyOutlineIcon';
import { RadioEmptyOutlineIcon as RadioEmptyOutlineIcon_bold } from './bold/RadioEmptyOutlineIcon';
import { RadioEmptyOutlineIcon as RadioEmptyOutlineIcon_solid } from './solid/RadioEmptyOutlineIcon';
import { RadioEmptyTonedIcon as RadioEmptyTonedIcon_regular } from './regular/RadioEmptyTonedIcon';
import { RadioEmptyTonedIcon as RadioEmptyTonedIcon_bold } from './bold/RadioEmptyTonedIcon';
import { RadioEmptyTonedIcon as RadioEmptyTonedIcon_solid } from './solid/RadioEmptyTonedIcon';
import { RadioExcludedFilledIcon as RadioExcludedFilledIcon_regular } from './regular/RadioExcludedFilledIcon';
import { RadioExcludedFilledIcon as RadioExcludedFilledIcon_bold } from './bold/RadioExcludedFilledIcon';
import { RadioExcludedFilledIcon as RadioExcludedFilledIcon_solid } from './solid/RadioExcludedFilledIcon';
import { RadioExcludedOutlineIcon as RadioExcludedOutlineIcon_regular } from './regular/RadioExcludedOutlineIcon';
import { RadioExcludedOutlineIcon as RadioExcludedOutlineIcon_bold } from './bold/RadioExcludedOutlineIcon';
import { RadioExcludedOutlineIcon as RadioExcludedOutlineIcon_solid } from './solid/RadioExcludedOutlineIcon';
import { RadioExcludedTonedIcon as RadioExcludedTonedIcon_regular } from './regular/RadioExcludedTonedIcon';
import { RadioExcludedTonedIcon as RadioExcludedTonedIcon_bold } from './bold/RadioExcludedTonedIcon';
import { RadioExcludedTonedIcon as RadioExcludedTonedIcon_solid } from './solid/RadioExcludedTonedIcon';
import { RedoIcon as RedoIcon_regular } from './regular/RedoIcon';
import { RedoIcon as RedoIcon_bold } from './bold/RedoIcon';
import { RedoIcon as RedoIcon_solid } from './solid/RedoIcon';
import { Reload01Icon as Reload01Icon_regular } from './regular/Reload01Icon';
import { Reload01Icon as Reload01Icon_bold } from './bold/Reload01Icon';
import { Reload01Icon as Reload01Icon_solid } from './solid/Reload01Icon';
import { Reload02Icon as Reload02Icon_regular } from './regular/Reload02Icon';
import { Reload02Icon as Reload02Icon_bold } from './bold/Reload02Icon';
import { Reload02Icon as Reload02Icon_solid } from './solid/Reload02Icon';
import { RemoveCircleIcon as RemoveCircleIcon_regular } from './regular/RemoveCircleIcon';
import { RemoveCircleIcon as RemoveCircleIcon_bold } from './bold/RemoveCircleIcon';
import { RemoveCircleIcon as RemoveCircleIcon_solid } from './solid/RemoveCircleIcon';
import { RemoveSquareIcon as RemoveSquareIcon_regular } from './regular/RemoveSquareIcon';
import { RemoveSquareIcon as RemoveSquareIcon_bold } from './bold/RemoveSquareIcon';
import { RemoveSquareIcon as RemoveSquareIcon_solid } from './solid/RemoveSquareIcon';
import { RemoveIcon as RemoveIcon_regular } from './regular/RemoveIcon';
import { RemoveIcon as RemoveIcon_bold } from './bold/RemoveIcon';
import { RemoveIcon as RemoveIcon_solid } from './solid/RemoveIcon';
import { RepeatIcon as RepeatIcon_regular } from './regular/RepeatIcon';
import { RepeatIcon as RepeatIcon_bold } from './bold/RepeatIcon';
import { RepeatIcon as RepeatIcon_solid } from './solid/RepeatIcon';
import { RewindIcon as RewindIcon_regular } from './regular/RewindIcon';
import { RewindIcon as RewindIcon_bold } from './bold/RewindIcon';
import { RewindIcon as RewindIcon_solid } from './solid/RewindIcon';
import { SaveDiskIcon as SaveDiskIcon_regular } from './regular/SaveDiskIcon';
import { SaveDiskIcon as SaveDiskIcon_bold } from './bold/SaveDiskIcon';
import { SaveDiskIcon as SaveDiskIcon_solid } from './solid/SaveDiskIcon';
import { SecurityShieldIcon as SecurityShieldIcon_regular } from './regular/SecurityShieldIcon';
import { SecurityShieldIcon as SecurityShieldIcon_bold } from './bold/SecurityShieldIcon';
import { SecurityShieldIcon as SecurityShieldIcon_solid } from './solid/SecurityShieldIcon';
import { SendIcon as SendIcon_regular } from './regular/SendIcon';
import { SendIcon as SendIcon_bold } from './bold/SendIcon';
import { SendIcon as SendIcon_solid } from './solid/SendIcon';
import { Settings01Icon as Settings01Icon_regular } from './regular/Settings01Icon';
import { Settings01Icon as Settings01Icon_bold } from './bold/Settings01Icon';
import { Settings01Icon as Settings01Icon_solid } from './solid/Settings01Icon';
import { Settings02Icon as Settings02Icon_regular } from './regular/Settings02Icon';
import { Settings02Icon as Settings02Icon_bold } from './bold/Settings02Icon';
import { Settings02Icon as Settings02Icon_solid } from './solid/Settings02Icon';
import { Settings03Icon as Settings03Icon_regular } from './regular/Settings03Icon';
import { Settings03Icon as Settings03Icon_bold } from './bold/Settings03Icon';
import { Settings03Icon as Settings03Icon_solid } from './solid/Settings03Icon';
import { Shrink1CircleIcon as Shrink1CircleIcon_regular } from './regular/Shrink1CircleIcon';
import { Shrink1CircleIcon as Shrink1CircleIcon_bold } from './bold/Shrink1CircleIcon';
import { Shrink1CircleIcon as Shrink1CircleIcon_solid } from './solid/Shrink1CircleIcon';
import { Shrink1SquareIcon as Shrink1SquareIcon_regular } from './regular/Shrink1SquareIcon';
import { Shrink1SquareIcon as Shrink1SquareIcon_bold } from './bold/Shrink1SquareIcon';
import { Shrink1SquareIcon as Shrink1SquareIcon_solid } from './solid/Shrink1SquareIcon';
import { Shrink1Icon as Shrink1Icon_regular } from './regular/Shrink1Icon';
import { Shrink1Icon as Shrink1Icon_bold } from './bold/Shrink1Icon';
import { Shrink1Icon as Shrink1Icon_solid } from './solid/Shrink1Icon';
import { Shrink2CircleIcon as Shrink2CircleIcon_regular } from './regular/Shrink2CircleIcon';
import { Shrink2CircleIcon as Shrink2CircleIcon_bold } from './bold/Shrink2CircleIcon';
import { Shrink2CircleIcon as Shrink2CircleIcon_solid } from './solid/Shrink2CircleIcon';
import { Shrink2SquareIcon as Shrink2SquareIcon_regular } from './regular/Shrink2SquareIcon';
import { Shrink2SquareIcon as Shrink2SquareIcon_bold } from './bold/Shrink2SquareIcon';
import { Shrink2SquareIcon as Shrink2SquareIcon_solid } from './solid/Shrink2SquareIcon';
import { Shrink2Icon as Shrink2Icon_regular } from './regular/Shrink2Icon';
import { Shrink2Icon as Shrink2Icon_bold } from './bold/Shrink2Icon';
import { Shrink2Icon as Shrink2Icon_solid } from './solid/Shrink2Icon';
import { ShuffleIcon as ShuffleIcon_regular } from './regular/ShuffleIcon';
import { ShuffleIcon as ShuffleIcon_bold } from './bold/ShuffleIcon';
import { ShuffleIcon as ShuffleIcon_solid } from './solid/ShuffleIcon';
import { Slider01Icon as Slider01Icon_regular } from './regular/Slider01Icon';
import { Slider01Icon as Slider01Icon_bold } from './bold/Slider01Icon';
import { Slider01Icon as Slider01Icon_solid } from './solid/Slider01Icon';
import { Slider02Icon as Slider02Icon_regular } from './regular/Slider02Icon';
import { Slider02Icon as Slider02Icon_bold } from './bold/Slider02Icon';
import { Slider02Icon as Slider02Icon_solid } from './solid/Slider02Icon';
import { SpeakerOffIcon as SpeakerOffIcon_regular } from './regular/SpeakerOffIcon';
import { SpeakerOffIcon as SpeakerOffIcon_bold } from './bold/SpeakerOffIcon';
import { SpeakerOffIcon as SpeakerOffIcon_solid } from './solid/SpeakerOffIcon';
import { SpeakerOnIcon as SpeakerOnIcon_regular } from './regular/SpeakerOnIcon';
import { SpeakerOnIcon as SpeakerOnIcon_bold } from './bold/SpeakerOnIcon';
import { SpeakerOnIcon as SpeakerOnIcon_solid } from './solid/SpeakerOnIcon';
import { StarFilledIcon as StarFilledIcon_regular } from './regular/StarFilledIcon';
import { StarFilledIcon as StarFilledIcon_bold } from './bold/StarFilledIcon';
import { StarFilledIcon as StarFilledIcon_solid } from './solid/StarFilledIcon';
import { StarOutlineIcon as StarOutlineIcon_regular } from './regular/StarOutlineIcon';
import { StarOutlineIcon as StarOutlineIcon_bold } from './bold/StarOutlineIcon';
import { StarOutlineIcon as StarOutlineIcon_solid } from './solid/StarOutlineIcon';
import { StarTonedIcon as StarTonedIcon_regular } from './regular/StarTonedIcon';
import { StarTonedIcon as StarTonedIcon_bold } from './bold/StarTonedIcon';
import { StarTonedIcon as StarTonedIcon_solid } from './solid/StarTonedIcon';
import { StopIcon as StopIcon_regular } from './regular/StopIcon';
import { StopIcon as StopIcon_bold } from './bold/StopIcon';
import { StopIcon as StopIcon_solid } from './solid/StopIcon';
import { Tablet01Icon as Tablet01Icon_regular } from './regular/Tablet01Icon';
import { Tablet01Icon as Tablet01Icon_bold } from './bold/Tablet01Icon';
import { Tablet01Icon as Tablet01Icon_solid } from './solid/Tablet01Icon';
import { Tablet02Icon as Tablet02Icon_regular } from './regular/Tablet02Icon';
import { Tablet02Icon as Tablet02Icon_bold } from './bold/Tablet02Icon';
import { Tablet02Icon as Tablet02Icon_solid } from './solid/Tablet02Icon';
import { TimerAddIcon as TimerAddIcon_regular } from './regular/TimerAddIcon';
import { TimerAddIcon as TimerAddIcon_bold } from './bold/TimerAddIcon';
import { TimerAddIcon as TimerAddIcon_solid } from './solid/TimerAddIcon';
import { TimerCheckIcon as TimerCheckIcon_regular } from './regular/TimerCheckIcon';
import { TimerCheckIcon as TimerCheckIcon_bold } from './bold/TimerCheckIcon';
import { TimerCheckIcon as TimerCheckIcon_solid } from './solid/TimerCheckIcon';
import { TimerCloseIcon as TimerCloseIcon_regular } from './regular/TimerCloseIcon';
import { TimerCloseIcon as TimerCloseIcon_bold } from './bold/TimerCloseIcon';
import { TimerCloseIcon as TimerCloseIcon_solid } from './solid/TimerCloseIcon';
import { TimerEmptyIcon as TimerEmptyIcon_regular } from './regular/TimerEmptyIcon';
import { TimerEmptyIcon as TimerEmptyIcon_bold } from './bold/TimerEmptyIcon';
import { TimerEmptyIcon as TimerEmptyIcon_solid } from './solid/TimerEmptyIcon';
import { TimerMinusIcon as TimerMinusIcon_regular } from './regular/TimerMinusIcon';
import { TimerMinusIcon as TimerMinusIcon_bold } from './bold/TimerMinusIcon';
import { TimerMinusIcon as TimerMinusIcon_solid } from './solid/TimerMinusIcon';
import { TimerIcon as TimerIcon_regular } from './regular/TimerIcon';
import { TimerIcon as TimerIcon_bold } from './bold/TimerIcon';
import { TimerIcon as TimerIcon_solid } from './solid/TimerIcon';
import { ToggleOffFilledIcon as ToggleOffFilledIcon_regular } from './regular/ToggleOffFilledIcon';
import { ToggleOffFilledIcon as ToggleOffFilledIcon_bold } from './bold/ToggleOffFilledIcon';
import { ToggleOffFilledIcon as ToggleOffFilledIcon_solid } from './solid/ToggleOffFilledIcon';
import { ToggleOffOulineIcon as ToggleOffOulineIcon_regular } from './regular/ToggleOffOulineIcon';
import { ToggleOffOulineIcon as ToggleOffOulineIcon_bold } from './bold/ToggleOffOulineIcon';
import { ToggleOffOulineIcon as ToggleOffOulineIcon_solid } from './solid/ToggleOffOulineIcon';
import { ToggleOffTonedIcon as ToggleOffTonedIcon_regular } from './regular/ToggleOffTonedIcon';
import { ToggleOffTonedIcon as ToggleOffTonedIcon_bold } from './bold/ToggleOffTonedIcon';
import { ToggleOffTonedIcon as ToggleOffTonedIcon_solid } from './solid/ToggleOffTonedIcon';
import { ToggleOnFilledIcon as ToggleOnFilledIcon_regular } from './regular/ToggleOnFilledIcon';
import { ToggleOnFilledIcon as ToggleOnFilledIcon_bold } from './bold/ToggleOnFilledIcon';
import { ToggleOnFilledIcon as ToggleOnFilledIcon_solid } from './solid/ToggleOnFilledIcon';
import { ToggleOnOulineIcon as ToggleOnOulineIcon_regular } from './regular/ToggleOnOulineIcon';
import { ToggleOnOulineIcon as ToggleOnOulineIcon_bold } from './bold/ToggleOnOulineIcon';
import { ToggleOnOulineIcon as ToggleOnOulineIcon_solid } from './solid/ToggleOnOulineIcon';
import { ToggleOnTonedIcon as ToggleOnTonedIcon_regular } from './regular/ToggleOnTonedIcon';
import { ToggleOnTonedIcon as ToggleOnTonedIcon_bold } from './bold/ToggleOnTonedIcon';
import { ToggleOnTonedIcon as ToggleOnTonedIcon_solid } from './solid/ToggleOnTonedIcon';
import { Trash01Icon as Trash01Icon_regular } from './regular/Trash01Icon';
import { Trash01Icon as Trash01Icon_bold } from './bold/Trash01Icon';
import { Trash01Icon as Trash01Icon_solid } from './solid/Trash01Icon';
import { Trash02Icon as Trash02Icon_regular } from './regular/Trash02Icon';
import { Trash02Icon as Trash02Icon_bold } from './bold/Trash02Icon';
import { Trash02Icon as Trash02Icon_solid } from './solid/Trash02Icon';
import { TrendArrowDecrease02Icon as TrendArrowDecrease02Icon_regular } from './regular/TrendArrowDecrease02Icon';
import { TrendArrowDecrease02Icon as TrendArrowDecrease02Icon_bold } from './bold/TrendArrowDecrease02Icon';
import { TrendArrowDecrease02Icon as TrendArrowDecrease02Icon_solid } from './solid/TrendArrowDecrease02Icon';
import { TrendArrowDoubleIcon as TrendArrowDoubleIcon_regular } from './regular/TrendArrowDoubleIcon';
import { TrendArrowDoubleIcon as TrendArrowDoubleIcon_bold } from './bold/TrendArrowDoubleIcon';
import { TrendArrowDoubleIcon as TrendArrowDoubleIcon_solid } from './solid/TrendArrowDoubleIcon';
import { TrendArrowIncrease02Icon as TrendArrowIncrease02Icon_regular } from './regular/TrendArrowIncrease02Icon';
import { TrendArrowIncrease02Icon as TrendArrowIncrease02Icon_bold } from './bold/TrendArrowIncrease02Icon';
import { TrendArrowIncrease02Icon as TrendArrowIncrease02Icon_solid } from './solid/TrendArrowIncrease02Icon';
import { TrendDoubleIcon as TrendDoubleIcon_regular } from './regular/TrendDoubleIcon';
import { TrendDoubleIcon as TrendDoubleIcon_bold } from './bold/TrendDoubleIcon';
import { TrendDoubleIcon as TrendDoubleIcon_solid } from './solid/TrendDoubleIcon';
import { TriangleIcon as TriangleIcon_regular } from './regular/TriangleIcon';
import { TriangleIcon as TriangleIcon_bold } from './bold/TriangleIcon';
import { TriangleIcon as TriangleIcon_solid } from './solid/TriangleIcon';
import { UndoIcon as UndoIcon_regular } from './regular/UndoIcon';
import { UndoIcon as UndoIcon_bold } from './bold/UndoIcon';
import { UndoIcon as UndoIcon_solid } from './solid/UndoIcon';
import { UnfoldLessCircleIcon as UnfoldLessCircleIcon_regular } from './regular/UnfoldLessCircleIcon';
import { UnfoldLessCircleIcon as UnfoldLessCircleIcon_bold } from './bold/UnfoldLessCircleIcon';
import { UnfoldLessCircleIcon as UnfoldLessCircleIcon_solid } from './solid/UnfoldLessCircleIcon';
import { UnfoldLessSquareIcon as UnfoldLessSquareIcon_regular } from './regular/UnfoldLessSquareIcon';
import { UnfoldLessSquareIcon as UnfoldLessSquareIcon_bold } from './bold/UnfoldLessSquareIcon';
import { UnfoldLessSquareIcon as UnfoldLessSquareIcon_solid } from './solid/UnfoldLessSquareIcon';
import { UnfoldLessIcon as UnfoldLessIcon_regular } from './regular/UnfoldLessIcon';
import { UnfoldLessIcon as UnfoldLessIcon_bold } from './bold/UnfoldLessIcon';
import { UnfoldLessIcon as UnfoldLessIcon_solid } from './solid/UnfoldLessIcon';
import { UnfoldMoreCircleIcon as UnfoldMoreCircleIcon_regular } from './regular/UnfoldMoreCircleIcon';
import { UnfoldMoreCircleIcon as UnfoldMoreCircleIcon_bold } from './bold/UnfoldMoreCircleIcon';
import { UnfoldMoreCircleIcon as UnfoldMoreCircleIcon_solid } from './solid/UnfoldMoreCircleIcon';
import { UnfoldMoreSquareIcon as UnfoldMoreSquareIcon_regular } from './regular/UnfoldMoreSquareIcon';
import { UnfoldMoreSquareIcon as UnfoldMoreSquareIcon_bold } from './bold/UnfoldMoreSquareIcon';
import { UnfoldMoreSquareIcon as UnfoldMoreSquareIcon_solid } from './solid/UnfoldMoreSquareIcon';
import { UnfoldMoreIcon as UnfoldMoreIcon_regular } from './regular/UnfoldMoreIcon';
import { UnfoldMoreIcon as UnfoldMoreIcon_bold } from './bold/UnfoldMoreIcon';
import { UnfoldMoreIcon as UnfoldMoreIcon_solid } from './solid/UnfoldMoreIcon';
import { UnlockIcon as UnlockIcon_regular } from './regular/UnlockIcon';
import { UnlockIcon as UnlockIcon_bold } from './bold/UnlockIcon';
import { UnlockIcon as UnlockIcon_solid } from './solid/UnlockIcon';
import { UploadIcon as UploadIcon_regular } from './regular/UploadIcon';
import { UploadIcon as UploadIcon_bold } from './bold/UploadIcon';
import { UploadIcon as UploadIcon_solid } from './solid/UploadIcon';
import { UserAddIcon as UserAddIcon_regular } from './regular/UserAddIcon';
import { UserAddIcon as UserAddIcon_bold } from './bold/UserAddIcon';
import { UserAddIcon as UserAddIcon_solid } from './solid/UserAddIcon';
import { UserCheckedIcon as UserCheckedIcon_regular } from './regular/UserCheckedIcon';
import { UserCheckedIcon as UserCheckedIcon_bold } from './bold/UserCheckedIcon';
import { UserCheckedIcon as UserCheckedIcon_solid } from './solid/UserCheckedIcon';
import { UserCircleIcon as UserCircleIcon_regular } from './regular/UserCircleIcon';
import { UserCircleIcon as UserCircleIcon_bold } from './bold/UserCircleIcon';
import { UserCircleIcon as UserCircleIcon_solid } from './solid/UserCircleIcon';
import { UserInfoIcon as UserInfoIcon_regular } from './regular/UserInfoIcon';
import { UserInfoIcon as UserInfoIcon_bold } from './bold/UserInfoIcon';
import { UserInfoIcon as UserInfoIcon_solid } from './solid/UserInfoIcon';
import { UserMinusIcon as UserMinusIcon_regular } from './regular/UserMinusIcon';
import { UserMinusIcon as UserMinusIcon_bold } from './bold/UserMinusIcon';
import { UserMinusIcon as UserMinusIcon_solid } from './solid/UserMinusIcon';
import { UserRemoveIcon as UserRemoveIcon_regular } from './regular/UserRemoveIcon';
import { UserRemoveIcon as UserRemoveIcon_bold } from './bold/UserRemoveIcon';
import { UserRemoveIcon as UserRemoveIcon_solid } from './solid/UserRemoveIcon';
import { UserVoiceIcon as UserVoiceIcon_regular } from './regular/UserVoiceIcon';
import { UserVoiceIcon as UserVoiceIcon_bold } from './bold/UserVoiceIcon';
import { UserVoiceIcon as UserVoiceIcon_solid } from './solid/UserVoiceIcon';
import { UserIcon as UserIcon_regular } from './regular/UserIcon';
import { UserIcon as UserIcon_bold } from './bold/UserIcon';
import { UserIcon as UserIcon_solid } from './solid/UserIcon';
import { Users01Icon as Users01Icon_regular } from './regular/Users01Icon';
import { Users01Icon as Users01Icon_bold } from './bold/Users01Icon';
import { Users01Icon as Users01Icon_solid } from './solid/Users01Icon';
import { Users02Icon as Users02Icon_regular } from './regular/Users02Icon';
import { Users02Icon as Users02Icon_bold } from './bold/Users02Icon';
import { Users02Icon as Users02Icon_solid } from './solid/Users02Icon';
import { VerticalHorizontalIcon as VerticalHorizontalIcon_regular } from './regular/VerticalHorizontalIcon';
import { VerticalHorizontalIcon as VerticalHorizontalIcon_bold } from './bold/VerticalHorizontalIcon';
import { VerticalHorizontalIcon as VerticalHorizontalIcon_solid } from './solid/VerticalHorizontalIcon';
import { VideoCameraIcon as VideoCameraIcon_regular } from './regular/VideoCameraIcon';
import { VideoCameraIcon as VideoCameraIcon_bold } from './bold/VideoCameraIcon';
import { VideoCameraIcon as VideoCameraIcon_solid } from './solid/VideoCameraIcon';
import { VoucherIcon as VoucherIcon_regular } from './regular/VoucherIcon';
import { VoucherIcon as VoucherIcon_bold } from './bold/VoucherIcon';
import { VoucherIcon as VoucherIcon_solid } from './solid/VoucherIcon';
export type IconWeight = "regular" | "bold" | "solid";
interface IconEntry { [weight: string]: React.ComponentType<any> }
const registry: { [name: string]: IconEntry } = {};
registry['addcircle'] = {
  regular: AddCircleIcon_regular,
  bold: AddCircleIcon_bold,
  solid: AddCircleIcon_solid,
};
registry['addsquare'] = {
  regular: AddSquareIcon_regular,
  bold: AddSquareIcon_bold,
  solid: AddSquareIcon_solid,
};
registry['add'] = {
  regular: AddIcon_regular,
  bold: AddIcon_bold,
  solid: AddIcon_solid,
};
registry['airplay'] = {
  regular: AirplayIcon_regular,
  bold: AirplayIcon_bold,
  solid: AirplayIcon_solid,
};
registry['alarm'] = {
  regular: AlarmIcon_regular,
  bold: AlarmIcon_bold,
  solid: AlarmIcon_solid,
};
registry['aligncenter'] = {
  regular: AlignCenterIcon_regular,
  bold: AlignCenterIcon_bold,
  solid: AlignCenterIcon_solid,
};
registry['alignjustify'] = {
  regular: AlignJustifyIcon_regular,
  bold: AlignJustifyIcon_bold,
  solid: AlignJustifyIcon_solid,
};
registry['alignleft'] = {
  regular: AlignLeftIcon_regular,
  bold: AlignLeftIcon_bold,
  solid: AlignLeftIcon_solid,
};
registry['alignright'] = {
  regular: AlignRightIcon_regular,
  bold: AlignRightIcon_bold,
  solid: AlignRightIcon_solid,
};
registry['anglebottomleft'] = {
  regular: AngleBottomLeftIcon_regular,
  bold: AngleBottomLeftIcon_bold,
  solid: AngleBottomLeftIcon_solid,
};
registry['anglebottomright'] = {
  regular: AngleBottomRightIcon_regular,
  bold: AngleBottomRightIcon_bold,
  solid: AngleBottomRightIcon_solid,
};
registry['angletopleft'] = {
  regular: AngleTopLeftIcon_regular,
  bold: AngleTopLeftIcon_bold,
  solid: AngleTopLeftIcon_solid,
};
registry['angletopright'] = {
  regular: AngleTopRightIcon_regular,
  bold: AngleTopRightIcon_bold,
  solid: AngleTopRightIcon_solid,
};
registry['arrowbottomcircle'] = {
  regular: ArrowBottomCircleIcon_regular,
  bold: ArrowBottomCircleIcon_bold,
  solid: ArrowBottomCircleIcon_solid,
};
registry['arrowbottomlarge'] = {
  regular: ArrowBottomLargeIcon_regular,
  bold: ArrowBottomLargeIcon_bold,
  solid: ArrowBottomLargeIcon_solid,
};
registry['arrowbottomleftcircle'] = {
  regular: ArrowBottomLeftCircleIcon_regular,
  bold: ArrowBottomLeftCircleIcon_bold,
  solid: ArrowBottomLeftCircleIcon_solid,
};
registry['arrowbottomleftlarge'] = {
  regular: ArrowBottomLeftLargeIcon_regular,
  bold: ArrowBottomLeftLargeIcon_bold,
  solid: ArrowBottomLeftLargeIcon_solid,
};
registry['arrowbottomleftnormal'] = {
  regular: ArrowBottomLeftNormalIcon_regular,
  bold: ArrowBottomLeftNormalIcon_bold,
  solid: ArrowBottomLeftNormalIcon_solid,
};
registry['arrowbottomleftsquare'] = {
  regular: ArrowBottomLeftSquareIcon_regular,
  bold: ArrowBottomLeftSquareIcon_bold,
  solid: ArrowBottomLeftSquareIcon_solid,
};
registry['arrowbottomnormal'] = {
  regular: ArrowBottomNormalIcon_regular,
  bold: ArrowBottomNormalIcon_bold,
  solid: ArrowBottomNormalIcon_solid,
};
registry['arrowbottomrightcircle'] = {
  regular: ArrowBottomRightCircleIcon_regular,
  bold: ArrowBottomRightCircleIcon_bold,
  solid: ArrowBottomRightCircleIcon_solid,
};
registry['arrowbottomrightlarge'] = {
  regular: ArrowBottomRightLargeIcon_regular,
  bold: ArrowBottomRightLargeIcon_bold,
  solid: ArrowBottomRightLargeIcon_solid,
};
registry['arrowbottomrightnormal'] = {
  regular: ArrowBottomRightNormalIcon_regular,
  bold: ArrowBottomRightNormalIcon_bold,
  solid: ArrowBottomRightNormalIcon_solid,
};
registry['arrowbottomrightsquare'] = {
  regular: ArrowBottomRightSquareIcon_regular,
  bold: ArrowBottomRightSquareIcon_bold,
  solid: ArrowBottomRightSquareIcon_solid,
};
registry['arrowbottomsquare'] = {
  regular: ArrowBottomSquareIcon_regular,
  bold: ArrowBottomSquareIcon_bold,
  solid: ArrowBottomSquareIcon_solid,
};
registry['arrowleftcircle'] = {
  regular: ArrowLeftCircleIcon_regular,
  bold: ArrowLeftCircleIcon_bold,
  solid: ArrowLeftCircleIcon_solid,
};
registry['arrowleftlarge'] = {
  regular: ArrowLeftLargeIcon_regular,
  bold: ArrowLeftLargeIcon_bold,
  solid: ArrowLeftLargeIcon_solid,
};
registry['arrowleftnormal'] = {
  regular: ArrowLeftNormalIcon_regular,
  bold: ArrowLeftNormalIcon_bold,
  solid: ArrowLeftNormalIcon_solid,
};
registry['arrowleftsquare'] = {
  regular: ArrowLeftSquareIcon_regular,
  bold: ArrowLeftSquareIcon_bold,
  solid: ArrowLeftSquareIcon_solid,
};
registry['arrowrightcircle'] = {
  regular: ArrowRightCircleIcon_regular,
  bold: ArrowRightCircleIcon_bold,
  solid: ArrowRightCircleIcon_solid,
};
registry['arrowrightlarge'] = {
  regular: ArrowRightLargeIcon_regular,
  bold: ArrowRightLargeIcon_bold,
  solid: ArrowRightLargeIcon_solid,
};
registry['arrowrightnormal'] = {
  regular: ArrowRightNormalIcon_regular,
  bold: ArrowRightNormalIcon_bold,
  solid: ArrowRightNormalIcon_solid,
};
registry['arrowrightsquare'] = {
  regular: ArrowRightSquareIcon_regular,
  bold: ArrowRightSquareIcon_bold,
  solid: ArrowRightSquareIcon_solid,
};
registry['arrowtopcircle'] = {
  regular: ArrowTopCircleIcon_regular,
  bold: ArrowTopCircleIcon_bold,
  solid: ArrowTopCircleIcon_solid,
};
registry['arrowtoplarge'] = {
  regular: ArrowTopLargeIcon_regular,
  bold: ArrowTopLargeIcon_bold,
  solid: ArrowTopLargeIcon_solid,
};
registry['arrowtopleftcircle'] = {
  regular: ArrowTopLeftCircleIcon_regular,
  bold: ArrowTopLeftCircleIcon_bold,
  solid: ArrowTopLeftCircleIcon_solid,
};
registry['arrowtopleftlarge'] = {
  regular: ArrowTopLeftLargeIcon_regular,
  bold: ArrowTopLeftLargeIcon_bold,
  solid: ArrowTopLeftLargeIcon_solid,
};
registry['arrowtopleftnormal'] = {
  regular: ArrowTopLeftNormalIcon_regular,
  bold: ArrowTopLeftNormalIcon_bold,
  solid: ArrowTopLeftNormalIcon_solid,
};
registry['arrowtopleftsquare'] = {
  regular: ArrowTopLeftSquareIcon_regular,
  bold: ArrowTopLeftSquareIcon_bold,
  solid: ArrowTopLeftSquareIcon_solid,
};
registry['arrowtopnormal'] = {
  regular: ArrowTopNormalIcon_regular,
  bold: ArrowTopNormalIcon_bold,
  solid: ArrowTopNormalIcon_solid,
};
registry['arrowtoprightcircle'] = {
  regular: ArrowTopRightCircleIcon_regular,
  bold: ArrowTopRightCircleIcon_bold,
  solid: ArrowTopRightCircleIcon_solid,
};
registry['arrowtoprightlarge'] = {
  regular: ArrowTopRightLargeIcon_regular,
  bold: ArrowTopRightLargeIcon_bold,
  solid: ArrowTopRightLargeIcon_solid,
};
registry['arrowtoprightnormal'] = {
  regular: ArrowTopRightNormalIcon_regular,
  bold: ArrowTopRightNormalIcon_bold,
  solid: ArrowTopRightNormalIcon_solid,
};
registry['arrowtoprightsquare'] = {
  regular: ArrowTopRightSquareIcon_regular,
  bold: ArrowTopRightSquareIcon_bold,
  solid: ArrowTopRightSquareIcon_solid,
};
registry['arrowtopsquare'] = {
  regular: ArrowTopSquareIcon_regular,
  bold: ArrowTopSquareIcon_bold,
  solid: ArrowTopSquareIcon_solid,
};
registry['atsign'] = {
  regular: AtSignIcon_regular,
  bold: AtSignIcon_bold,
  solid: AtSignIcon_solid,
};
registry['attachments01'] = {
  regular: Attachments01Icon_regular,
  bold: Attachments01Icon_bold,
  solid: Attachments01Icon_solid,
};
registry['attachments02'] = {
  regular: Attachments02Icon_regular,
  bold: Attachments02Icon_bold,
  solid: Attachments02Icon_solid,
};
registry['attentioncircle'] = {
  regular: AttentionCircleIcon_regular,
  bold: AttentionCircleIcon_bold,
  solid: AttentionCircleIcon_solid,
};
registry['attentionsecurityshield'] = {
  regular: AttentionSecurityShieldIcon_regular,
  bold: AttentionSecurityShieldIcon_bold,
  solid: AttentionSecurityShieldIcon_solid,
};
registry['attentionsquare'] = {
  regular: AttentionSquareIcon_regular,
  bold: AttentionSquareIcon_bold,
  solid: AttentionSquareIcon_solid,
};
registry['attentionstop'] = {
  regular: AttentionStopIcon_regular,
  bold: AttentionStopIcon_bold,
  solid: AttentionStopIcon_solid,
};
registry['attentiontriangle'] = {
  regular: AttentionTriangleIcon_regular,
  bold: AttentionTriangleIcon_bold,
  solid: AttentionTriangleIcon_solid,
};
registry['bag01'] = {
  regular: Bag01Icon_regular,
  bold: Bag01Icon_bold,
  solid: Bag01Icon_solid,
};
registry['bag02'] = {
  regular: Bag02Icon_regular,
  bold: Bag02Icon_bold,
  solid: Bag02Icon_solid,
};
registry['bag03'] = {
  regular: Bag03Icon_regular,
  bold: Bag03Icon_bold,
  solid: Bag03Icon_solid,
};
registry['barchart01'] = {
  regular: BarChart01Icon_regular,
  bold: BarChart01Icon_bold,
  solid: BarChart01Icon_solid,
};
registry['barchart02'] = {
  regular: BarChart02Icon_regular,
  bold: BarChart02Icon_bold,
  solid: BarChart02Icon_solid,
};
registry['bellnotification01'] = {
  regular: BellNotification01Icon_regular,
  bold: BellNotification01Icon_bold,
  solid: BellNotification01Icon_solid,
};
registry['bellnotification03'] = {
  regular: BellNotification03Icon_regular,
  bold: BellNotification03Icon_bold,
  solid: BellNotification03Icon_solid,
};
registry['bellnotificationoff01'] = {
  regular: BellNotificationOff01Icon_regular,
  bold: BellNotificationOff01Icon_bold,
  solid: BellNotificationOff01Icon_solid,
};
registry['bellnotificationoff02'] = {
  regular: BellNotificationOff02Icon_regular,
  bold: BellNotificationOff02Icon_bold,
  solid: BellNotificationOff02Icon_solid,
};
registry['bellnotificationon01'] = {
  regular: BellNotificationOn01Icon_regular,
  bold: BellNotificationOn01Icon_bold,
  solid: BellNotificationOn01Icon_solid,
};
registry['bellnotificationon02'] = {
  regular: BellNotificationOn02Icon_regular,
  bold: BellNotificationOn02Icon_bold,
  solid: BellNotificationOn02Icon_solid,
};
registry['book01'] = {
  regular: Book01Icon_regular,
  bold: Book01Icon_bold,
  solid: Book01Icon_solid,
};
registry['book02'] = {
  regular: Book02Icon_regular,
  bold: Book02Icon_bold,
  solid: Book02Icon_solid,
};
registry['book03'] = {
  regular: Book03Icon_regular,
  bold: Book03Icon_bold,
  solid: Book03Icon_solid,
};
registry['bookmarkfilled'] = {
  regular: BookmarkFilledIcon_regular,
  bold: BookmarkFilledIcon_bold,
  solid: BookmarkFilledIcon_solid,
};
registry['bookmarkoutline'] = {
  regular: BookmarkOutlineIcon_regular,
  bold: BookmarkOutlineIcon_bold,
  solid: BookmarkOutlineIcon_solid,
};
registry['bookmarktoned'] = {
  regular: BookmarkTonedIcon_regular,
  bold: BookmarkTonedIcon_bold,
  solid: BookmarkTonedIcon_solid,
};
registry['calendaradd'] = {
  regular: CalendarAddIcon_regular,
  bold: CalendarAddIcon_bold,
  solid: CalendarAddIcon_solid,
};
registry['calendarcheck'] = {
  regular: CalendarCheckIcon_regular,
  bold: CalendarCheckIcon_bold,
  solid: CalendarCheckIcon_solid,
};
registry['calendarclose'] = {
  regular: CalendarCloseIcon_regular,
  bold: CalendarCloseIcon_bold,
  solid: CalendarCloseIcon_solid,
};
registry['calendarday'] = {
  regular: CalendarDayIcon_regular,
  bold: CalendarDayIcon_bold,
  solid: CalendarDayIcon_solid,
};
registry['calendarempty'] = {
  regular: CalendarEmptyIcon_regular,
  bold: CalendarEmptyIcon_bold,
  solid: CalendarEmptyIcon_solid,
};
registry['calendarmonth'] = {
  regular: CalendarMonthIcon_regular,
  bold: CalendarMonthIcon_bold,
  solid: CalendarMonthIcon_solid,
};
registry['calendarremove'] = {
  regular: CalendarRemoveIcon_regular,
  bold: CalendarRemoveIcon_bold,
  solid: CalendarRemoveIcon_solid,
};
registry['calendarweek'] = {
  regular: CalendarWeekIcon_regular,
  bold: CalendarWeekIcon_bold,
  solid: CalendarWeekIcon_solid,
};
registry['callphone'] = {
  regular: CallPhoneIcon_regular,
  bold: CallPhoneIcon_bold,
  solid: CallPhoneIcon_solid,
};
registry['cart01'] = {
  regular: Cart01Icon_regular,
  bold: Cart01Icon_bold,
  solid: Cart01Icon_solid,
};
registry['cart02'] = {
  regular: Cart02Icon_regular,
  bold: Cart02Icon_bold,
  solid: Cart02Icon_solid,
};
registry['chatconversation'] = {
  regular: ChatConversationIcon_regular,
  bold: ChatConversationIcon_bold,
  solid: ChatConversationIcon_solid,
};
registry['checkdouble'] = {
  regular: CheckDoubleIcon_regular,
  bold: CheckDoubleIcon_bold,
  solid: CheckDoubleIcon_solid,
};
registry['checksingle'] = {
  regular: CheckSingleIcon_regular,
  bold: CheckSingleIcon_bold,
  solid: CheckSingleIcon_solid,
};
registry['checkboxaddfilled'] = {
  regular: CheckboxAddFilledIcon_regular,
  bold: CheckboxAddFilledIcon_bold,
  solid: CheckboxAddFilledIcon_solid,
};
registry['checkboxaddoutline'] = {
  regular: CheckboxAddOutlineIcon_regular,
  bold: CheckboxAddOutlineIcon_bold,
  solid: CheckboxAddOutlineIcon_solid,
};
registry['checkboxaddtoned'] = {
  regular: CheckboxAddTonedIcon_regular,
  bold: CheckboxAddTonedIcon_bold,
  solid: CheckboxAddTonedIcon_solid,
};
registry['checkboxbulkfilled'] = {
  regular: CheckboxBulkFilledIcon_regular,
  bold: CheckboxBulkFilledIcon_bold,
  solid: CheckboxBulkFilledIcon_solid,
};
registry['checkboxbulkoutline'] = {
  regular: CheckboxBulkOutlineIcon_regular,
  bold: CheckboxBulkOutlineIcon_bold,
  solid: CheckboxBulkOutlineIcon_solid,
};
registry['checkboxbulktoned'] = {
  regular: CheckboxBulkTonedIcon_regular,
  bold: CheckboxBulkTonedIcon_bold,
  solid: CheckboxBulkTonedIcon_solid,
};
registry['checkboxcheckedfilled'] = {
  regular: CheckboxCheckedFilledIcon_regular,
  bold: CheckboxCheckedFilledIcon_bold,
  solid: CheckboxCheckedFilledIcon_solid,
};
registry['checkboxcheckedoutline'] = {
  regular: CheckboxCheckedOutlineIcon_regular,
  bold: CheckboxCheckedOutlineIcon_bold,
  solid: CheckboxCheckedOutlineIcon_solid,
};
registry['checkboxcheckedtoned'] = {
  regular: CheckboxCheckedTonedIcon_regular,
  bold: CheckboxCheckedTonedIcon_bold,
  solid: CheckboxCheckedTonedIcon_solid,
};
registry['checkboxdotfilled'] = {
  regular: CheckboxDotFilledIcon_regular,
  bold: CheckboxDotFilledIcon_bold,
  solid: CheckboxDotFilledIcon_solid,
};
registry['checkboxdotoutline'] = {
  regular: CheckboxDotOutlineIcon_regular,
  bold: CheckboxDotOutlineIcon_bold,
  solid: CheckboxDotOutlineIcon_solid,
};
registry['checkboxdottoned'] = {
  regular: CheckboxDotTonedIcon_regular,
  bold: CheckboxDotTonedIcon_bold,
  solid: CheckboxDotTonedIcon_solid,
};
registry['checkboxemptyfilled'] = {
  regular: CheckboxEmptyFilledIcon_regular,
  bold: CheckboxEmptyFilledIcon_bold,
  solid: CheckboxEmptyFilledIcon_solid,
};
registry['checkboxemptyoutline'] = {
  regular: CheckboxEmptyOutlineIcon_regular,
  bold: CheckboxEmptyOutlineIcon_bold,
  solid: CheckboxEmptyOutlineIcon_solid,
};
registry['checkboxemptytoned'] = {
  regular: CheckboxEmptyTonedIcon_regular,
  bold: CheckboxEmptyTonedIcon_bold,
  solid: CheckboxEmptyTonedIcon_solid,
};
registry['checkboxexcludedfilled'] = {
  regular: CheckboxExcludedFilledIcon_regular,
  bold: CheckboxExcludedFilledIcon_bold,
  solid: CheckboxExcludedFilledIcon_solid,
};
registry['checkboxexcludedoutline'] = {
  regular: CheckboxExcludedOutlineIcon_regular,
  bold: CheckboxExcludedOutlineIcon_bold,
  solid: CheckboxExcludedOutlineIcon_solid,
};
registry['checkboxexcludedtoned'] = {
  regular: CheckboxExcludedTonedIcon_regular,
  bold: CheckboxExcludedTonedIcon_bold,
  solid: CheckboxExcludedTonedIcon_solid,
};
registry['chevronbottomcircle'] = {
  regular: ChevronBottomCircleIcon_regular,
  bold: ChevronBottomCircleIcon_bold,
  solid: ChevronBottomCircleIcon_solid,
};
registry['chevronbottomduo'] = {
  regular: ChevronBottomDuoIcon_regular,
  bold: ChevronBottomDuoIcon_bold,
  solid: ChevronBottomDuoIcon_solid,
};
registry['chevronbottomleftcircle'] = {
  regular: ChevronBottomLeftCircleIcon_regular,
  bold: ChevronBottomLeftCircleIcon_bold,
  solid: ChevronBottomLeftCircleIcon_solid,
};
registry['chevronbottomleftduo'] = {
  regular: ChevronBottomLeftDuoIcon_regular,
  bold: ChevronBottomLeftDuoIcon_bold,
  solid: ChevronBottomLeftDuoIcon_solid,
};
registry['chevronbottomleftnormal'] = {
  regular: ChevronBottomLeftNormalIcon_regular,
  bold: ChevronBottomLeftNormalIcon_bold,
  solid: ChevronBottomLeftNormalIcon_solid,
};
registry['chevronbottomleftsquare'] = {
  regular: ChevronBottomLeftSquareIcon_regular,
  bold: ChevronBottomLeftSquareIcon_bold,
  solid: ChevronBottomLeftSquareIcon_solid,
};
registry['chevronbottomnormal'] = {
  regular: ChevronBottomNormalIcon_regular,
  bold: ChevronBottomNormalIcon_bold,
  solid: ChevronBottomNormalIcon_solid,
};
registry['chevronbottomrightcircle'] = {
  regular: ChevronBottomRightCircleIcon_regular,
  bold: ChevronBottomRightCircleIcon_bold,
  solid: ChevronBottomRightCircleIcon_solid,
};
registry['chevronbottomrightduo'] = {
  regular: ChevronBottomRightDuoIcon_regular,
  bold: ChevronBottomRightDuoIcon_bold,
  solid: ChevronBottomRightDuoIcon_solid,
};
registry['chevronbottomrightnormal'] = {
  regular: ChevronBottomRightNormalIcon_regular,
  bold: ChevronBottomRightNormalIcon_bold,
  solid: ChevronBottomRightNormalIcon_solid,
};
registry['chevronbottomrightsquare'] = {
  regular: ChevronBottomRightSquareIcon_regular,
  bold: ChevronBottomRightSquareIcon_bold,
  solid: ChevronBottomRightSquareIcon_solid,
};
registry['chevronbottomsquare'] = {
  regular: ChevronBottomSquareIcon_regular,
  bold: ChevronBottomSquareIcon_bold,
  solid: ChevronBottomSquareIcon_solid,
};
registry['chevronleftcircle'] = {
  regular: ChevronLeftCircleIcon_regular,
  bold: ChevronLeftCircleIcon_bold,
  solid: ChevronLeftCircleIcon_solid,
};
registry['chevronleftduo'] = {
  regular: ChevronLeftDuoIcon_regular,
  bold: ChevronLeftDuoIcon_bold,
  solid: ChevronLeftDuoIcon_solid,
};
registry['chevronleftnormal'] = {
  regular: ChevronLeftNormalIcon_regular,
  bold: ChevronLeftNormalIcon_bold,
  solid: ChevronLeftNormalIcon_solid,
};
registry['chevronleftsquare'] = {
  regular: ChevronLeftSquareIcon_regular,
  bold: ChevronLeftSquareIcon_bold,
  solid: ChevronLeftSquareIcon_solid,
};
registry['chevronrightcircle'] = {
  regular: ChevronRightCircleIcon_regular,
  bold: ChevronRightCircleIcon_bold,
  solid: ChevronRightCircleIcon_solid,
};
registry['chevronrightduo'] = {
  regular: ChevronRightDuoIcon_regular,
  bold: ChevronRightDuoIcon_bold,
  solid: ChevronRightDuoIcon_solid,
};
registry['chevronrightnormal'] = {
  regular: ChevronRightNormalIcon_regular,
  bold: ChevronRightNormalIcon_bold,
  solid: ChevronRightNormalIcon_solid,
};
registry['chevronrightsquare'] = {
  regular: ChevronRightSquareIcon_regular,
  bold: ChevronRightSquareIcon_bold,
  solid: ChevronRightSquareIcon_solid,
};
registry['chevrontopcircle'] = {
  regular: ChevronTopCircleIcon_regular,
  bold: ChevronTopCircleIcon_bold,
  solid: ChevronTopCircleIcon_solid,
};
registry['chevrontopduo'] = {
  regular: ChevronTopDuoIcon_regular,
  bold: ChevronTopDuoIcon_bold,
  solid: ChevronTopDuoIcon_solid,
};
registry['chevrontopleftcircle'] = {
  regular: ChevronTopLeftCircleIcon_regular,
  bold: ChevronTopLeftCircleIcon_bold,
  solid: ChevronTopLeftCircleIcon_solid,
};
registry['chevrontopleftduo'] = {
  regular: ChevronTopLeftDuoIcon_regular,
  bold: ChevronTopLeftDuoIcon_bold,
  solid: ChevronTopLeftDuoIcon_solid,
};
registry['chevrontopleftnormal'] = {
  regular: ChevronTopLeftNormalIcon_regular,
  bold: ChevronTopLeftNormalIcon_bold,
  solid: ChevronTopLeftNormalIcon_solid,
};
registry['chevrontopleftsquare'] = {
  regular: ChevronTopLeftSquareIcon_regular,
  bold: ChevronTopLeftSquareIcon_bold,
  solid: ChevronTopLeftSquareIcon_solid,
};
registry['chevrontopnormal'] = {
  regular: ChevronTopNormalIcon_regular,
  bold: ChevronTopNormalIcon_bold,
  solid: ChevronTopNormalIcon_solid,
};
registry['chevrontoprightcircle'] = {
  regular: ChevronTopRightCircleIcon_regular,
  bold: ChevronTopRightCircleIcon_bold,
  solid: ChevronTopRightCircleIcon_solid,
};
registry['chevrontoprightduo'] = {
  regular: ChevronTopRightDuoIcon_regular,
  bold: ChevronTopRightDuoIcon_bold,
  solid: ChevronTopRightDuoIcon_solid,
};
registry['chevrontoprightnormal'] = {
  regular: ChevronTopRightNormalIcon_regular,
  bold: ChevronTopRightNormalIcon_bold,
  solid: ChevronTopRightNormalIcon_solid,
};
registry['chevrontoprightsquare'] = {
  regular: ChevronTopRightSquareIcon_regular,
  bold: ChevronTopRightSquareIcon_bold,
  solid: ChevronTopRightSquareIcon_solid,
};
registry['chevrontopsquare'] = {
  regular: ChevronTopSquareIcon_regular,
  bold: ChevronTopSquareIcon_bold,
  solid: ChevronTopSquareIcon_solid,
};
registry['chromecast'] = {
  regular: ChromecastIcon_regular,
  bold: ChromecastIcon_bold,
  solid: ChromecastIcon_solid,
};
registry['clock'] = {
  regular: ClockIcon_regular,
  bold: ClockIcon_bold,
  solid: ClockIcon_solid,
};
registry['closecircle'] = {
  regular: CloseCircleIcon_regular,
  bold: CloseCircleIcon_bold,
  solid: CloseCircleIcon_solid,
};
registry['closesquare'] = {
  regular: CloseSquareIcon_regular,
  bold: CloseSquareIcon_bold,
  solid: CloseSquareIcon_solid,
};
registry['close'] = {
  regular: CloseIcon_regular,
  bold: CloseIcon_bold,
  solid: CloseIcon_solid,
};
registry['command'] = {
  regular: CommandIcon_regular,
  bold: CommandIcon_bold,
  solid: CommandIcon_solid,
};
registry['compasslocation'] = {
  regular: CompassLocationIcon_regular,
  bold: CompassLocationIcon_bold,
  solid: CompassLocationIcon_solid,
};
registry['copyadd'] = {
  regular: CopyAddIcon_regular,
  bold: CopyAddIcon_bold,
  solid: CopyAddIcon_solid,
};
registry['copycheck'] = {
  regular: CopyCheckIcon_regular,
  bold: CopyCheckIcon_bold,
  solid: CopyCheckIcon_solid,
};
registry['copyduplicate'] = {
  regular: CopyDuplicateIcon_regular,
  bold: CopyDuplicateIcon_bold,
  solid: CopyDuplicateIcon_solid,
};
registry['copyremove'] = {
  regular: CopyRemoveIcon_regular,
  bold: CopyRemoveIcon_bold,
  solid: CopyRemoveIcon_solid,
};
registry['creditcard01'] = {
  regular: CreditCard01Icon_regular,
  bold: CreditCard01Icon_bold,
  solid: CreditCard01Icon_solid,
};
registry['creditcard02'] = {
  regular: CreditCard02Icon_regular,
  bold: CreditCard02Icon_bold,
  solid: CreditCard02Icon_solid,
};
registry['delete'] = {
  regular: DeleteIcon_regular,
  bold: DeleteIcon_bold,
  solid: DeleteIcon_solid,
};
registry['desktop'] = {
  regular: DesktopIcon_regular,
  bold: DesktopIcon_bold,
  solid: DesktopIcon_solid,
};
registry['devices'] = {
  regular: DevicesIcon_regular,
  bold: DevicesIcon_bold,
  solid: DevicesIcon_solid,
};
registry['direction01'] = {
  regular: Direction01Icon_regular,
  bold: Direction01Icon_bold,
  solid: Direction01Icon_solid,
};
registry['direction02'] = {
  regular: Direction02Icon_regular,
  bold: Direction02Icon_bold,
  solid: Direction02Icon_solid,
};
registry['display'] = {
  regular: DisplayIcon_regular,
  bold: DisplayIcon_bold,
  solid: DisplayIcon_solid,
};
registry['download'] = {
  regular: DownloadIcon_regular,
  bold: DownloadIcon_bold,
  solid: DownloadIcon_solid,
};
registry['dragvertical'] = {
  regular: DragVerticalIcon_regular,
  bold: DragVerticalIcon_bold,
  solid: DragVerticalIcon_solid,
};
registry['edit01'] = {
  regular: Edit01Icon_regular,
  bold: Edit01Icon_bold,
  solid: Edit01Icon_solid,
};
registry['edit02'] = {
  regular: Edit02Icon_regular,
  bold: Edit02Icon_bold,
  solid: Edit02Icon_solid,
};
registry['edit03'] = {
  regular: Edit03Icon_regular,
  bold: Edit03Icon_bold,
  solid: Edit03Icon_solid,
};
registry['edit04'] = {
  regular: Edit04Icon_regular,
  bold: Edit04Icon_bold,
  solid: Edit04Icon_solid,
};
registry['edit05'] = {
  regular: Edit05Icon_regular,
  bold: Edit05Icon_bold,
  solid: Edit05Icon_solid,
};
registry['edit06'] = {
  regular: Edit06Icon_regular,
  bold: Edit06Icon_bold,
  solid: Edit06Icon_solid,
};
registry['equalcircle'] = {
  regular: EqualCircleIcon_regular,
  bold: EqualCircleIcon_bold,
  solid: EqualCircleIcon_solid,
};
registry['equalsquare'] = {
  regular: EqualSquareIcon_regular,
  bold: EqualSquareIcon_bold,
  solid: EqualSquareIcon_solid,
};
registry['equal'] = {
  regular: EqualIcon_regular,
  bold: EqualIcon_bold,
  solid: EqualIcon_solid,
};
registry['expand1circle'] = {
  regular: Expand1CircleIcon_regular,
  bold: Expand1CircleIcon_bold,
  solid: Expand1CircleIcon_solid,
};
registry['expand1square'] = {
  regular: Expand1SquareIcon_regular,
  bold: Expand1SquareIcon_bold,
  solid: Expand1SquareIcon_solid,
};
registry['expand1'] = {
  regular: Expand1Icon_regular,
  bold: Expand1Icon_bold,
  solid: Expand1Icon_solid,
};
registry['expand2circle'] = {
  regular: Expand2CircleIcon_regular,
  bold: Expand2CircleIcon_bold,
  solid: Expand2CircleIcon_solid,
};
registry['expand2square'] = {
  regular: Expand2SquareIcon_regular,
  bold: Expand2SquareIcon_bold,
  solid: Expand2SquareIcon_solid,
};
registry['expand2'] = {
  regular: Expand2Icon_regular,
  bold: Expand2Icon_bold,
  solid: Expand2Icon_solid,
};
registry['eyeoff'] = {
  regular: EyeOffIcon_regular,
  bold: EyeOffIcon_bold,
  solid: EyeOffIcon_solid,
};
registry['eye'] = {
  regular: EyeIcon_regular,
  bold: EyeIcon_bold,
  solid: EyeIcon_solid,
};
registry['fileadd'] = {
  regular: FileAddIcon_regular,
  bold: FileAddIcon_bold,
  solid: FileAddIcon_solid,
};
registry['filecheck'] = {
  regular: FileCheckIcon_regular,
  bold: FileCheckIcon_bold,
  solid: FileCheckIcon_solid,
};
registry['filecode'] = {
  regular: FileCodeIcon_regular,
  bold: FileCodeIcon_bold,
  solid: FileCodeIcon_solid,
};
registry['filedownload'] = {
  regular: FileDownloadIcon_regular,
  bold: FileDownloadIcon_bold,
  solid: FileDownloadIcon_solid,
};
registry['fileedit'] = {
  regular: FileEditIcon_regular,
  bold: FileEditIcon_bold,
  solid: FileEditIcon_solid,
};
registry['fileempty'] = {
  regular: FileEmptyIcon_regular,
  bold: FileEmptyIcon_bold,
  solid: FileEmptyIcon_solid,
};
registry['filefilled'] = {
  regular: FileFilledIcon_regular,
  bold: FileFilledIcon_bold,
  solid: FileFilledIcon_solid,
};
registry['fileminus'] = {
  regular: FileMinusIcon_regular,
  bold: FileMinusIcon_bold,
  solid: FileMinusIcon_solid,
};
registry['fileremove'] = {
  regular: FileRemoveIcon_regular,
  bold: FileRemoveIcon_bold,
  solid: FileRemoveIcon_solid,
};
registry['filesearch'] = {
  regular: FileSearchIcon_regular,
  bold: FileSearchIcon_bold,
  solid: FileSearchIcon_solid,
};
registry['fileupload'] = {
  regular: FileUploadIcon_regular,
  bold: FileUploadIcon_bold,
  solid: FileUploadIcon_solid,
};
registry['files'] = {
  regular: FilesIcon_regular,
  bold: FilesIcon_bold,
  solid: FilesIcon_solid,
};
registry['flag'] = {
  regular: FlagIcon_regular,
  bold: FlagIcon_bold,
  solid: FlagIcon_solid,
};
registry['flash'] = {
  regular: FlashIcon_regular,
  bold: FlashIcon_bold,
  solid: FlashIcon_solid,
};
registry['folderadd'] = {
  regular: FolderAddIcon_regular,
  bold: FolderAddIcon_bold,
  solid: FolderAddIcon_solid,
};
registry['foldercheck'] = {
  regular: FolderCheckIcon_regular,
  bold: FolderCheckIcon_bold,
  solid: FolderCheckIcon_solid,
};
registry['foldercode'] = {
  regular: FolderCodeIcon_regular,
  bold: FolderCodeIcon_bold,
  solid: FolderCodeIcon_solid,
};
registry['folderdownload'] = {
  regular: FolderDownloadIcon_regular,
  bold: FolderDownloadIcon_bold,
  solid: FolderDownloadIcon_solid,
};
registry['folderedit'] = {
  regular: FolderEditIcon_regular,
  bold: FolderEditIcon_bold,
  solid: FolderEditIcon_solid,
};
registry['folderempty'] = {
  regular: FolderEmptyIcon_regular,
  bold: FolderEmptyIcon_bold,
  solid: FolderEmptyIcon_solid,
};
registry['folderfilled'] = {
  regular: FolderFilledIcon_regular,
  bold: FolderFilledIcon_bold,
  solid: FolderFilledIcon_solid,
};
registry['folderminus'] = {
  regular: FolderMinusIcon_regular,
  bold: FolderMinusIcon_bold,
  solid: FolderMinusIcon_solid,
};
registry['folderremove'] = {
  regular: FolderRemoveIcon_regular,
  bold: FolderRemoveIcon_bold,
  solid: FolderRemoveIcon_solid,
};
registry['foldersearch'] = {
  regular: FolderSearchIcon_regular,
  bold: FolderSearchIcon_bold,
  solid: FolderSearchIcon_solid,
};
registry['folderupload'] = {
  regular: FolderUploadIcon_regular,
  bold: FolderUploadIcon_bold,
  solid: FolderUploadIcon_solid,
};
registry['folders'] = {
  regular: FoldersIcon_regular,
  bold: FoldersIcon_bold,
  solid: FoldersIcon_solid,
};
registry['forward'] = {
  regular: ForwardIcon_regular,
  bold: ForwardIcon_bold,
  solid: ForwardIcon_solid,
};
registry['frame9stop'] = {
  regular: Frame9stopIcon_regular,
  bold: Frame9stopIcon_bold,
  solid: Frame9stopIcon_solid,
};
registry['funnelfilter'] = {
  regular: FunnelFilterIcon_regular,
  bold: FunnelFilterIcon_bold,
  solid: FunnelFilterIcon_solid,
};
registry['globe'] = {
  regular: GlobeIcon_regular,
  bold: GlobeIcon_bold,
  solid: GlobeIcon_solid,
};
registry['graph01'] = {
  regular: Graph01Icon_regular,
  bold: Graph01Icon_bold,
  solid: Graph01Icon_solid,
};
registry['graph02'] = {
  regular: Graph02Icon_regular,
  bold: Graph02Icon_bold,
  solid: Graph02Icon_solid,
};
registry['grapharrowdecrease01'] = {
  regular: GraphArrowDecrease01Icon_regular,
  bold: GraphArrowDecrease01Icon_bold,
  solid: GraphArrowDecrease01Icon_solid,
};
registry['grapharrowdecrease02'] = {
  regular: GraphArrowDecrease02Icon_regular,
  bold: GraphArrowDecrease02Icon_bold,
  solid: GraphArrowDecrease02Icon_solid,
};
registry['grapharrowdouble'] = {
  regular: GraphArrowDoubleIcon_regular,
  bold: GraphArrowDoubleIcon_bold,
  solid: GraphArrowDoubleIcon_solid,
};
registry['grapharrowincrease01'] = {
  regular: GraphArrowIncrease01Icon_regular,
  bold: GraphArrowIncrease01Icon_bold,
  solid: GraphArrowIncrease01Icon_solid,
};
registry['grapharrowincrease02'] = {
  regular: GraphArrowIncrease02Icon_regular,
  bold: GraphArrowIncrease02Icon_bold,
  solid: GraphArrowIncrease02Icon_solid,
};
registry['graphdecrease'] = {
  regular: GraphDecreaseIcon_regular,
  bold: GraphDecreaseIcon_bold,
  solid: GraphDecreaseIcon_solid,
};
registry['graphdouble'] = {
  regular: GraphDoubleIcon_regular,
  bold: GraphDoubleIcon_bold,
  solid: GraphDoubleIcon_solid,
};
registry['graphincrease'] = {
  regular: GraphIncreaseIcon_regular,
  bold: GraphIncreaseIcon_bold,
  solid: GraphIncreaseIcon_solid,
};
registry['headphones'] = {
  regular: HeadphonesIcon_regular,
  bold: HeadphonesIcon_bold,
  solid: HeadphonesIcon_solid,
};
registry['heartfilled'] = {
  regular: HeartFilledIcon_regular,
  bold: HeartFilledIcon_bold,
  solid: HeartFilledIcon_solid,
};
registry['heartoutline'] = {
  regular: HeartOutlineIcon_regular,
  bold: HeartOutlineIcon_bold,
  solid: HeartOutlineIcon_solid,
};
registry['hearttoned'] = {
  regular: HeartTonedIcon_regular,
  bold: HeartTonedIcon_bold,
  solid: HeartTonedIcon_solid,
};
registry['helpcircle'] = {
  regular: HelpCircleIcon_regular,
  bold: HelpCircleIcon_bold,
  solid: HelpCircleIcon_solid,
};
registry['home01'] = {
  regular: Home01Icon_regular,
  bold: Home01Icon_bold,
  solid: Home01Icon_solid,
};
registry['home02'] = {
  regular: Home02Icon_regular,
  bold: Home02Icon_bold,
  solid: Home02Icon_solid,
};
registry['home03'] = {
  regular: Home03Icon_regular,
  bold: Home03Icon_bold,
  solid: Home03Icon_solid,
};
registry['home04'] = {
  regular: Home04Icon_regular,
  bold: Home04Icon_bold,
  solid: Home04Icon_solid,
};
registry['home05'] = {
  regular: Home05Icon_regular,
  bold: Home05Icon_bold,
  solid: Home05Icon_solid,
};
registry['home06'] = {
  regular: Home06Icon_regular,
  bold: Home06Icon_bold,
  solid: Home06Icon_solid,
};
registry['informationcircle'] = {
  regular: InformationCircleIcon_regular,
  bold: InformationCircleIcon_bold,
  solid: InformationCircleIcon_solid,
};
registry['informationsquare'] = {
  regular: InformationSquareIcon_regular,
  bold: InformationSquareIcon_bold,
  solid: InformationSquareIcon_solid,
};
registry['keyboard'] = {
  regular: KeyboardIcon_regular,
  bold: KeyboardIcon_bold,
  solid: KeyboardIcon_solid,
};
registry['labeltag01'] = {
  regular: LabelTag01Icon_regular,
  bold: LabelTag01Icon_bold,
  solid: LabelTag01Icon_solid,
};
registry['labeltag02'] = {
  regular: LabelTag02Icon_regular,
  bold: LabelTag02Icon_bold,
  solid: LabelTag02Icon_solid,
};
registry['laptop'] = {
  regular: LaptopIcon_regular,
  bold: LaptopIcon_bold,
  solid: LaptopIcon_solid,
};
registry['layers01'] = {
  regular: Layers01Icon_regular,
  bold: Layers01Icon_bold,
  solid: Layers01Icon_solid,
};
registry['layers02'] = {
  regular: Layers02Icon_regular,
  bold: Layers02Icon_bold,
  solid: Layers02Icon_solid,
};
registry['link01'] = {
  regular: Link01Icon_regular,
  bold: Link01Icon_bold,
  solid: Link01Icon_solid,
};
registry['link02'] = {
  regular: Link02Icon_regular,
  bold: Link02Icon_bold,
  solid: Link02Icon_solid,
};
registry['listadd'] = {
  regular: ListAddIcon_regular,
  bold: ListAddIcon_bold,
  solid: ListAddIcon_solid,
};
registry['listcheck'] = {
  regular: ListCheckIcon_regular,
  bold: ListCheckIcon_bold,
  solid: ListCheckIcon_solid,
};
registry['listdot'] = {
  regular: ListDotIcon_regular,
  bold: ListDotIcon_bold,
  solid: ListDotIcon_solid,
};
registry['listnumber'] = {
  regular: ListNumberIcon_regular,
  bold: ListNumberIcon_bold,
  solid: ListNumberIcon_solid,
};
registry['lock'] = {
  regular: LockIcon_regular,
  bold: LockIcon_bold,
  solid: LockIcon_solid,
};
registry['login'] = {
  regular: LogInIcon_regular,
  bold: LogInIcon_bold,
  solid: LogInIcon_solid,
};
registry['logout'] = {
  regular: LogOutIcon_regular,
  bold: LogOutIcon_bold,
  solid: LogOutIcon_solid,
};
registry['magnifiersearch01'] = {
  regular: MagnifierSearch01Icon_regular,
  bold: MagnifierSearch01Icon_bold,
  solid: MagnifierSearch01Icon_solid,
};
registry['magnifiersearch02'] = {
  regular: MagnifierSearch02Icon_regular,
  bold: MagnifierSearch02Icon_bold,
  solid: MagnifierSearch02Icon_solid,
};
registry['mailopen'] = {
  regular: MailOpenIcon_regular,
  bold: MailOpenIcon_bold,
  solid: MailOpenIcon_solid,
};
registry['mail'] = {
  regular: MailIcon_regular,
  bold: MailIcon_bold,
  solid: MailIcon_solid,
};
registry['maximize'] = {
  regular: MaximizeIcon_regular,
  bold: MaximizeIcon_bold,
  solid: MaximizeIcon_solid,
};
registry['menu01'] = {
  regular: Menu01Icon_regular,
  bold: Menu01Icon_bold,
  solid: Menu01Icon_solid,
};
registry['menu02'] = {
  regular: Menu02Icon_regular,
  bold: Menu02Icon_bold,
  solid: Menu02Icon_solid,
};
registry['menuadd'] = {
  regular: MenuAddIcon_regular,
  bold: MenuAddIcon_bold,
  solid: MenuAddIcon_solid,
};
registry['message1'] = {
  regular: Message1Icon_regular,
  bold: Message1Icon_bold,
  solid: Message1Icon_solid,
};
registry['messageadd'] = {
  regular: MessageAddIcon_regular,
  bold: MessageAddIcon_bold,
  solid: MessageAddIcon_solid,
};
registry['messagechecked'] = {
  regular: MessageCheckedIcon_regular,
  bold: MessageCheckedIcon_bold,
  solid: MessageCheckedIcon_solid,
};
registry['messageclose'] = {
  regular: MessageCloseIcon_regular,
  bold: MessageCloseIcon_bold,
  solid: MessageCloseIcon_solid,
};
registry['messagemore'] = {
  regular: MessageMoreIcon_regular,
  bold: MessageMoreIcon_bold,
  solid: MessageMoreIcon_solid,
};
registry['messageremove'] = {
  regular: MessageRemoveIcon_regular,
  bold: MessageRemoveIcon_bold,
  solid: MessageRemoveIcon_solid,
};
registry['micoff'] = {
  regular: MicOffIcon_regular,
  bold: MicOffIcon_bold,
  solid: MicOffIcon_solid,
};
registry['micon'] = {
  regular: MicOnIcon_regular,
  bold: MicOnIcon_bold,
  solid: MicOnIcon_solid,
};
registry['minimize'] = {
  regular: MinimizeIcon_regular,
  bold: MinimizeIcon_bold,
  solid: MinimizeIcon_solid,
};
registry['mobile01'] = {
  regular: Mobile01Icon_regular,
  bold: Mobile01Icon_bold,
  solid: Mobile01Icon_solid,
};
registry['mobile02'] = {
  regular: Mobile02Icon_regular,
  bold: Mobile02Icon_bold,
  solid: Mobile02Icon_solid,
};
registry['more01'] = {
  regular: More01Icon_regular,
  bold: More01Icon_bold,
  solid: More01Icon_solid,
};
registry['more02'] = {
  regular: More02Icon_regular,
  bold: More02Icon_bold,
  solid: More02Icon_solid,
};
registry['more3'] = {
  regular: More3Icon_regular,
  bold: More3Icon_bold,
  solid: More3Icon_solid,
};
registry['mouse'] = {
  regular: MouseIcon_regular,
  bold: MouseIcon_bold,
  solid: MouseIcon_solid,
};
registry['move01'] = {
  regular: Move01Icon_regular,
  bold: Move01Icon_bold,
  solid: Move01Icon_solid,
};
registry['move02'] = {
  regular: Move02Icon_regular,
  bold: Move02Icon_bold,
  solid: Move02Icon_solid,
};
registry['move03'] = {
  regular: Move03Icon_regular,
  bold: Move03Icon_bold,
  solid: Move03Icon_solid,
};
registry['move04'] = {
  regular: Move04Icon_regular,
  bold: Move04Icon_bold,
  solid: Move04Icon_solid,
};
registry['move05'] = {
  regular: Move05Icon_regular,
  bold: Move05Icon_bold,
  solid: Move05Icon_solid,
};
registry['move06'] = {
  regular: Move06Icon_regular,
  bold: Move06Icon_bold,
  solid: Move06Icon_solid,
};
registry['next'] = {
  regular: NextIcon_regular,
  bold: NextIcon_bold,
  solid: NextIcon_solid,
};
registry['pause'] = {
  regular: PauseIcon_regular,
  bold: PauseIcon_bold,
  solid: PauseIcon_solid,
};
registry['photocamera01'] = {
  regular: PhotoCamera01Icon_regular,
  bold: PhotoCamera01Icon_bold,
  solid: PhotoCamera01Icon_solid,
};
registry['photocamera02'] = {
  regular: PhotoCamera02Icon_regular,
  bold: PhotoCamera02Icon_bold,
  solid: PhotoCamera02Icon_solid,
};
registry['piechart01'] = {
  regular: PieChart01Icon_regular,
  bold: PieChart01Icon_bold,
  solid: PieChart01Icon_solid,
};
registry['piechart02'] = {
  regular: PieChart02Icon_regular,
  bold: PieChart02Icon_bold,
  solid: PieChart02Icon_solid,
};
registry['piechart03'] = {
  regular: PieChart03Icon_regular,
  bold: PieChart03Icon_bold,
  solid: PieChart03Icon_solid,
};
registry['piechart04'] = {
  regular: PieChart04Icon_regular,
  bold: PieChart04Icon_bold,
  solid: PieChart04Icon_solid,
};
registry['pinlocation'] = {
  regular: PinLocationIcon_regular,
  bold: PinLocationIcon_bold,
  solid: PinLocationIcon_solid,
};
registry['play'] = {
  regular: PlayIcon_regular,
  bold: PlayIcon_bold,
  solid: PlayIcon_solid,
};
registry['previous'] = {
  regular: PreviousIcon_regular,
  bold: PreviousIcon_bold,
  solid: PreviousIcon_solid,
};
registry['print'] = {
  regular: PrintIcon_regular,
  bold: PrintIcon_bold,
  solid: PrintIcon_solid,
};
registry['qr'] = {
  regular: QrIcon_regular,
  bold: QrIcon_bold,
  solid: QrIcon_solid,
};
registry['radiocheckedfilled'] = {
  regular: RadioCheckedFilledIcon_regular,
  bold: RadioCheckedFilledIcon_bold,
  solid: RadioCheckedFilledIcon_solid,
};
registry['radiocheckedoutline'] = {
  regular: RadioCheckedOutlineIcon_regular,
  bold: RadioCheckedOutlineIcon_bold,
  solid: RadioCheckedOutlineIcon_solid,
};
registry['radiocheckedtoned'] = {
  regular: RadioCheckedTonedIcon_regular,
  bold: RadioCheckedTonedIcon_bold,
  solid: RadioCheckedTonedIcon_solid,
};
registry['radiodotfilled'] = {
  regular: RadioDotFilledIcon_regular,
  bold: RadioDotFilledIcon_bold,
  solid: RadioDotFilledIcon_solid,
};
registry['radiodotoutline'] = {
  regular: RadioDotOutlineIcon_regular,
  bold: RadioDotOutlineIcon_bold,
  solid: RadioDotOutlineIcon_solid,
};
registry['radiodottoned'] = {
  regular: RadioDotTonedIcon_regular,
  bold: RadioDotTonedIcon_bold,
  solid: RadioDotTonedIcon_solid,
};
registry['radioemptyfilled'] = {
  regular: RadioEmptyFilledIcon_regular,
  bold: RadioEmptyFilledIcon_bold,
  solid: RadioEmptyFilledIcon_solid,
};
registry['radioemptyoutline'] = {
  regular: RadioEmptyOutlineIcon_regular,
  bold: RadioEmptyOutlineIcon_bold,
  solid: RadioEmptyOutlineIcon_solid,
};
registry['radioemptytoned'] = {
  regular: RadioEmptyTonedIcon_regular,
  bold: RadioEmptyTonedIcon_bold,
  solid: RadioEmptyTonedIcon_solid,
};
registry['radioexcludedfilled'] = {
  regular: RadioExcludedFilledIcon_regular,
  bold: RadioExcludedFilledIcon_bold,
  solid: RadioExcludedFilledIcon_solid,
};
registry['radioexcludedoutline'] = {
  regular: RadioExcludedOutlineIcon_regular,
  bold: RadioExcludedOutlineIcon_bold,
  solid: RadioExcludedOutlineIcon_solid,
};
registry['radioexcludedtoned'] = {
  regular: RadioExcludedTonedIcon_regular,
  bold: RadioExcludedTonedIcon_bold,
  solid: RadioExcludedTonedIcon_solid,
};
registry['redo'] = {
  regular: RedoIcon_regular,
  bold: RedoIcon_bold,
  solid: RedoIcon_solid,
};
registry['reload01'] = {
  regular: Reload01Icon_regular,
  bold: Reload01Icon_bold,
  solid: Reload01Icon_solid,
};
registry['reload02'] = {
  regular: Reload02Icon_regular,
  bold: Reload02Icon_bold,
  solid: Reload02Icon_solid,
};
registry['removecircle'] = {
  regular: RemoveCircleIcon_regular,
  bold: RemoveCircleIcon_bold,
  solid: RemoveCircleIcon_solid,
};
registry['removesquare'] = {
  regular: RemoveSquareIcon_regular,
  bold: RemoveSquareIcon_bold,
  solid: RemoveSquareIcon_solid,
};
registry['remove'] = {
  regular: RemoveIcon_regular,
  bold: RemoveIcon_bold,
  solid: RemoveIcon_solid,
};
registry['repeat'] = {
  regular: RepeatIcon_regular,
  bold: RepeatIcon_bold,
  solid: RepeatIcon_solid,
};
registry['rewind'] = {
  regular: RewindIcon_regular,
  bold: RewindIcon_bold,
  solid: RewindIcon_solid,
};
registry['savedisk'] = {
  regular: SaveDiskIcon_regular,
  bold: SaveDiskIcon_bold,
  solid: SaveDiskIcon_solid,
};
registry['securityshield'] = {
  regular: SecurityShieldIcon_regular,
  bold: SecurityShieldIcon_bold,
  solid: SecurityShieldIcon_solid,
};
registry['send'] = {
  regular: SendIcon_regular,
  bold: SendIcon_bold,
  solid: SendIcon_solid,
};
registry['settings01'] = {
  regular: Settings01Icon_regular,
  bold: Settings01Icon_bold,
  solid: Settings01Icon_solid,
};
registry['settings02'] = {
  regular: Settings02Icon_regular,
  bold: Settings02Icon_bold,
  solid: Settings02Icon_solid,
};
registry['settings03'] = {
  regular: Settings03Icon_regular,
  bold: Settings03Icon_bold,
  solid: Settings03Icon_solid,
};
registry['shrink1circle'] = {
  regular: Shrink1CircleIcon_regular,
  bold: Shrink1CircleIcon_bold,
  solid: Shrink1CircleIcon_solid,
};
registry['shrink1square'] = {
  regular: Shrink1SquareIcon_regular,
  bold: Shrink1SquareIcon_bold,
  solid: Shrink1SquareIcon_solid,
};
registry['shrink1'] = {
  regular: Shrink1Icon_regular,
  bold: Shrink1Icon_bold,
  solid: Shrink1Icon_solid,
};
registry['shrink2circle'] = {
  regular: Shrink2CircleIcon_regular,
  bold: Shrink2CircleIcon_bold,
  solid: Shrink2CircleIcon_solid,
};
registry['shrink2square'] = {
  regular: Shrink2SquareIcon_regular,
  bold: Shrink2SquareIcon_bold,
  solid: Shrink2SquareIcon_solid,
};
registry['shrink2'] = {
  regular: Shrink2Icon_regular,
  bold: Shrink2Icon_bold,
  solid: Shrink2Icon_solid,
};
registry['shuffle'] = {
  regular: ShuffleIcon_regular,
  bold: ShuffleIcon_bold,
  solid: ShuffleIcon_solid,
};
registry['slider01'] = {
  regular: Slider01Icon_regular,
  bold: Slider01Icon_bold,
  solid: Slider01Icon_solid,
};
registry['slider02'] = {
  regular: Slider02Icon_regular,
  bold: Slider02Icon_bold,
  solid: Slider02Icon_solid,
};
registry['speakeroff'] = {
  regular: SpeakerOffIcon_regular,
  bold: SpeakerOffIcon_bold,
  solid: SpeakerOffIcon_solid,
};
registry['speakeron'] = {
  regular: SpeakerOnIcon_regular,
  bold: SpeakerOnIcon_bold,
  solid: SpeakerOnIcon_solid,
};
registry['starfilled'] = {
  regular: StarFilledIcon_regular,
  bold: StarFilledIcon_bold,
  solid: StarFilledIcon_solid,
};
registry['staroutline'] = {
  regular: StarOutlineIcon_regular,
  bold: StarOutlineIcon_bold,
  solid: StarOutlineIcon_solid,
};
registry['startoned'] = {
  regular: StarTonedIcon_regular,
  bold: StarTonedIcon_bold,
  solid: StarTonedIcon_solid,
};
registry['stop'] = {
  regular: StopIcon_regular,
  bold: StopIcon_bold,
  solid: StopIcon_solid,
};
registry['tablet01'] = {
  regular: Tablet01Icon_regular,
  bold: Tablet01Icon_bold,
  solid: Tablet01Icon_solid,
};
registry['tablet02'] = {
  regular: Tablet02Icon_regular,
  bold: Tablet02Icon_bold,
  solid: Tablet02Icon_solid,
};
registry['timeradd'] = {
  regular: TimerAddIcon_regular,
  bold: TimerAddIcon_bold,
  solid: TimerAddIcon_solid,
};
registry['timercheck'] = {
  regular: TimerCheckIcon_regular,
  bold: TimerCheckIcon_bold,
  solid: TimerCheckIcon_solid,
};
registry['timerclose'] = {
  regular: TimerCloseIcon_regular,
  bold: TimerCloseIcon_bold,
  solid: TimerCloseIcon_solid,
};
registry['timerempty'] = {
  regular: TimerEmptyIcon_regular,
  bold: TimerEmptyIcon_bold,
  solid: TimerEmptyIcon_solid,
};
registry['timerminus'] = {
  regular: TimerMinusIcon_regular,
  bold: TimerMinusIcon_bold,
  solid: TimerMinusIcon_solid,
};
registry['timer'] = {
  regular: TimerIcon_regular,
  bold: TimerIcon_bold,
  solid: TimerIcon_solid,
};
registry['toggleofffilled'] = {
  regular: ToggleOffFilledIcon_regular,
  bold: ToggleOffFilledIcon_bold,
  solid: ToggleOffFilledIcon_solid,
};
registry['toggleoffouline'] = {
  regular: ToggleOffOulineIcon_regular,
  bold: ToggleOffOulineIcon_bold,
  solid: ToggleOffOulineIcon_solid,
};
registry['toggleofftoned'] = {
  regular: ToggleOffTonedIcon_regular,
  bold: ToggleOffTonedIcon_bold,
  solid: ToggleOffTonedIcon_solid,
};
registry['toggleonfilled'] = {
  regular: ToggleOnFilledIcon_regular,
  bold: ToggleOnFilledIcon_bold,
  solid: ToggleOnFilledIcon_solid,
};
registry['toggleonouline'] = {
  regular: ToggleOnOulineIcon_regular,
  bold: ToggleOnOulineIcon_bold,
  solid: ToggleOnOulineIcon_solid,
};
registry['toggleontoned'] = {
  regular: ToggleOnTonedIcon_regular,
  bold: ToggleOnTonedIcon_bold,
  solid: ToggleOnTonedIcon_solid,
};
registry['trash01'] = {
  regular: Trash01Icon_regular,
  bold: Trash01Icon_bold,
  solid: Trash01Icon_solid,
};
registry['trash02'] = {
  regular: Trash02Icon_regular,
  bold: Trash02Icon_bold,
  solid: Trash02Icon_solid,
};
registry['trendarrowdecrease02'] = {
  regular: TrendArrowDecrease02Icon_regular,
  bold: TrendArrowDecrease02Icon_bold,
  solid: TrendArrowDecrease02Icon_solid,
};
registry['trendarrowdouble'] = {
  regular: TrendArrowDoubleIcon_regular,
  bold: TrendArrowDoubleIcon_bold,
  solid: TrendArrowDoubleIcon_solid,
};
registry['trendarrowincrease02'] = {
  regular: TrendArrowIncrease02Icon_regular,
  bold: TrendArrowIncrease02Icon_bold,
  solid: TrendArrowIncrease02Icon_solid,
};
registry['trenddouble'] = {
  regular: TrendDoubleIcon_regular,
  bold: TrendDoubleIcon_bold,
  solid: TrendDoubleIcon_solid,
};
registry['triangle'] = {
  regular: TriangleIcon_regular,
  bold: TriangleIcon_bold,
  solid: TriangleIcon_solid,
};
registry['undo'] = {
  regular: UndoIcon_regular,
  bold: UndoIcon_bold,
  solid: UndoIcon_solid,
};
registry['unfoldlesscircle'] = {
  regular: UnfoldLessCircleIcon_regular,
  bold: UnfoldLessCircleIcon_bold,
  solid: UnfoldLessCircleIcon_solid,
};
registry['unfoldlesssquare'] = {
  regular: UnfoldLessSquareIcon_regular,
  bold: UnfoldLessSquareIcon_bold,
  solid: UnfoldLessSquareIcon_solid,
};
registry['unfoldless'] = {
  regular: UnfoldLessIcon_regular,
  bold: UnfoldLessIcon_bold,
  solid: UnfoldLessIcon_solid,
};
registry['unfoldmorecircle'] = {
  regular: UnfoldMoreCircleIcon_regular,
  bold: UnfoldMoreCircleIcon_bold,
  solid: UnfoldMoreCircleIcon_solid,
};
registry['unfoldmoresquare'] = {
  regular: UnfoldMoreSquareIcon_regular,
  bold: UnfoldMoreSquareIcon_bold,
  solid: UnfoldMoreSquareIcon_solid,
};
registry['unfoldmore'] = {
  regular: UnfoldMoreIcon_regular,
  bold: UnfoldMoreIcon_bold,
  solid: UnfoldMoreIcon_solid,
};
registry['unlock'] = {
  regular: UnlockIcon_regular,
  bold: UnlockIcon_bold,
  solid: UnlockIcon_solid,
};
registry['upload'] = {
  regular: UploadIcon_regular,
  bold: UploadIcon_bold,
  solid: UploadIcon_solid,
};
registry['useradd'] = {
  regular: UserAddIcon_regular,
  bold: UserAddIcon_bold,
  solid: UserAddIcon_solid,
};
registry['userchecked'] = {
  regular: UserCheckedIcon_regular,
  bold: UserCheckedIcon_bold,
  solid: UserCheckedIcon_solid,
};
registry['usercircle'] = {
  regular: UserCircleIcon_regular,
  bold: UserCircleIcon_bold,
  solid: UserCircleIcon_solid,
};
registry['userinfo'] = {
  regular: UserInfoIcon_regular,
  bold: UserInfoIcon_bold,
  solid: UserInfoIcon_solid,
};
registry['userminus'] = {
  regular: UserMinusIcon_regular,
  bold: UserMinusIcon_bold,
  solid: UserMinusIcon_solid,
};
registry['userremove'] = {
  regular: UserRemoveIcon_regular,
  bold: UserRemoveIcon_bold,
  solid: UserRemoveIcon_solid,
};
registry['uservoice'] = {
  regular: UserVoiceIcon_regular,
  bold: UserVoiceIcon_bold,
  solid: UserVoiceIcon_solid,
};
registry['user'] = {
  regular: UserIcon_regular,
  bold: UserIcon_bold,
  solid: UserIcon_solid,
};
registry['users01'] = {
  regular: Users01Icon_regular,
  bold: Users01Icon_bold,
  solid: Users01Icon_solid,
};
registry['users02'] = {
  regular: Users02Icon_regular,
  bold: Users02Icon_bold,
  solid: Users02Icon_solid,
};
registry['verticalhorizontal'] = {
  regular: VerticalHorizontalIcon_regular,
  bold: VerticalHorizontalIcon_bold,
  solid: VerticalHorizontalIcon_solid,
};
registry['videocamera'] = {
  regular: VideoCameraIcon_regular,
  bold: VideoCameraIcon_bold,
  solid: VideoCameraIcon_solid,
};
registry['voucher'] = {
  regular: VoucherIcon_regular,
  bold: VoucherIcon_bold,
  solid: VoucherIcon_solid,
};
export function getIconComponent(name: string, weight?: IconWeight): React.ComponentType<any> | null {
  const entry = registry[name];
  if (!entry) return null;
  const wKey = weight && entry[weight] ? weight : "regular";
  return entry[wKey] || null;
}
export const allIconNames = Object.keys(registry);