import * as React from 'react';
export const ArrowTopRightLargeIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M5.63605 18.364L18.364 5.63604M18.364 5.63604V14.1213M18.364 5.63604H9.87869" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default ArrowTopRightLargeIcon;
