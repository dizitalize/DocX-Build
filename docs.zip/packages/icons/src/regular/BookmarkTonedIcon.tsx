import * as React from 'react';
export const BookmarkTonedIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path opacity="0.2" fill-rule="evenodd" clip-rule="evenodd" d="M4 7C4 4.23858 6.23858 2 9 2H15C17.7614 2 20 4.23858 20 7V18.6516C20 21.2146 16.9936 22.5973 15.0476 20.9293L12.6508 18.8749C12.2763 18.5539 11.7237 18.5539 11.3492 18.8749L8.95237 20.9293C7.00635 22.5973 4 21.2146 4 18.6516V7Z" fill="black"/>
<path d="M5 7C5 4.79086 6.79086 3 9 3L15 3C17.2091 3 19 4.79086 19 7V18.6516C19 20.3603 16.9958 21.2821 15.6984 20.1701L13.3016 18.1156C12.5526 17.4737 11.4474 17.4737 10.6984 18.1156L8.30158 20.1701C7.00424 21.2821 5 20.3603 5 18.6516L5 7Z" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default BookmarkTonedIcon;
