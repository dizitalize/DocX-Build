import * as React from 'react';
export const AttentionStopIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<circle cx="12" cy="16" r="1" fill="black"/>
<path d="M12 8V12M8.27208 3L15.7279 3L21 8.27208V15.7279L15.7279 21H8.27208L3 15.7279L3 8.27208L8.27208 3Z" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default AttentionStopIcon;
