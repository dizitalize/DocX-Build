import * as React from 'react';
export const BarChart02Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M3 15H15C16.1046 15 17 15.8954 17 17V19C17 20.1046 16.1046 21 15 21H5C3.89543 21 3 20.1046 3 19L3 15ZM3 15L3 9M3 15H19C20.1046 15 21 14.1046 21 13V11C21 9.89543 20.1046 9 19 9L3 9M3 9L3 5C3 3.89543 3.89543 3 5 3L11 3C12.1046 3 13 3.89543 13 5V7C13 8.10457 12.1046 9 11 9L3 9Z" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default BarChart02Icon;
