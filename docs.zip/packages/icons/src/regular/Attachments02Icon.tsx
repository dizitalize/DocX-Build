import * as React from 'react';
export const Attachments02Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M3.51471 12L10.5858 4.92893C12.9289 2.58578 16.7279 2.58578 19.0711 4.92893C21.4142 7.27208 21.4142 11.0711 19.0711 13.4142L12 20.4853C10.4379 22.0474 7.90523 22.0474 6.34314 20.4853C6.12495 20.2671 5.93723 20.03 5.78 19.7792C4.81152 18.2346 4.99923 16.1723 6.34314 14.8284L13.4142 7.75736C14.1953 6.97631 15.4616 6.97631 16.2426 7.75736C17.0237 8.53841 17.0237 9.80473 16.2426 10.5858L9.17156 17.6569" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Attachments02Icon;
