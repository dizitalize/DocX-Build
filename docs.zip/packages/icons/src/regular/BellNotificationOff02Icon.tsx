import * as React from 'react';
export const BellNotificationOff02Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M14 18V19C14 20.1046 13.1046 21 12 21C10.8954 21 10 20.1046 10 19V18M14 18H10M14 18H17.5C17.6515 18 17.7978 17.9775 17.9357 17.9357M10 18H6.5C5.67157 18 5 17.3284 5 16.5C5 15.6716 5.67157 15 6.5 15H7V10C7 9.13357 7.22038 8.31862 7.60814 7.60814M12 5V3M12 5C14.7614 5 17 7.23858 17 10V12M12 5C11.4021 5 10.8288 5.10493 10.2974 5.29737M17.9357 17.9357L21 21M17.9357 17.9357L7.60814 7.60814M3 3L7.60814 7.60814" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default BellNotificationOff02Icon;
