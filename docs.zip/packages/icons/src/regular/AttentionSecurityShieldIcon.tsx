import * as React from 'react';
export const AttentionSecurityShieldIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<circle cx="12" cy="16" r="1" fill="black"/>
<path d="M12 8V12M19.5556 12.0526C20.1895 9.94304 20.0197 7.27187 19.8104 5.599C19.6931 4.66133 18.8795 4 17.9345 4H6.06546C5.12049 4 4.30692 4.66133 4.18962 5.599C3.98033 7.27187 3.81049 9.94304 4.44445 12.0526C5.42793 15.3253 9.01104 18.5945 10.8675 20.1165C11.5326 20.6617 12.4674 20.6617 13.1325 20.1165C14.989 18.5945 18.5721 15.3253 19.5556 12.0526Z" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default AttentionSecurityShieldIcon;
