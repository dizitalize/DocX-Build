import * as React from 'react';
export const BookmarkOutlineIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M5 7C5 4.79086 6.79086 3 9 3L15 3C17.2091 3 19 4.79086 19 7V18.6516C19 20.3603 16.9958 21.2821 15.6984 20.1701L13.3016 18.1156C12.5526 17.4737 11.4474 17.4737 10.6984 18.1156L8.30158 20.1701C7.00424 21.2821 5 20.3603 5 18.6516L5 7Z" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default BookmarkOutlineIcon;
