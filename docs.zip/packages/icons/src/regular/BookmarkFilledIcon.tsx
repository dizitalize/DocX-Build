import * as React from 'react';
export const BookmarkFilledIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" stroke-width="1.5">
<path fill-rule="evenodd" clip-rule="evenodd" d="M4 7C4 4.23858 6.23858 2 9 2H15C17.7614 2 20 4.23858 20 7V18.6516C20 21.2146 16.9936 22.5973 15.0476 20.9293L12.6508 18.8749C12.2763 18.5539 11.7237 18.5539 11.3492 18.8749L8.95237 20.9293C7.00635 22.5973 4 21.2146 4 18.6516V7Z" fill="black"/>
</svg>);
export default BookmarkFilledIcon;
