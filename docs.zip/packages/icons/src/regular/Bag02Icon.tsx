import * as React from 'react';
export const Bag02Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M16 7C16 4.79086 14.2091 3 12 3C9.79085 3 7.99999 4.79086 7.99999 7M6.94794 21H17.052C19.5986 21 21.4968 18.6519 20.9632 16.1619L19.6775 10.1619C19.2823 8.3176 17.6525 7 15.7663 7H8.23365C6.3475 7 4.71765 8.3176 4.32244 10.1619L3.03673 16.1619C2.50315 18.6519 4.40136 21 6.94794 21Z" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Bag02Icon;
