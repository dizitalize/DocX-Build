import * as React from 'react';
export const BellNotification01Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<circle cx="16.5" cy="8.5" r="2.5" fill="black"/>
<path d="M17 12.9725V17M13.4319 5.20805C12.9783 5.0727 12.4976 5 12 5M12 5C9.23858 5 7 7.23858 7 10V17M12 5V3M7 17H10M7 17H5M10 17V18C10 19.1046 10.8954 20 12 20C13.1046 20 14 19.1046 14 18V17M10 17H14M14 17H17M17 17H19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default BellNotification01Icon;
