import * as React from 'react';
export const CalendarEmptyIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M7.5 4H7C4.79086 4 3 5.79086 3 8M7.5 4V2M7.5 4H16.5M16.5 4H17C19.2091 4 21 5.79086 21 8M16.5 4V2M3 8V17C3 19.2091 4.79086 21 7 21H17C19.2091 21 21 19.2091 21 17V8M3 8H21" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default CalendarEmptyIcon;
