import * as React from 'react';
export const Bag03Icon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M16 7C16 4.79086 14.2091 3 12 3C9.79085 3 7.99999 4.79086 7.99999 7M8.23365 21H15.7663C17.6525 21 19.2823 19.6824 19.6775 17.8381L20.9632 11.8381C21.4968 9.34807 19.5986 7 17.052 7H6.94794C4.40136 7 2.50315 9.34807 3.03673 11.8381L4.32244 17.8381C4.71765 19.6824 6.3475 21 8.23365 21Z" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default Bag03Icon;
