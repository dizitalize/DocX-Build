import * as React from 'react';
export const ChatConversationIcon = (props: React.SVGProps<SVGSVGElement>) => (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor">
<path d="M16 9C17.96 9 19.75 10.7909 19.75 13V16.3761C19.75 17.156 19.9779 17.9188 20.4058 18.5708L22 21H12C9.79086 21 8 19.2091 8 17V15M16 9V7C16 4.79086 14.2091 3 12 3H8.25C6.04086 3 4.25 4.79086 4.25 7V10.3761C4.25 11.156 4.02205 11.9188 3.59419 12.5708L2 15H12C14.2091 15 16 13.2091 16 11V9Z" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>);
export default ChatConversationIcon;
