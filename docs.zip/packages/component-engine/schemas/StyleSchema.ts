/**
 * StyleSchema - Define component styles with theme token support.
 */
export interface StyleSchema {
  selector?: string; // CSS selector, e.g., '.button', '&:hover', '.button-icon'
  property: string; // CSS property name
  value?: string | number;
  
  // Theme token reference
  tokenPath?: string; // e.g., 'colors.primary.500', 'spacing.md'
  
  // Responsive values
  responsive?: {
    sm?: string | number;
    md?: string | number;
    lg?: string | number;
    xl?: string | number;
  };
  
  // Pseudo-class / pseudo-element
  pseudoClass?: 'hover' | 'active' | 'focus' | 'disabled' | 'visited';
  pseudoElement?: 'before' | 'after';
  
  // State-based styles
  state?: 'default' | 'hover' | 'active' | 'disabled' | 'loading';
}

export type StyleRecord = Record<string, string | number>;

export interface MergedStyles {
  baseStyles: StyleRecord;
  themeStyles: StyleRecord;
  merchantStyles: StyleRecord;
  userStyles: StyleRecord;
  computed: StyleRecord; // Final merged result
}
