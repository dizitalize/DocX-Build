/**
 * ComponentSchema - Complete schema definition for a component.
 * Unifies props, styles, validation, and metadata.
 */
import { PropSchema } from './PropSchema';
import { StyleSchema } from './StyleSchema';
import { ValidationSchema } from './ValidationSchema';

export interface DefaultValues extends Record<string, any> {
  [key: string]: any;
}

export interface MetadataSchema {
  category?: string; // e.g., 'layout', 'form', 'media'
  tags?: string[];
  documentation?: string;
  author?: string;
  createdAt?: string;
  updatedAt?: string;
  deprecated?: boolean;
  replacedBy?: string; // component name to use instead
}

export interface ComponentSchema {
  // Identity
  name: string;
  version: string;
  displayName?: string;
  description?: string;
  
  // Props definition
  props: PropSchema[];
  
  // Style definition
  styles?: StyleSchema[];
  
  // Default values for props
  defaults?: DefaultValues;
  
  // Validation rules
  validation?: ValidationSchema;
  
  // Metadata
  metadata?: MetadataSchema;
  
  // Component-specific extensions
  extensions?: Record<string, any>;
}

export type ComponentSchemaMap = Record<string, ComponentSchema>;

export type { PropSchema } from './PropSchema';
export type { StyleSchema } from './StyleSchema';
export type { ValidationSchema } from './ValidationSchema';
