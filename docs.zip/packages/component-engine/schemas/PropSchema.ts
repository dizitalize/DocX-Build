/**
 * PropSchema - Define a component prop with type, validation, and UI metadata.
 */
export type PropType = 'string' | 'number' | 'boolean' | 'enum' | 'array' | 'object' | 'event' | 'richtext';

export interface PropSchema {
  key: string;
  label: string;
  type: PropType;
  required?: boolean;
  defaultValue?: any;
  description?: string;
  
  // For enum type
  options?: Array<{ value: any; label: string }>;
  
  // For array/object type
  items?: PropSchema | Record<string, PropSchema>;
  
  // UI editor hints
  editorComponent?: string;
  editorProps?: Record<string, any>;
  
  // Validation rules
  minLength?: number;
  maxLength?: number;
  pattern?: string;
  min?: number;
  max?: number;
  
  // Conditional rendering
  visibility?: {
    dependsOn: string;
    condition: 'equals' | 'notEquals' | 'in' | 'notIn';
    value: any;
  };
}

export type PropValue = string | number | boolean | any[] | Record<string, any> | (() => void) | null | undefined;

export type PropValues = Record<string, PropValue>;
