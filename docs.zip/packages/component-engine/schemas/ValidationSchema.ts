/**
 * ValidationSchema - Define validation rules for component props and data.
 */
export type ValidationRule = 'required' | 'email' | 'url' | 'minLength' | 'maxLength' | 'pattern' | 'custom';

export interface ValidationConstraint {
  rule: ValidationRule;
  value?: any;
  message?: string;
}

export interface ValidationSchema {
  // Per-prop validation
  props?: Record<string, ValidationConstraint[]>;
  
  // Cross-prop validation (dependencies, logical rules)
  compound?: Array<{
    fields: string[];
    rule: (values: Record<string, any>) => boolean;
    message: string;
  }>;
  
  // Custom validator function
  custom?: (componentData: any) => { valid: boolean; errors: Record<string, string> };
}

export interface ValidationResult {
  valid: boolean;
  errors: Record<string, string[]>;
  warnings?: Record<string, string[]>;
}
