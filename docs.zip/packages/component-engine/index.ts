/**
 * Component Engine - Main export point.
 * Schemas, registry, renderer, style merger, and types.
 */

// Re-export all schemas
export * from './schemas/ComponentSchema';
export * from './schemas/PropSchema';
export * from './schemas/StyleSchema';
export * from './schemas/ValidationSchema';

// Re-export registry
export { ComponentRegistry, globalRegistry } from './registry/ComponentRegistry';
export type { ComponentDefinition } from './registry/ComponentRegistry';

// Re-export renderer
export { RenderEngine } from './renderer/RenderEngine';
export type { RenderBlock, RenderEngineProps } from './renderer/RenderEngine';

// Re-export style merger
export { mergeStyles, schemasToRecord, applyCssToElement, stylesToCssString } from './style-merger/mergeStyles';
export type { StyleMergeOptions, MergedStylesResult } from './style-merger/mergeStyles';

// Re-export unified types
export * from './types/index';
