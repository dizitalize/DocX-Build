/**
 * Type system for the component engine.
 * Centralizes all type definitions for schemas, components, props, and rendering.
 */

export type {
  ComponentSchema,
  ComponentSchemaMap,
  DefaultValues,
  MetadataSchema,
} from '../schemas/ComponentSchema';

export type {
  PropSchema,
  PropType,
  PropValue,
  PropValues,
} from '../schemas/PropSchema';

export type {
  StyleSchema,
  StyleRecord,
  MergedStyles,
} from '../schemas/StyleSchema';

export type {
  ValidationRule,
  ValidationConstraint,
  ValidationSchema,
  ValidationResult,
} from '../schemas/ValidationSchema';

export type {
  ComponentDefinition,
} from '../registry/ComponentRegistry';

export type {
  RenderBlock,
  RenderEngineProps,
} from '../renderer/RenderEngine';

export type {
  StyleMergeOptions,
  MergedStylesResult,
} from '../style-merger/mergeStyles';

// Re-export commonly used functions
export { ComponentRegistry, globalRegistry } from '../registry/ComponentRegistry';
export { mergeStyles, schemasToRecord, applyCssToElement, stylesToCssString } from '../style-merger/mergeStyles';
export { RenderEngine } from '../renderer/RenderEngine';
