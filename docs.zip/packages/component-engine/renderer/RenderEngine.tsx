import React, { useMemo } from 'react';
import { ComponentRegistry } from '../registry/ComponentRegistry';
import { mergeStyles } from '../style-merger/mergeStyles';
import { ComponentSchema } from '../schemas/ComponentSchema';
import type { PropValues } from '../schemas/PropSchema';
import { StyleRecord } from '../schemas/StyleSchema';

export interface RenderBlock {
  id: string;
  componentName: string;
  componentVersion?: string;
  props?: PropValues;
  styles?: StyleRecord;
  themeOverrides?: StyleRecord;
  merchantOverrides?: StyleRecord;
  children?: RenderBlock[];
}

export interface RenderEngineProps {
  blocks: RenderBlock[];
  registry: ComponentRegistry;
  themeTokens?: Record<string, any>;
  merchantTheme?: Record<string, any>;
  onError?: (error: Error) => void;
}

/**
 * Resolve default values from schema and merge with provided props.
 */
function resolveProps(schema: ComponentSchema, providedProps?: PropValues): PropValues {
  const resolved: PropValues = { ...schema.defaults };

  if (!providedProps) return resolved;

  for (const prop of schema.props) {
    if (prop.key in providedProps) {
      resolved[prop.key] = providedProps[prop.key];
    }
  }

  return resolved;
}

/**
 * Resolve theme token references in styles.
 */
function resolveStyleTokens(styles: StyleRecord, themeTokens?: Record<string, any>): StyleRecord {
  if (!themeTokens) return styles;

  const resolved: StyleRecord = {};
  for (const [key, value] of Object.entries(styles)) {
    if (typeof value === 'string' && value.startsWith('var(--')) {
      // Already a CSS var, keep as is
      resolved[key] = value;
    } else if (typeof value === 'string' && value.includes('.')) {
      // Attempt token path resolution: "colors.primary.500" -> look up in themeTokens
      const val = resolveTokenPath(value, themeTokens);
      resolved[key] = val !== undefined ? val : value;
    } else {
      resolved[key] = value;
    }
  }

  return resolved;
}

/**
 * Navigate nested theme tokens by dot notation.
 */
function resolveTokenPath(path: string, tokens: Record<string, any>): any {
  const parts = path.split('.');
  let current = tokens;

  for (const part of parts) {
    if (current == null || typeof current !== 'object') return undefined;
    current = current[part];
  }

  return current;
}

/**
 * Single render block → component instance
 */
function renderSingleBlock(
  block: RenderBlock,
  registry: ComponentRegistry,
  themeTokens?: Record<string, any>,
  merchantTheme?: Record<string, any>
): React.ReactNode {
  const definition = registry.get(block.componentName, block.componentVersion);

  if (!definition) {
    console.error(`Component not found: ${block.componentName}@${block.componentVersion || 'latest'}`);
    return null;
  }

  const { component: Component, schema } = definition;

  // Resolve props with defaults
  const resolvedProps = resolveProps(schema, block.props);

  // Merge styles: base → theme → merchant → user
  const { computed: computedStyles } = mergeStyles({
    baseStyles: schema.styles ? toStyleRecord(schema.styles) : {},
    themeStyles: themeTokens ? resolveStyleTokens(block.themeOverrides || {}, themeTokens) : {},
    merchantStyles: merchantTheme ? block.merchantOverrides || {} : {},
    userStyles: block.styles || {},
  });

  // Render children recursively if present
  const children = block.children?.map((child: RenderBlock, idx: number) =>
    React.cloneElement(renderSingleBlock(child, registry, themeTokens, merchantTheme) as React.ReactElement, {
      key: `${block.id}-child-${idx}`,
    })
  );

  return React.createElement(Component, {
    key: block.id,
    ...resolvedProps,
    style: computedStyles,
    children,
  });
}

/**
 * Convert StyleSchema to StyleRecord (simple version).
 */
function toStyleRecord(schemas: any[]): StyleRecord {
  const record: StyleRecord = {};
  for (const s of schemas) {
    if (s.property && s.value !== undefined) {
      record[s.property] = s.value;
    }
  }
  return record;
}

/**
 * RenderEngine - Dynamic component renderer with schema-driven props, defaults, and style merging.
 */
export const RenderEngine: React.FC<RenderEngineProps> = ({
  blocks,
  registry,
  themeTokens,
  merchantTheme,
  onError,
}: RenderEngineProps) => {
  const rendered = useMemo(() => {
    try {
      return blocks.map((block: RenderBlock) =>
        renderSingleBlock(block, registry, themeTokens, merchantTheme) as React.ReactElement
      );
    } catch (err) {
      if (onError && err instanceof Error) {
        onError(err);
      }
      console.error('RenderEngine error:', err);
      return [];
    }
  }, [blocks, registry, themeTokens, merchantTheme, onError]);

  return React.createElement(React.Fragment, null, ...rendered);
};

export default RenderEngine;
