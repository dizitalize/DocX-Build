/**
 * Style Merger - Merge styles with priority: base → theme → merchant → user
 */
import { StyleRecord, StyleSchema } from '../schemas/StyleSchema';

export interface StyleMergeOptions {
  baseStyles?: StyleRecord;
  themeStyles?: StyleRecord;
  merchantStyles?: StyleRecord;
  userStyles?: StyleRecord;
  computeResponsive?: boolean;
}

export interface MergedStylesResult {
  baseStyles: StyleRecord;
  themeStyles: StyleRecord;
  merchantStyles: StyleRecord;
  userStyles: StyleRecord;
  computed: StyleRecord;
}

/**
 * Deep-merge style records following priority order.
 */
function deepMergeStyles(...sources: Array<StyleRecord | undefined>): StyleRecord {
  const result: StyleRecord = {};

  for (const src of sources) {
    if (!src) continue;
    for (const [key, value] of Object.entries(src)) {
      result[key] = value;
    }
  }

  return result;
}

/**
 * Merge styles with clear priority chain.
 * Priority: base → theme → merchant → user (user wins)
 */
export function mergeStyles(options: StyleMergeOptions): MergedStylesResult {
  const {
    baseStyles = {},
    themeStyles = {},
    merchantStyles = {},
    userStyles = {},
  } = options;

  const computed = deepMergeStyles(
    baseStyles,
    themeStyles,
    merchantStyles,
    userStyles
  );

  return {
    baseStyles,
    themeStyles,
    merchantStyles,
    userStyles,
    computed,
  };
}

/**
 * Convert StyleSchema array to flat StyleRecord.
 */
export function schemasToRecord(schemas: StyleSchema[]): StyleRecord {
  const record: StyleRecord = {};

  for (const schema of schemas) {
    if (schema.value !== undefined) {
      // Use tokenPath if available, otherwise use value directly
      const key = schema.selector ? `${schema.selector}::${schema.property}` : schema.property;
      record[key] = schema.tokenPath ? `var(--${schema.tokenPath})` : schema.value;
    }
  }

  return record;
}

/**
 * Apply computed styles to an element or return CSS string.
 */
export function applyCssToElement(element: HTMLElement, styles: StyleRecord): void {
  for (const [property, value] of Object.entries(styles)) {
    // Handle selector-based styles (e.g., "button::color" -> element.style.color)
    const [, prop] = property.split('::');
    const cssProperty = prop || property;
    (element.style as any)[toCamelCase(cssProperty)] = value;
  }
}

/**
 * Convert CSS property name to camelCase for JavaScript access.
 */
function toCamelCase(str: string): string {
  return str.replace(/-([a-z])/g, (_, letter) => letter.toUpperCase());
}

/**
 * Convert styles to inline CSS string.
 */
export function stylesToCssString(styles: StyleRecord): string {
  return Object.entries(styles)
    .map(([key, value]) => {
      const [, prop] = key.split('::');
      const property = prop || key;
      return `${property}: ${value};`;
    })
    .join(' ');
}

export default mergeStyles;
