/**
 * Component Registry - Central registry for all components, editors, schemas, and versions.
 */
import { ComponentSchema } from '../schemas/ComponentSchema';

export interface ComponentDefinition {
  name: string;
  component: any; // React.ComponentType or constructor
  editor?: any; // React.ComponentType for editing UI
  schema: ComponentSchema;
  version: string;
  compatibleVersions?: string[];
}

export class ComponentRegistry {
  private registry: Map<string, ComponentDefinition> = new Map();

  /**
   * Register a new component
   */
  public register(def: ComponentDefinition): void {
    const key = this.buildKey(def.name, def.version);
    this.registry.set(key, def);
  }

  /**
   * Unregister a component
   */
  public unregister(name: string, version?: string): boolean {
    const key = version ? this.buildKey(name, version) : this.getLatestKey(name);
    if (!key) return false;
    return this.registry.delete(key);
  }

  /**
   * Get a component by name and optional version
   */
  public get(name: string, version?: string): ComponentDefinition | undefined {
    const key = version ? this.buildKey(name, version) : this.getLatestKey(name);
    return key ? this.registry.get(key) : undefined;
  }

  /**
   * Get all versions of a component
   */
  public getAll(name: string): ComponentDefinition[] {
    const results: ComponentDefinition[] = [];
    for (const def of this.registry.values()) {
      if (def.name === name) {
        results.push(def);
      }
    }
    return results;
  }

  /**
   * List all registered component names
   */
  public list(): string[] {
    const names = new Set<string>();
    for (const def of this.registry.values()) {
      names.add(def.name);
    }
    return Array.from(names);
  }

  /**
   * Check if a component is registered
   */
  public has(name: string, version?: string): boolean {
    const key = version ? this.buildKey(name, version) : this.getLatestKey(name);
    return key ? this.registry.has(key) : false;
  }

  /**
   * Get registry snapshot (for inspection)
   */
  public snapshot(): Record<string, ComponentDefinition> {
    const obj: Record<string, ComponentDefinition> = {};
    for (const [key, def] of this.registry.entries()) {
      obj[key] = def;
    }
    return obj;
  }

  /**
   * Clear the registry
   */
  public clear(): void {
    this.registry.clear();
  }

  private buildKey(name: string, version: string): string {
    return `${name}@${version}`;
  }

  private getLatestKey(name: string): string | undefined {
    let latest: string | undefined;
    let latestVersion = '0.0.0';

    for (const key of this.registry.keys()) {
      const [compName, version] = key.split('@');
      if (compName === name && this.compareVersions(version, latestVersion) > 0) {
        latestVersion = version;
        latest = key;
      }
    }

    return latest;
  }

  private compareVersions(v1: string, v2: string): number {
    const parts1 = v1.split('.').map(Number);
    const parts2 = v2.split('.').map(Number);

    for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
      const p1 = parts1[i] || 0;
      const p2 = parts2[i] || 0;
      if (p1 > p2) return 1;
      if (p1 < p2) return -1;
    }
    return 0;
  }
}

// Singleton instance
export const globalRegistry = new ComponentRegistry();

export default ComponentRegistry;
