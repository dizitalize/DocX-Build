/**
 * Shadow Tokens
 * Defines elevation and shadow values for depth
 */
export type ShadowTokens = {
    none: string;
    xs: string;
    sm: string;
    md: string;
    lg: string;
    xl: string;
    xxl: string;
};
export declare const shadowTokens: ShadowTokens;
//# sourceMappingURL=shadows.d.ts.map