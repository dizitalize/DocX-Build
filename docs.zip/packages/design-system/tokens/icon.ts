export const iconTokens = {
  size: {
    xs: 12,
    sm: 16,
    md: 20,
    lg: 24,
    xl: 32,
  },
  color: {
    primary: 'var(--color-primary-600)',
    neutral: 'var(--color-gray-500)',
    danger: 'var(--color-danger-600)',
    success: 'var(--color-success-600)',
  },
  opacity: {
    disabled: 0.38,
    active: 1,
  },
} as const;

export type IconSizeKey = keyof typeof iconTokens.size;
export type IconColorKey = keyof typeof iconTokens.color;

export default iconTokens;
