/**
 * Typography Tokens
 * Defines font families, sizes, weights, and line heights
 */
export type TypographyToken = {
    fontFamily: string;
    fontSize: string;
    fontWeight: number;
    lineHeight: string;
    letterSpacing: string;
};
export type TypographyTokens = {
    displayLarge: TypographyToken;
    displayMedium: TypographyToken;
    displaySmall: TypographyToken;
    headlineLarge: TypographyToken;
    headlineMedium: TypographyToken;
    headlineSmall: TypographyToken;
    bodyLarge: TypographyToken;
    bodyMedium: TypographyToken;
    bodySmall: TypographyToken;
    labelLarge: TypographyToken;
    labelMedium: TypographyToken;
    labelSmall: TypographyToken;
};
export declare const typographyTokens: TypographyTokens;
//# sourceMappingURL=typography.d.ts.map