/**
 * Breakpoints for Responsive Design
 */

export type BreakpointTokens = {
  mobile: string;
  tablet: string;
  desktop: string;
  wide: string;
};

export const breakpointTokens: BreakpointTokens = {
  mobile: "320px",
  tablet: "768px",
  desktop: "1024px",
  wide: "1440px",
};
