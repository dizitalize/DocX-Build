/**
 * Breakpoints for Responsive Design
 */
export type BreakpointTokens = {
    mobile: string;
    tablet: string;
    desktop: string;
    wide: string;
};
export declare const breakpointTokens: BreakpointTokens;
//# sourceMappingURL=breakpoints.d.ts.map