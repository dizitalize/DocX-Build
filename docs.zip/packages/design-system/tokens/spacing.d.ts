/**
 * Spacing Tokens
 * Defines consistent spacing scale (4px base)
 */
export type SpacingTokens = {
    xs: string;
    sm: string;
    md: string;
    lg: string;
    xl: string;
    xxl: string;
    xxxl: string;
};
export declare const spacingTokens: SpacingTokens;
//# sourceMappingURL=spacing.d.ts.map