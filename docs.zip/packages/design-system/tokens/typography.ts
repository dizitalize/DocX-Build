/**
 * Typography Tokens
 * Defines font families, sizes, weights, and line heights
 */

export type TypographyToken = {
  fontFamily: string;
  fontSize: string;
  fontWeight: number;
  lineHeight: string;
  letterSpacing: string;
};

export type TypographyTokens = {
  // Headings
  displayLarge: TypographyToken;
  displayMedium: TypographyToken;
  displaySmall: TypographyToken;

  headlineLarge: TypographyToken;
  headlineMedium: TypographyToken;
  headlineSmall: TypographyToken;

  // Body text
  bodyLarge: TypographyToken;
  bodyMedium: TypographyToken;
  bodySmall: TypographyToken;

  // Labels
  labelLarge: TypographyToken;
  labelMedium: TypographyToken;
  labelSmall: TypographyToken;
};

const fontFamily = {
  primary: "'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', sans-serif",
  mono: "'Monaco', 'Courier New', monospace",
};

export const typographyTokens: TypographyTokens = {
  // Headings
  displayLarge: {
    fontFamily: fontFamily.primary,
    fontSize: "57px",
    fontWeight: 700,
    lineHeight: "64px",
    letterSpacing: "0px",
  },
  displayMedium: {
    fontFamily: fontFamily.primary,
    fontSize: "45px",
    fontWeight: 700,
    lineHeight: "52px",
    letterSpacing: "0px",
  },
  displaySmall: {
    fontFamily: fontFamily.primary,
    fontSize: "36px",
    fontWeight: 700,
    lineHeight: "44px",
    letterSpacing: "0px",
  },

  // Headlines
  headlineLarge: {
    fontFamily: fontFamily.primary,
    fontSize: "32px",
    fontWeight: 700,
    lineHeight: "40px",
    letterSpacing: "0px",
  },
  headlineMedium: {
    fontFamily: fontFamily.primary,
    fontSize: "28px",
    fontWeight: 700,
    lineHeight: "36px",
    letterSpacing: "0px",
  },
  headlineSmall: {
    fontFamily: fontFamily.primary,
    fontSize: "24px",
    fontWeight: 700,
    lineHeight: "32px",
    letterSpacing: "0px",
  },

  // Body text
  bodyLarge: {
    fontFamily: fontFamily.primary,
    fontSize: "16px",
    fontWeight: 400,
    lineHeight: "24px",
    letterSpacing: "0.5px",
  },
  bodyMedium: {
    fontFamily: fontFamily.primary,
    fontSize: "14px",
    fontWeight: 400,
    lineHeight: "20px",
    letterSpacing: "0.25px",
  },
  bodySmall: {
    fontFamily: fontFamily.primary,
    fontSize: "12px",
    fontWeight: 400,
    lineHeight: "16px",
    letterSpacing: "0.4px",
  },

  // Labels
  labelLarge: {
    fontFamily: fontFamily.primary,
    fontSize: "14px",
    fontWeight: 500,
    lineHeight: "20px",
    letterSpacing: "0.1px",
  },
  labelMedium: {
    fontFamily: fontFamily.primary,
    fontSize: "12px",
    fontWeight: 500,
    lineHeight: "16px",
    letterSpacing: "0.5px",
  },
  labelSmall: {
    fontFamily: fontFamily.primary,
    fontSize: "11px",
    fontWeight: 500,
    lineHeight: "16px",
    letterSpacing: "0.5px",
  },
};
