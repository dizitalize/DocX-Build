/**
 * Border Radius Tokens
 * Defines consistent border radius scale
 */
export type RadiusTokens = {
    none: string;
    xs: string;
    sm: string;
    md: string;
    lg: string;
    xl: string;
    full: string;
};
export declare const radiusTokens: RadiusTokens;
//# sourceMappingURL=radius.d.ts.map