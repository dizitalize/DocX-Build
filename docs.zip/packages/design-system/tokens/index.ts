/**
 * Design System Tokens
 * Central export point for all design tokens
 */

// Color Palettes
export {
  defaultPalette,
  classicPalette,
  lightSemanticTokens,
  darkSemanticTokens,
} from "./palettes/index";
export type {
  ColorPalettes,
  ColorScale,
  SemanticTokens,
} from "./palettes/index";

// Typography
export { typographyTokens } from "./typography";
export type { TypographyTokens, TypographyToken } from "./typography";

// Spacing
export { spacingTokens } from "./spacing";
export type { SpacingTokens } from "./spacing";

// Shadows
export { shadowTokens } from "./shadows";
export type { ShadowTokens } from "./shadows";

// Border Radius
export { radiusTokens } from "./radius";
export type { RadiusTokens } from "./radius";

// Breakpoints
export { breakpointTokens } from "./breakpoints";
export type { BreakpointTokens } from "./breakpoints";

// Icon tokens
export { iconTokens } from './icon';
export type { IconSizeKey, IconColorKey } from './icon';