/**
 * Color Palettes
 * Defines all color scales (100-900) for design tokens
 */
export type ColorScale = {
    100: string;
    200: string;
    300: string;
    400: string;
    500: string;
    600: string;
    700: string;
    800: string;
    900: string;
};
export type ColorPalettes = {
    primary: ColorScale;
    secondary: ColorScale;
    tertiary: ColorScale;
    gray: ColorScale;
    accent: ColorScale;
    warning: ColorScale;
    info: ColorScale;
    danger: ColorScale;
    success: ColorScale;
    neutral: {
        white: string;
        black: string;
    };
};
/**
 * Default Theme Palette
 * Modern, accessible color scheme with proper contrast ratios
 */
export declare const defaultPalette: ColorPalettes;
/**
 * Classic Theme Palette
 * Traditional, professional color scheme
 */
export declare const classicPalette: ColorPalettes;
export * from "./semantic";
//# sourceMappingURL=index.d.ts.map