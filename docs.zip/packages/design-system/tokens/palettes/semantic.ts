/**
 * Semantic Color Tokens
 * These tokens map semantic meanings to actual colors
 * Used for UI elements that need consistent meaning across themes
 */

export type SemanticTokens = {
  // Surface colors
  surfacePrimary: string;
  surfaceSecondary: string;
  surfaceTertiary: string;

  // Text/Foreground colors
  textPrimary: string;
  textSecondary: string;
  textTertiary: string;
  textDisabled: string;

  // Interactive colors
  interactive: string;
  interactiveHover: string;
  interactiveActive: string;
  interactiveDisabled: string;

  // Status colors
  success: string;
  warning: string;
  error: string;
  info: string;

  // Borders and dividers
  borderDefault: string;
  borderSubtle: string;

  // Background
  background: string;
  backgroundSecondary: string;
};

export const lightSemanticTokens: SemanticTokens = {
  surfacePrimary: "#ffffff",
  surfaceSecondary: "#f5f5f5",
  surfaceTertiary: "#eeeeee",

  textPrimary: "#000000",
  textSecondary: "#666666",
  textTertiary: "#999999",
  textDisabled: "#cccccc",

  interactive: "#5115dfff",
  interactiveHover: "#4010c9",
  interactiveActive: "#3009b3",
  interactiveDisabled: "#e0d5f7",

  success: "#0f0",
  warning: "#ff0",
  error: "#f00",
  info: "#0099ff",

  borderDefault: "#e0e0e0",
  borderSubtle: "#f0f0f0",

  background: "#ffffff",
  backgroundSecondary: "#fafafa",
};

export const darkSemanticTokens: SemanticTokens = {
  surfacePrimary: "#1a1a1a",
  surfaceSecondary: "#2d2d2d",
  surfaceTertiary: "#3d3d3d",

  textPrimary: "#ffffff",
  textSecondary: "#cccccc",
  textTertiary: "#999999",
  textDisabled: "#666666",

  interactive: "#7c3ff2",
  interactiveHover: "#9055ff",
  interactiveActive: "#a366ff",
  interactiveDisabled: "#4a3a6b",

  success: "#0f0",
  warning: "#ff0",
  error: "#f00",
  info: "#0099ff",

  borderDefault: "#444444",
  borderSubtle: "#2a2a2a",

  background: "#121212",
  backgroundSecondary: "#1e1e1e",
};
