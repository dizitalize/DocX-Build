/**
 * Semantic Color Tokens
 * These tokens map semantic meanings to actual colors
 * Used for UI elements that need consistent meaning across themes
 */
export type SemanticTokens = {
    surfacePrimary: string;
    surfaceSecondary: string;
    surfaceTertiary: string;
    textPrimary: string;
    textSecondary: string;
    textTertiary: string;
    textDisabled: string;
    interactive: string;
    interactiveHover: string;
    interactiveActive: string;
    interactiveDisabled: string;
    success: string;
    warning: string;
    error: string;
    info: string;
    borderDefault: string;
    borderSubtle: string;
    background: string;
    backgroundSecondary: string;
};
export declare const lightSemanticTokens: SemanticTokens;
export declare const darkSemanticTokens: SemanticTokens;
//# sourceMappingURL=semantic.d.ts.map