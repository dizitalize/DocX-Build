/**
 * Color Palettes
 * Defines all color scales (100-900) for design tokens
 */

export type ColorScale = {
  100: string;
  200: string;
  300: string;
  400: string;
  500: string;
  600: string;
  700: string;
  800: string;
  900: string;
};

export type ColorPalettes = {
  primary: ColorScale;
  secondary: ColorScale;
  tertiary: ColorScale;
  gray: ColorScale;
  accent: ColorScale;
  warning: ColorScale;
  info: ColorScale;
  danger: ColorScale;
  success: ColorScale;
  neutral: {
    white: string;
    black: string;
  };
};

/**
 * Default Theme Palette
 * Modern, accessible color scheme with proper contrast ratios
 */
export const classicPalette: ColorPalettes = {
  primary: {
    100: "#f3ebff",
    200: "#e6d7ff",
    300: "#d9c3ff",
    400: "#ccafff",
    500: "#bf9bff",
    600: "#b287ff",
    700: "#a573ff",
    800: "#985fff",
    900: "#5115dfff",
  },
  secondary: {
    100: "#e8f1ff",
    200: "#d0e3ff",
    300: "#b8d5ff",
    400: "#a0c7ff",
    500: "#88b9ff",
    600: "#70abff",
    700: "#589dff",
    800: "#408fff",
    900: "#0e1c3aff",
  },
  tertiary: {
    100: "#f1f6e8",
    200: "#e2edd0",
    300: "#d4e4b9",
    400: "#c5dba1",
    500: "#b6d28a",
    600: "#a8c972",
    700: "#99c05b",
    800: "#8bb743",
    900: "#a5ce11ff",
  },
  gray: {
    100: "#f5f5f5",
    200: "#eeeeee",
    300: "#e0e0e0",
    400: "#d0d0d0",
    500: "#999999",
    600: "#808080",
    700: "#666666",
    800: "#4d4d4d",
    900: "#1a1a1a",
  },
  accent: {
    100: "#ffe8f3",
    200: "#ffd0e7",
    300: "#ffb8db",
    400: "#ffa0cf",
    500: "#ff88c3",
    600: "#ff70b7",
    700: "#ff58ab",
    800: "#ff409f",
    900: "#ff0099",
  },
  warning: {
    100: "#fff8e1",
    200: "#fff0c2",
    300: "#ffe8a3",
    400: "#ffe084",
    500: "#ffd865",
    600: "#ffd046",
    700: "#ffc827",
    800: "#ffc008",
    900: "#ff9800",
  },
  info: {
    100: "#e1f5ff",
    200: "#b3e5fc",
    300: "#81d4ff",
    400: "#4fc3ff",
    500: "#29b6ff",
    600: "#00b8ff",
    700: "#00a8e8",
    800: "#0099d8",
    900: "#0077be",
  },
  danger: {
    100: "#ffebee",
    200: "#ffcdd2",
    300: "#ef9a9a",
    400: "#e57373",
    500: "#ef5350",
    600: "#f44336",
    700: "#e53935",
    800: "#d32f2f",
    900: "#b71c1c",
  },
  success: {
    100: "#e8f5e9",
    200: "#c8e6c9",
    300: "#a5d6a7",
    400: "#81c784",
    500: "#66bb6a",
    600: "#4caf50",
    700: "#43a047",
    800: "#388e3c",
    900: "#1b5e20",
  },
  neutral: {
    white: "#ffffff",
    black: "#000000",
  },
};

/**
 * Classic Theme Palette
 * Traditional, professional color scheme
 */
export const defaultPalette: ColorPalettes = {
  primary: {
    100: "#ecf1fe",
    200: "#d8e4fc",
    300: "#c5d6fb",
    400: "#6391f4",
    500: "#3c76f1",
    600: "#366ad9",
    700: "#305ec1",
    800: "#2a53a9",
    900: "#244791",
  },
  secondary: {
    100: "#ced3dd",
    200: "#9ba6bc",
    300: "#394e75",
    400: "#213864",
    500: "#082253",
    600: "#071f4b",
    700: "#061b42",
    800: "#06183a",
    900: "#04112a",
  },
  tertiary: {
    100: "#e7fafa",
    200: "#cff5f4",
    300: "#58ddd9",
    400: "#40d9d4",
    500: "#10cfc9",
    600: "#0ebab5",
    700: "#0da6a1",
    800: "#0b918d",
    900: "#0a7c79",
  },
  gray: {
    100: "#f9f9f9",
    200: "#f3f3f3",
    300: "#ececec",
    400: "#e6e6e6",
    500: "#d9d9d9",
    600: "#bfbfbf",
    700: "#a6a6a6",
    800: "#8c8c8c",
    900: "#595959",
  },
  accent: {
    100: "#ffe0f7",
    200: "#ffc1ef",
    300: "#ffa2e7",
    400: "#ff83df",
    500: "#ff64d7",
    600: "#ff45cf",
    700: "#ff26c7",
    800: "#ff07bf",
    900: "#d9049d",
  },
  warning: {
    100: "#fff9e6",
    200: "#fff3cc",
    300: "#ffecb3",
    400: "#ffe599",
    500: "#ffde80",
    600: "#ffd666",
    700: "#ffce4d",
    800: "#ffc733",
    900: "#ffb81a",
  },
  info: {
    100: "#e3f2fd",
    200: "#bbdefb",
    300: "#90caf9",
    400: "#64b5f6",
    500: "#42a5f5",
    600: "#2196f3",
    700: "#1e88e5",
    800: "#1976d2",
    900: "#1565c0",
  },
  danger: {
    100: "#ffebee",
    200: "#ffcdd2",
    300: "#ef9a9a",
    400: "#e57373",
    500: "#ef5350",
    600: "#f44336",
    700: "#e53935",
    800: "#d32f2f",
    900: "#c62828",
  },
  success: {
    100: "#e8f5e9",
    200: "#c8e6c9",
    300: "#a5d6a7",
    400: "#81c784",
    500: "#66bb6a",
    600: "#4caf50",
    700: "#43a047",
    800: "#388e3c",
    900: "#2e7d32",
  },
  neutral: {
    white: "#ffffff",
    black: "#000000",
  },
};

export * from "./semantic";
