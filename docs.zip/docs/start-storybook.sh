#!/bin/bash
# Setup and start Storybook for the design system

echo "🚀 Starting Design System Storybook Setup..."
echo ""

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies with pnpm..."
    pnpm install
else
    echo "✅ Dependencies already installed"
fi

echo ""
echo "🎭 Starting Storybook..."
echo "📖 Storybook will open at: http://localhost:6006"
echo ""

# Start Storybook
pnpm storybook

