# 📋 Quick Reference Guide

## Project Commands

```bash
# Install all dependencies
pnpm install

# Start Storybook dev server (http://localhost:6006)
pnpm storybook

# Build static Storybook site
pnpm build-storybook

# Run TypeScript compiler check
pnpm tsc --noEmit

# Format code (if prettier configured)
pnpm format

# Lint code (if eslint configured)
pnpm lint
```

---

## Component File Structure

Every component follows this pattern:

```
Component/
├── Component.tsx              # Main component (forwardRef, CSSProperties)
├── component.schema.ts        # ComponentSchema definition
├── ComponentEditor.tsx        # Schema-driven form editor
├── index.ts                   # Exports: Component, ComponentProps, Schema, Editor
└── __stories__/
    └── Component.stories.tsx  # Storybook stories with multiple variants
```

---

## Creating a New Component

### 1. Create Component File
```typescript
// components/MyComponent/MyComponent.tsx
import React from 'react';

export interface MyComponentProps {
  title: string;
  variant?: 'primary' | 'secondary';
}

const MyComponent = React.forwardRef<HTMLDivElement, MyComponentProps>(
  ({ title, variant = 'primary' }, ref) => {
    return (
      <div
        ref={ref}
        style={{
          backgroundColor: `var(--color-${variant}-500)`,
          padding: 'var(--spacing-md)',
        }}
      >
        {title}
      </div>
    );
  }
);

MyComponent.displayName = 'MyComponent';
export default MyComponent;
```

### 2. Create Schema
```typescript
// components/MyComponent/mycomponent.schema.ts
import { ComponentSchema } from '../../component-engine';

const myComponentSchema: ComponentSchema = {
  name: 'MyComponent',
  version: '1.0.0',
  props: {
    title: { type: 'string', required: true },
    variant: { type: 'enum', values: ['primary', 'secondary'] },
  },
  defaults: {
    variant: 'primary',
  },
};

export default myComponentSchema;
```

### 3. Create Stories
```typescript
// components/MyComponent/__stories__/MyComponent.stories.tsx
import type { Meta, StoryObj } from '@storybook/react';
import MyComponent from '../MyComponent';

const meta: Meta<typeof MyComponent> = {
  title: 'UI/MyComponent',
  component: MyComponent,
  argTypes: {
    variant: { control: 'select', options: ['primary', 'secondary'] },
  },
};

export default meta;
type Story = StoryObj<typeof MyComponent>;

export const Default: Story = {
  args: { title: 'Hello' },
};
```

### 4. Create Index Export
```typescript
// components/MyComponent/index.ts
export { default as MyComponent, type MyComponentProps } from './MyComponent';
export { default as myComponentSchema } from './mycomponent.schema';
export { default as MyComponentEditor } from './MyComponentEditor';
```

---

## Using Design Tokens

### Colors
```css
/* Primary color shades 100-900 */
var(--color-primary-100)
var(--color-primary-500)  /* Default */
var(--color-primary-900)

/* Other color groups */
var(--color-secondary-500)
var(--color-tertiary-500)
var(--color-success-500)
var(--color-warning-500)
var(--color-danger-500)
```

### Spacing
```css
var(--spacing-xs)   /* 4px */
var(--spacing-sm)   /* 8px */
var(--spacing-md)   /* 12px */
var(--spacing-lg)   /* 16px */
var(--spacing-xl)   /* 20px */
var(--spacing-2xl)  /* 32px */
```

### Typography
```css
/* Font families */
var(--font-family-sans)
var(--font-family-serif)
var(--font-family-mono)

/* Font sizes */
var(--font-size-xs)
var(--font-size-sm)
var(--font-size-md)
var(--font-size-lg)
var(--font-size-xl)
var(--font-size-2xl)
var(--font-size-3xl)
var(--font-size-4xl)

/* Font weights */
var(--font-weight-light)
var(--font-weight-normal)
var(--font-weight-semibold)
var(--font-weight-bold)
```

### Radius
```css
var(--radius-sm)
var(--radius-md)
var(--radius-lg)
var(--radius-pill)
```

### Shadows
```css
var(--shadow-xs)
var(--shadow-sm)
var(--shadow-md)
var(--shadow-lg)
```

### Responsive
```css
/* Use in media queries */
@media (min-width: var(--breakpoint-sm)) { }
@media (min-width: var(--breakpoint-md)) { }
@media (min-width: var(--breakpoint-lg)) { }
```

---

## Storybook Story Patterns

### Simple Story
```typescript
export const MyStory: Story = {
  args: { prop1: 'value', prop2: true },
};
```

### Render Function (Gallery)
```typescript
export const AllVariants: Story = {
  render: () => (
    <div style={{ display: 'grid', gap: 'var(--spacing-md)' }}>
      <Component prop="value1" />
      <Component prop="value2" />
    </div>
  ),
};
```

### Decorator (Custom Layout)
```typescript
export const MyStory: Story = {
  render: () => <Component />,
  decorators: [
    (Story) => (
      <div style={{ padding: 'var(--spacing-lg)' }}>
        <Story />
      </div>
    ),
  ],
};
```

### With Documentation
```typescript
export const MyStory: Story = {
  args: { ... },
  parameters: {
    docs: {
      description: {
        story: 'This story demonstrates...',
      },
    },
  },
};
```

---

## Theme Switching in Components

### In Component
```typescript
import { useThemeEngineContext } from '@packages/theme-engine';

export function MyComponent() {
  const { theme, appearance, setAppearance } = useThemeEngineContext();

  return (
    <button onClick={() => setAppearance(
      appearance === 'light' ? 'dark' : 'light'
    )}>
      Current: {appearance}
    </button>
  );
}
```

### In Stories
```typescript
export const Dark: Story = {
  render: () => <Component />,
  decorators: [
    (Story) => {
      React.useEffect(() => {
        document.documentElement.classList.add('appearance-dark');
      }, []);
      return Story();
    },
  ],
};
```

---

## Appearance CSS Variables

### Light Mode
```css
html.appearance-light {
  --appearance-bg: #ffffff;
  --appearance-text: #000000;
  --appearance-border: #e5e7eb;
  --appearance-hover: #f3f4f6;
}
```

### Dark Mode
```css
html.appearance-dark {
  --appearance-bg: #111111;
  --appearance-text: #ffffff;
  --appearance-border: #374151;
  --appearance-hover: #1f2937;
}
```

---

## Common File Imports

```typescript
// Design Tokens
import { tokens } from '@packages/design-system/tokens';

// Theme Engine
import { ThemeProvider, useTheme } from '@packages/theme-engine';
import type { Theme, Appearance } from '@packages/theme-engine';

// Component Engine
import {
  ComponentSchema,
  PropSchema,
  StyleSchema,
  ValidationSchema,
} from '@packages/component-engine';
import { ComponentRegistry } from '@packages/component-engine';
import { RenderEngine } from '@packages/component-engine';

// UI Components
import Button from '@packages/ui-components/Button';
import Hero from '@packages/ui-components/Hero';
import Banner from '@packages/ui-components/Banner';
import Card from '@packages/ui-components/Card';
```

---

## CSS-in-JS Pattern (Hover Effects)

```typescript
const MyComponent = React.forwardRef((props, ref) => {
  const [isHovered, setIsHovered] = React.useState(false);

  return (
    <div
      ref={ref}
      style={{
        backgroundColor: isHovered 
          ? 'var(--color-primary-600)' 
          : 'var(--color-primary-500)',
        transform: isHovered ? 'scale(1.05)' : 'scale(1)',
        transition: 'all 0.2s ease',
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {props.label}
    </div>
  );
});
```

---

## Validation Example

```typescript
// In schema
validation: {
  rules: [
    {
      field: 'title',
      constraint: 'required',
      message: 'Title is required',
    },
    {
      field: 'title',
      constraint: 'minLength',
      value: 3,
      message: 'Title must be at least 3 characters',
    },
  ],
}

// In component
const validateProps = (props: MyComponentProps) => {
  if (!props.title) throw new Error('Title required');
  if (props.title.length < 3) throw new Error('Title too short');
};
```

---

## Project Statistics

- **Total Components:** 4 (Button, Hero, Banner, Card)
- **Total Stories:** 47 variants + 3 galleries
- **Design Tokens:** 6 groups (colors, spacing, typography, radius, shadows, breakpoints)
- **Color Shades:** 54 (6 groups × 9 shades)
- **Responsive Breakpoints:** 5 (xs, sm, md, lg, xl)
- **CSS Variables:** 100+
- **TypeScript Files:** 47+
- **Component Combinations:** 54+ for Button alone

---

## File Locations Reference

```
c:\Root\
├── packages/design-system/tokens/    ← Design tokens
├── packages/theme-engine/             ← Theme system
├── packages/component-engine/         ← Component schemas & renderer
├── packages/ui-components/            ← UI components + stories
│   ├── Button/__stories__/
│   ├── Hero/__stories__/
│   ├── Banner/__stories__/
│   └── Card/__stories__/
├── .storybook/                        ← Storybook config
└── storybook/src/                     ← Storybook styles & gallery
```

---

## Troubleshooting

### "Cannot find module" errors
→ Run `pnpm install` to install dependencies

### JSX errors in .ts files
→ Use .tsx extension for JSX files

### CSS variables not working
→ Check appearance class is applied: `document.documentElement.classList.contains('appearance-light')`

### Storybook stories not showing
→ Check `.storybook/main.ts` stories path matches file locations

### Theme not switching
→ Verify ThemeProvider wraps your component tree
→ Call `setAppearance('dark')` from useThemeEngineContext

---

**Quick Link Index:**
- 📚 Stories: `packages/ui-components/*/___stories__/*.stories.tsx`
- 🎨 Tokens: `packages/design-system/tokens/`
- 🎭 Theme: `packages/theme-engine/`
- ⚙️ Engine: `packages/component-engine/`
- 🔧 Config: `.storybook/main.ts` & `.storybook/preview.tsx`
