# 🚀 Workspace Setup & Configuration Guide

## Overview

This is a **pnpm monorepo** with 5 interconnected packages and Storybook 8.2.0 integration.

```
Root (workspace)
├── packages/design-system/       (Design tokens)
├── packages/theme-engine/        (Theme system)
├── packages/component-engine/    (Component schemas)
├── packages/ui-components/       (UI components)
└── storybook/                    (Storybook dev)
```

---

## Package Dependencies

```
design-system (0 deps)
    ↓
theme-engine → design-system
    ↓
component-engine → design-system + theme-engine
    ↓
ui-components → design-system + theme-engine + component-engine
    ↓
storybook → all above packages
```

---

## Installation & Setup

### Prerequisites
- **Node.js:** 18+ (ideally 20+)
- **pnpm:** 8+ (install with `npm install -g pnpm`)

### Step 1: Install Dependencies

From the root directory:

```bash
pnpm install
```

This will:
- Install all root dependencies
- Install dependencies for each package
- Link packages using workspace protocol (`workspace:*`)
- Create symbolic links between packages

### Step 2: Verify Installation

```bash
# Check workspace structure
pnpm list -r --depth=0

# Output should show:
# ├── @design-system/tokens
# ├── @design-system/theme-engine
# ├── @design-system/component-engine
# ├── @design-system/ui-components
# └── @design-system/storybook
```

### Step 3: Start Storybook

```bash
# From root directory
pnpm storybook

# Or use the convenience scripts:
# Windows:
start-storybook.bat

# macOS/Linux:
./start-storybook.sh
```

Storybook will open at: **http://localhost:6006**

---

## File Structure

### Root Files

```
package.json              → Workspace root, all scripts defined here
pnpm-workspace.yaml      → PNPM workspace configuration
tsconfig.json            → Root TypeScript config with path aliases
```

### Each Package Has

```
📦 Package Folder
├── package.json         → Package-specific dependencies
├── tsconfig.json        → Package-specific TypeScript config
├── index.ts             → Main export
└── src files/
```

---

## TypeScript Path Resolution

All packages are configured with path aliases for clean imports:

```typescript
// Instead of:
import from '../../../../packages/ui-components/Button'

// Use:
import Button from '@design-system/ui-components/button'

// Or in components:
import { tokens } from '@design-system/tokens'
import { ThemeProvider } from '@design-system/theme-engine'
import { ComponentSchema } from '@design-system/component-engine'
```

### Path Aliases Configured

| Alias | Resolves To |
|-------|-------------|
| `@design-system/tokens` | `packages/design-system/index.ts` |
| `@design-system/theme-engine` | `packages/theme-engine/index.ts` |
| `@design-system/component-engine` | `packages/component-engine/index.ts` |
| `@design-system/ui-components` | `packages/ui-components/index.ts` |
| `@design-system/ui-components/*` | `packages/ui-components/*` |
| `@/*` | `packages/*` |
| `@ui/*` | `packages/ui-components/*` |

---

## Package.json Structure

Each package follows this structure:

```json
{
  "name": "@design-system/package-name",
  "version": "1.0.0",
  "description": "...",
  "main": "index.ts",
  "types": "index.ts",
  "scripts": { "build": "tsc" },
  "dependencies": {
    "@design-system/other-package": "workspace:*"
  },
  "exports": {
    ".": { "import": "./index.ts" }
  },
  "peerDependencies": {
    "react": "^18.0.0"
  }
}
```

### Key Points

- **`workspace:*`** - Refers to other packages in workspace (auto-resolved)
- **`exports`** - Defines public API and subpaths
- **`peerDependencies`** - React is peer dep (not bundled)
- **`main` & `types`** - Point to TypeScript files (not compiled JS)

---

## Workspace Scripts

Run from root directory:

```bash
# Development
pnpm storybook              # Start Storybook dev server

# Building
pnpm build                  # Build all packages (tsc)
pnpm build-storybook        # Build static Storybook

# Filtering (run in specific package)
pnpm --filter @design-system/tokens build
pnpm --filter @design-system/ui-components build
```

---

## Adding New Components

### 1. Create Component File

```typescript
// packages/ui-components/MyComponent/MyComponent.tsx
import React from 'react';
import { tokens } from '@design-system/tokens';

export interface MyComponentProps {
  label: string;
}

const MyComponent = React.forwardRef<HTMLDivElement, MyComponentProps>(
  ({ label }, ref) => (
    <div ref={ref} style={{ padding: `var(--spacing-md)` }}>
      {label}
    </div>
  )
);

MyComponent.displayName = 'MyComponent';
export default MyComponent;
```

### 2. Create Schema

```typescript
// packages/ui-components/MyComponent/mycomponent.schema.ts
import { ComponentSchema } from '@design-system/component-engine';

const myComponentSchema: ComponentSchema = {
  name: 'MyComponent',
  version: '1.0.0',
  props: {
    label: { type: 'string', required: true },
  },
};

export default myComponentSchema;
```

### 3. Create Stories

```typescript
// packages/ui-components/MyComponent/__stories__/MyComponent.stories.tsx
import type { Meta, StoryObj } from '@storybook/react';
import MyComponent from '../MyComponent';

const meta: Meta<typeof MyComponent> = {
  title: 'UI/MyComponent',
  component: MyComponent,
};

export default meta;
type Story = StoryObj<typeof MyComponent>;

export const Default: Story = {
  args: { label: 'Hello' },
};
```

### 4. Update Export

```typescript
// packages/ui-components/MyComponent/index.ts
export { default as MyComponent, type MyComponentProps } from './MyComponent';
export { default as myComponentSchema } from './mycomponent.schema';
```

---

## Troubleshooting

### "Cannot find module" errors

**Solution:** Run `pnpm install` from root:
```bash
cd c:\Root
pnpm install
```

### Storybook won't start

**Check:**
1. Node.js version: `node --version` (needs 18+)
2. pnpm installed: `pnpm --version`
3. Dependencies installed: `pnpm install`
4. No other app on port 6006: `netstat -ano | findstr :6006` (Windows)

**Solution:**
```bash
pnpm install
pnpm storybook
```

### Path aliases not resolving

**Check:**
1. `tsconfig.json` in root and each package
2. `.storybook/tsconfig.json` exists
3. All `tsconfig.json` files have correct `paths`

**Solution:** Verify all `tsconfig.json` files exist:
```
✅ c:\Root\tsconfig.json
✅ c:\Root\.storybook\tsconfig.json
✅ c:\Root\storybook\tsconfig.json
✅ c:\Root\packages\design-system\tsconfig.json
✅ c:\Root\packages\theme-engine\tsconfig.json
✅ c:\Root\packages\component-engine\tsconfig.json
✅ c:\Root\packages\ui-components\tsconfig.json
```

### Stories not showing in Storybook

**Check:** `.storybook/main.ts` stories path matches your files:
```typescript
stories: ['packages/ui-components/**/__stories__/*.stories.@(tsx|mdx)']
```

**Solution:** Verify story files exist at:
```
✅ packages/ui-components/Button/__stories__/Button.stories.tsx
✅ packages/ui-components/Hero/__stories__/Hero.stories.tsx
✅ packages/ui-components/Banner/__stories__/Banner.stories.tsx
✅ packages/ui-components/Card/__stories__/Card.stories.tsx
```

### Type errors in editor

**Solution:** Restart TypeScript server:
- VS Code: `Ctrl+Shift+P` → "TypeScript: Restart TS Server"
- Or reload the window

---

## Quick Reference

### Install
```bash
pnpm install
```

### Start Storybook
```bash
pnpm storybook
```

### Build All Packages
```bash
pnpm build
```

### Build Static Storybook
```bash
pnpm build-storybook
```

### Check Workspace
```bash
pnpm list -r --depth=0
```

---

## Monorepo Structure Diagram

```
c:\Root/
│
├── 📄 package.json (workspace root)
├── 📄 pnpm-workspace.yaml
├── 📄 tsconfig.json (with path aliases)
│
├── 🎭 .storybook/
│   ├── main.ts (stories path, addons)
│   ├── preview.tsx (decorators)
│   └── tsconfig.json
│
├── 🧩 packages/
│   ├── design-system/
│   │   ├── package.json
│   │   ├── tsconfig.json
│   │   ├── index.ts
│   │   └── tokens/
│   │       └── *.ts (color, spacing, etc.)
│   │
│   ├── theme-engine/
│   │   ├── package.json
│   │   ├── tsconfig.json
│   │   ├── index.ts
│   │   ├── ThemeProvider.tsx
│   │   ├── useTheme.ts
│   │   └── *.ts (utility files)
│   │
│   ├── component-engine/
│   │   ├── package.json
│   │   ├── tsconfig.json
│   │   ├── index.ts
│   │   ├── schemas/
│   │   ├── registry/
│   │   ├── renderer/
│   │   ├── style-merger/
│   │   └── types/
│   │
│   └── ui-components/
│       ├── package.json
│       ├── tsconfig.json
│       ├── index.ts
│       ├── Button/
│       │   ├── Button.tsx
│       │   ├── button.schema.ts
│       │   ├── ButtonEditor.tsx
│       │   ├── index.ts
│       │   └── __stories__/
│       │       └── Button.stories.tsx
│       ├── Hero/ (same structure)
│       ├── Banner/ (same structure)
│       └── Card/ (same structure)
│
└── 🎬 storybook/
    ├── package.json
    ├── tsconfig.json
    └── src/
        ├── appearance.css
        └── stories/
            └── ThemePreview.stories.tsx
```

---

## Next Steps

1. **Install:** `pnpm install`
2. **Start:** `pnpm storybook`
3. **Explore:** Visit http://localhost:6006
4. **Create:** Add new components following the guide above
5. **Build:** `pnpm build-storybook` for production

---

**Status:** ✅ Ready to Run  
**Version:** 1.0.0  
**Last Updated:** 2024
