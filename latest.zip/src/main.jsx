import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import './index.css'
import { loadAppdata, saveAppdata, sanitizeAllDocs, createDoc } from './utils/appdata'
import { ensureRoot } from './utils/remoteFolders'
import App from './App.jsx'
import Login from './Login.jsx'
import BlockingLoader from './components/BlockingLoader.jsx'

// Global Ctrl/Cmd+K opens search
window.addEventListener('keydown', (e)=>{
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase()==='k') {
    e.preventDefault()
    window.dispatchEvent(new CustomEvent('open-search'))
  }
})

// Initialize unified Appdata structure (purge legacy ephemeral keys once)
// NOTE: skip local bootstrap on cold start when user is not logged in. We rely on Login to fetch remote Appdata
// ;(function initAppdata(){
//   const currentUser = localStorage.getItem('currentUser')
//   if(!currentUser){
//     console.log('[init] skipping local Appdata bootstrap until user login')
//     return
//   }
//   const app = loadAppdata()
//   // Ensure local root exists and continue initialization
//   ensureRoot()
//   const merged = loadAppdata()
//     // Purge legacy keys except currentUser and Appdata
//     for (const k of Object.keys(localStorage)){
//       if (k.startsWith('doc:') || k.startsWith('history:') || k.startsWith('comments:') || k==='docsIndex'){
//         localStorage.removeItem(k)
//       }
//     }
//     merged.index = merged.index || [{ id:'root', type:'folder', title:'Pages', children: [] }]
//     merged.docs = merged.docs || {}
//     merged.comments = merged.comments || {}
//     merged.history = merged.history || {}
//   merged.syncMeta = merged.syncMeta || { lastSync: new Date().toISOString(), dirty: false }
//   saveAppdata(merged)
//   // sanitize any legacy doc content that looks like local file paths
//   sanitizeAllDocs()
//     // ensure at least one starter doc exists so editor isn't blank after login
//     const hasDocs = Object.keys(merged.docs || {}).length > 0
//     if(!hasDocs){
//       const welcomeHtml = `
// <h1>Welcome to DocX</h1>
// <p>This is your first page. Use this space to capture notes, plans, or documentation. Below are a few quick tips to get started:</p>
// <h2>Editing Basics</h2>
// <ul>
//   <li><strong>Formatting:</strong> Use the toolbar above (bold, italic, underline, lists).</li>
//   <li><strong>Links & Images:</strong> Click the link or image icons to insert.</li>
//   <li><strong>Code & Tables:</strong> Insert rows/cols with the +Row / +Col buttons.</li>
//   <li><strong>Tasks:</strong> Type <code>[]</code> or use the task list button for checkboxes.</li>
// </ul>
// <h2>Pages & Folders</h2>
// <ul>
//   {/* Sidebar reference removed */}
//   <li>Drag & drop pages to reorder or move them into folders.</li>
//   <li>Double‑click a title in the tree to rename.</li>
// </ul>
// <h2>Search & History</h2>
// <ul>
//   <li>Press <kbd>Ctrl</kbd>/<kbd>Cmd</kbd>+<kbd>K</kbd> to search across pages.</li>
//   <li>Version history captures snapshots every minute; open the clock icon to restore.</li>
// </ul>
// <h2>Comments</h2>
// <p>Select text and use the comment icon to leave contextual feedback.</p>
// <h2>Next Steps</h2>
// <ol>
//   <li>Create a "Roadmap" folder and add pages inside.</li>
//   <li>Draft your first specification in a new page.</li>
//   <li>Explore dark mode with the toggle in the top right.</li>
// </ol>
// <p>Happy documenting! 🎉</p>
// `
//     const firstId = createDoc(merged,'root','Welcome', welcomeHtml)
//     console.log('[init] created starter doc', firstId)
//     }
//   // After local bootstrap, kick off remote bootstrap (non-blocking)
//   // Remote bootstrap & sync removed (GitHub disabled)
// })()

const Root = () => (
  <BrowserRouter basename={import.meta.env.BASE_URL || '/'}>
    {/* Global blocking loader visible across routes (includes /login) */}
    <BlockingLoader />
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/*" element={<App />} />
    </Routes>
  </BrowserRouter>
)

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode><Root /></React.StrictMode>
)
