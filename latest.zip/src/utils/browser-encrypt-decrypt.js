// browser-encrypt-decrypt.js
// Example: AES-GCM encryption/decryption in the browser using Web Crypto API
// Usage: Paste into your browser console or use in a frontend JS file

async function generateKey() {
  return await window.crypto.subtle.generateKey(
    { name: 'AES-GCM', length: 256 },
    true,
    ['encrypt', 'decrypt']
  );
}

async function encryptText(plainText, key) {
  const enc = new TextEncoder();
  const iv = window.crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await window.crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    key,
    enc.encode(plainText)
  );
  return { ciphertext: new Uint8Array(ciphertext), iv };
}

async function decryptText(ciphertext, iv, key) {
  const dec = new TextDecoder();
  const plainBuffer = await window.crypto.subtle.decrypt(
    { name: 'AES-GCM', iv },
    key,
    ciphertext
  );
  return dec.decode(plainBuffer);
}

// Example usage:
// (async () => {
//   const key = await generateKey();
//   const { ciphertext, iv } = await encryptText('my secret message', key);
//   const decrypted = await decryptText(ciphertext, iv, key);
//   console.log('Decrypted:', decrypted);
// })();

export { generateKey, encryptText, decryptText };
