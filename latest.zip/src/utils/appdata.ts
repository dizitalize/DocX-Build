// Central Appdata manager (TypeScript)
// Maintains all app-level data in a single structure for easy migration and sync.

export interface AppData {
  index: any[];
  docs: Record<string, any>;
  comments: Record<string, any>;
  history: Record<string, any>;
  users?: Record<string, any>;
  syncMeta: { lastSync: string | null; dirty: boolean };
}

// Legacy/localStorage keys (kept for migration/compatibility)
const APPDATA_KEY = 'Appdata';
const INDEX_KEY = 'docsIndex';
const DOC_PREFIX = 'doc:';
const COMMENTS_PREFIX = 'comments:';
const HISTORY_PREFIX = 'history:';
const USERS_KEY = 'usersMap';

// When true, app operates in remote-first mode: reads come from GitHub bootstrap
// and localStorage writes for appdata are disabled. This keeps appdata authoritative
// on the remote repo. Change to `false` to re-enable local persistence.
const REMOTE_ONLY = true;

export function isRemoteOnly(): boolean {
  return REMOTE_ONLY;
}

// In-memory cache so `loadAppdata()` can remain synchronous for callers.
let cachedApp: AppData | null = null;

// Build AppData from legacy per-key storage (docsIndex + per-doc keys)
function buildFromLegacy(): AppData {
  const legacyIndexRaw = localStorage.getItem(INDEX_KEY);
  let indexTree: any[];
  if (legacyIndexRaw) {
    try {
      indexTree = JSON.parse(legacyIndexRaw);
    } catch {
      indexTree = [{ id: 'root', type: 'folder', title: 'Pages', children: [] }];
    }
  } else {
    indexTree = [{ id: 'root', type: 'folder', title: 'Pages', children: [] }];
  }
  const docs: Record<string, any> = {};
  const collectDocs = (nodes: any[]): void => {
    for (const n of nodes) {
      if (n.type === 'doc') {
        const local = localStorage.getItem(`${DOC_PREFIX}${n.id}`);
        if (local) {
          try {
            const data = JSON.parse(local);
            const content = sanitizeContent(data.content || n.initial?.content || '');
            docs[n.id] = {
              title: data.title || n.title || 'Untitled Page',
              content,
              updatedAt: data.updatedAt || null,
              lastEditedBy: data.lastEditedBy || getDisplayName() || 'Unknown',
              modifiedBy: data.modifiedBy || data.lastEditedBy || getDisplayName() || 'Unknown',
            };
          } catch {
            docs[n.id] = {
              title: n.title || 'Untitled Page',
              content: sanitizeContent(n.initial?.content || '<p>Start writing&hellip;</p>'),
              updatedAt: null,
              lastEditedBy: getDisplayName() || 'Unknown',
              modifiedBy: getDisplayName() || 'Unknown',
            };
          }
        } else {
          docs[n.id] = {
            title: n.title || 'Untitled Page',
            content: sanitizeContent(n.initial?.content || '<p>Start writing&hellip;</p>'),
            updatedAt: null,
            lastEditedBy: getDisplayName() || 'Unknown',
            modifiedBy: getDisplayName() || 'Unknown',
          };
        }
      }
      if (n.children) collectDocs(n.children);
    }
  };
  collectDocs(indexTree);
  const history: Record<string, any[]> = {};
  for (const id of Object.keys(docs)) {
    try{ history[id] = JSON.parse(localStorage.getItem(`${HISTORY_PREFIX}${id}`) || '[]') }catch(e){ history[id] = [] }
  }
  const comments: Record<string, any> = {}
  for(const id of Object.keys(docs)){
    try{ comments[id] = JSON.parse(localStorage.getItem(`${COMMENTS_PREFIX}${id}`) || '{}') }catch(e){ comments[id] = {} }
  }
  const usersMap = (()=>{ try{ return JSON.parse(localStorage.getItem(USERS_KEY) || '{}') }catch(e){ return {} } })()
  return { index: indexTree, docs, syncMeta: { lastSync: new Date().toISOString(), dirty: false }, comments, history, users: usersMap }
}

// Load the unified AppData into memory. Prefer per-key storage; migrate from legacy unified key if found.
export function loadAppdata(): AppData {
  // If cached from bootstrap (remote), return that
  if (cachedApp) return cachedApp

  // If not in remote-only mode and per-key index exists, rebuild from local per-key store
  if (!REMOTE_ONLY && localStorage.getItem(INDEX_KEY)){
    const l = buildFromLegacy()
    cachedApp = l
    return l
  }

  // If not remote-only and unified legacy key exists, parse and migrate
  if (!REMOTE_ONLY){
    const raw = localStorage.getItem(APPDATA_KEY)
    if(raw){
      try{
        const parsed = JSON.parse(raw) as AppData
        parsed.index = parsed.index || [{ id:'root', type:'folder', title:'Pages', children: [] }]
        parsed.docs = parsed.docs || {}
        parsed.comments = parsed.comments || {}
        parsed.history = parsed.history || {}
        parsed.users = parsed.users || {}
        parsed.syncMeta = parsed.syncMeta || { lastSync: new Date().toISOString(), dirty: false }
        try{ saveAppdata(parsed) }catch(e){}
        cachedApp = parsed
        return parsed
      }catch(e){ }
    }
  }

  // Remote-only or fallback: return an empty base structure (will be filled by bootstrapFromGit)
  const base: AppData = { index:[{ id:'root', type:'folder', title:'Pages', children: [] }], docs:{}, comments:{}, history:{}, users:{}, syncMeta:{ lastSync:null, dirty:false } }
  cachedApp = base
  return base
}

// Save AppData — persist index and each doc/comment/history individually to localStorage
export function saveAppdata(appdata: AppData){
  // In remote-first mode we avoid writing the full Appdata to localStorage.
  // Keep an in-memory cache and emit update events so the UI can react.
  cachedApp = appdata
  if (REMOTE_ONLY){
    try { console.log('[Appdata] updated (remote-only cache)', appdata) } catch(e){}
    try { window.dispatchEvent(new CustomEvent('appdata-updated', { detail: appdata })) } catch(e){}
    return
  }

  try{
    // Save index as a single structure for tree rendering
    localStorage.setItem(INDEX_KEY, JSON.stringify(appdata.index || []))
    // Persist each doc individually
    for(const id of Object.keys(appdata.docs || {})){
      try{ localStorage.setItem(`${DOC_PREFIX}${id}`, JSON.stringify({ title: appdata.docs[id].title || '', content: appdata.docs[id].content || '', updatedAt: appdata.docs[id].updatedAt || null, lastEditedBy: appdata.docs[id].lastEditedBy || '' })) }catch(e){}
    }
      // Persist modifiedBy if present
      for(const id of Object.keys(appdata.docs || {})){
        try{
          const existingRaw = localStorage.getItem(`${DOC_PREFIX}${id}`)
          const existing = existingRaw ? JSON.parse(existingRaw) : {}
          const toSave = { ...existing, modifiedBy: appdata.docs[id].modifiedBy || existing.modifiedBy || appdata.docs[id].lastEditedBy || '' }
          localStorage.setItem(`${DOC_PREFIX}${id}`, JSON.stringify({ title: appdata.docs[id].title || '', content: appdata.docs[id].content || '', updatedAt: appdata.docs[id].updatedAt || null, lastEditedBy: appdata.docs[id].lastEditedBy || '', modifiedBy: toSave.modifiedBy }))
        }catch(e){}
      }
    // Persist comments and history per-doc
    for(const id of Object.keys(appdata.comments || {})){
      try{ localStorage.setItem(`${COMMENTS_PREFIX}${id}`, JSON.stringify(appdata.comments[id] || {})) }catch(e){}
    }
    for(const id of Object.keys(appdata.history || {})){
      try{ localStorage.setItem(`${HISTORY_PREFIX}${id}`, JSON.stringify(appdata.history[id] || [])) }catch(e){}
    }
    // persist users map if present
    try{ localStorage.setItem(USERS_KEY, JSON.stringify(appdata.users || {})) }catch(e){}
    // keep legacy unified key as a fast fallback but do not rely on it
    try{ localStorage.setItem(APPDATA_KEY, JSON.stringify({ index: appdata.index, syncMeta: appdata.syncMeta })) }catch(e){}
  }catch(e){
    // best effort — ignore errors
  }

  try { console.log('[Appdata] saved (per-key)', appdata) } catch(e){}
  try { console.log('[Appdata:index data]', appdata.index) } catch(e){}
  try { window.dispatchEvent(new CustomEvent('appdata-updated', { detail: appdata })) } catch(e){}
}

export function markDirty(appdata: AppData){ appdata.syncMeta = appdata.syncMeta || { lastSync: null, dirty: false }; appdata.syncMeta.dirty = true }

// Explicit helper if manual re-print needed elsewhere
export function logIndexData(appdata: AppData){
  try { console.log('[Appdata:index data]', appdata.index) } catch(e){}
}

// mutation helpers
export function createDoc(app: AppData, parentFolderId: string, title='Untitled Page', content='<p>Start writing 26hellip;</p>'){
  const id = 'doc-' + Date.now()
    app.docs[id] = { title, content, updatedAt: new Date().toISOString(), lastEditedBy: 'System', modifiedBy: 'System' }
  app.comments[id] = {}
  app.history[id] = []
  const parent = findNode(app.index, parentFolderId) || app.index[0]
  parent.children = parent.children || []
  parent.children.push({ id, type:'doc', title, initial:null })
  markDirty(app); saveAppdata(app)
  try{ console.log('[Appdata:createDoc] Created doc', { id, title, parent: parentFolderId, contentPreview: content.slice(0,40) }) }catch{}
  return id
}
export function createFolder(app: AppData, parentFolderId: string, title='New Folder'){
  const id = 'folder-' + Date.now()
  const parent = findNode(app.index, parentFolderId) || app.index[0]
  parent.children = parent.children || []
  parent.children.push({ id, type:'folder', title, children: [] })
  markDirty(app); saveAppdata(app)
  try{ console.log('[Appdata:createFolder] Created folder', { id, title, parent: parentFolderId }) }catch{}
  return id
}
export function renameNode(app: AppData, id: string, title: string){
  const node = findNode(app.index, id); if(!node) return false
  node.title = title
  if(node.type==='doc' && app.docs[id]) app.docs[id].title = title
  markDirty(app); saveAppdata(app)
  try{ console.log('[Appdata:renameNode] Renamed node', { id, newTitle: title, type: node.type }) }catch{}
  return true
}
export function deleteNode(app: AppData, id: string){
  const removed = removeNode(app.index, id)
  if(!removed) return false
  const collect=(n:any)=>{ if(n.type==='doc'){ delete app.docs[n.id]; delete app.comments[n.id]; delete app.history[n.id]; try{ localStorage.removeItem(`${DOC_PREFIX}${n.id}`); localStorage.removeItem(`${COMMENTS_PREFIX}${n.id}`); localStorage.removeItem(`${HISTORY_PREFIX}${n.id}`) }catch(e){} } if(n.children) n.children.forEach(collect) }
  collect(removed)
  markDirty(app); saveAppdata(app)
  try{ console.log('[Appdata:deleteNode] Deleted node', { id, type: removed.type, title: removed.title }) }catch{}
  return true
}
import { getDisplayName } from './users';
export function updateDocContent(app: AppData, id: string, content: string, user=getDisplayName() || 'Unknown'){
  if(!app.docs[id]) return false
  app.docs[id].content = content
  app.docs[id].updatedAt = new Date().toISOString()
    app.docs[id].lastEditedBy = user
    app.docs[id].modifiedBy = user
  markDirty(app); saveAppdata(app)
  try{ console.log('[Appdata:updateDocContent] Updated doc', { id, by: user, contentLength: content.length }) }catch{}
  return true
}
export function addCommentEntry(app: AppData, docId: string, blockId: string, comment: any){
  app.comments[docId] = app.comments[docId] || {}
  app.comments[docId][blockId] = app.comments[docId][blockId] || []
  app.comments[docId][blockId].push({ id: Date.now().toString(), ts: Date.now(), ...comment })
  markDirty(app); saveAppdata(app)
  try{ console.log('[Appdata:addCommentEntry] Added comment', { docId, blockId, author: comment?.author, textPreview: String(comment?.text||'').slice(0,40) }) }catch{}
  return true
}
export function pushHistoryEntry(app: AppData, docId: string, snapshot: any){
  app.history[docId] = app.history[docId] || []
  app.history[docId].unshift({ ...snapshot, ts: Date.now() })
  app.history[docId] = app.history[docId].slice(0,50)
  markDirty(app); saveAppdata(app)
  try{ console.log('[Appdata:pushHistoryEntry] History snapshot added', { docId, snapshotKeys: Object.keys(snapshot||{}), total: app.history[docId].length }) }catch{}
  return true
}

export function upsertUser(app: AppData, user: any){
  if(!user) return false
  const key = user.id || user.email || user.username || ('user-'+Date.now())
  app.users = app.users || {}
  app.users[key] = { ...user, id: key, updatedAt: new Date().toISOString() }
  markDirty(app); saveAppdata(app)
  try{ console.log('[Appdata:upsertUser] Upserted user', { key, fields: Object.keys(user||{}) }) }catch{}
  return key
}

// internal helpers
function findNode(tree: any[], id: string): any | null { for(const n of tree){ if(n.id===id) return n; if(n.children){ const f = findNode(n.children,id); if(f) return f } } return null }
function removeNode(tree: any[], id: string): any | null { for(let i=0;i<tree.length;i++){ const n=tree[i]; if(n.id===id){ tree.splice(i,1); return n } if(n.children){ const r=removeNode(n.children,id); if(r) return r } } return null }

// ...existing code...

function getLocalUserId(){ const u = JSON.parse(localStorage.getItem('currentUser')||'{}'); return u.id || u.email || 'anonymous' }

export function saveUsersMap(app: AppData, usersMap: Record<string, any>){ app.users = { ...(usersMap||{}) }; markDirty(app); saveAppdata(app) }

// sanitize content loaded from legacy localStorage or accidental file paths
export function sanitizeContent(raw: string | null | undefined){
  if (!raw) return '<p>No content.</p>'
  const s = String(raw).trim()
  // if content looks like a Windows temp ScreenClip path or raw file path, replace
  const winPathPattern = /^[a-zA-Z]:(\\|\/).+\.(png|jpg|jpeg|gif|bmp|webp)$/i
  const tempScreenClip = /ScreenClip[\\/].+\.(png|jpg|jpeg|gif|bmp|webp)$/i
  if (winPathPattern.test(s) || tempScreenClip.test(s) || s.startsWith('file:///')){
    return '<p>[Image or local file detected \u2014 content not embedded]</p>'
  }
  // if it seems to be only a filename (no tags) and short, treat as placeholder
  if (!s.includes('<') && s.length < 260 && /\.(png|jpg|jpeg|gif|bmp|webp)$/i.test(s)){
    return '<p>[Image reference removed]</p>'
  }
  return s
}

// sanitize all docs in Appdata (in-place) and persist changes
export function sanitizeAllDocs(){
  try{
    const app = loadAppdata()
    let changed = false
    for(const id of Object.keys(app.docs||{})){
      const cur = app.docs[id]
      const safe = sanitizeContent(cur?.content)
      if (String(cur?.content || '') !== String(safe)){
        app.docs[id].content = safe
        // also update per-doc legacy key to keep parity
        try{ localStorage.setItem(`${DOC_PREFIX}${id}`, JSON.stringify({ title: cur.title || '', content: safe, updatedAt: cur.updatedAt || null, lastEditedBy: cur.lastEditedBy || '' })) }catch(e){}
        changed = true
      }
    }
    if (changed) saveAppdata(app)
    return changed
  }catch(e){ console.warn('[appdata] sanitizeAllDocs failed', e); return false }
}

// Bootstrap appdata by fetching index and docs from a GitHub repository using the contents API.
// ownerRepo: e.g. 'Dizitalize/DocX'  (owner/repo)
// ref: branch or tag name, e.g. 'main'
export async function bootstrapFromGit(ownerRepo = 'Dizitalize/DocX', ref = 'main'){
  const apiBase = `https://api.github.com/repos/${ownerRepo}/contents`
  try{
    // fetch index.json from repo root
    const idxRes = await fetch(`${apiBase}/index.json?ref=${ref}`, { cache: 'no-store' })
    if(!idxRes.ok) throw new Error('Failed to fetch index.json')
    const idxJson = await idxRes.json()
    const idxRaw = typeof idxJson.content === 'string' ? atob(String(idxJson.content).replace(/\n/g,'')) : null
    const index = idxRaw ? JSON.parse(idxRaw) : (Array.isArray(idxJson) ? idxJson : [{ id:'root', type:'folder', title:'Pages', children: [] }])

    const docs: Record<string, any> = {}
    const comments: Record<string, any> = {}
    const history: Record<string, any[]> = {}

    // Helper to recursively collect doc nodes from index
    const collectDocNodes = (nodes:any[])=>{
      for(const n of nodes || []){
        if(n.type === 'doc'){
          const id = n.id
          docs[id] = { title: n.title || 'Untitled Page', content: sanitizeContent(n.initial?.content || '<p>Start writing 26hellip;</p>'), updatedAt: null, lastEditedBy: 'System' }
        }
        if(n.children) collectDocNodes(n.children)
      }
    }
    collectDocNodes(index)

    // Fetch per-doc JSON from docs/<id>.json if present
    for(const id of Object.keys(docs)){
      try{
        const r = await fetch(`${apiBase}/docs/${id}.json?ref=${ref}`, { cache: 'no-store' })
        if(!r.ok) continue
        const data = await r.json()
        const raw = typeof data.content === 'string' ? atob(String(data.content).replace(/\n/g,'')) : null
        const parsed = raw ? JSON.parse(raw) : (data && data.content ? data.content : null)
        if(parsed){
          docs[id].title = parsed.title || docs[id].title
          // if parsed.content is full HTML or string, use; else if parsed.body/content nested, adapt
          docs[id].content = sanitizeContent(parsed.content || parsed.body || parsed.html || docs[id].content)
          docs[id].updatedAt = parsed.updatedAt || parsed.updated_at || null
          docs[id].lastEditedBy = parsed.lastEditedBy || parsed.last_edited_by || docs[id].lastEditedBy
          docs[id].modifiedBy = parsed.modifiedBy || parsed.modified_by || docs[id].lastEditedBy
        }
      }catch(e){ /* ignore per-doc fetch errors */ }
      // attempt to fetch comments and history for each doc
      try{
        const cRes = await fetch(`${apiBase}/comments/${id}.json?ref=${ref}`, { cache: 'no-store' })
        if(cRes.ok){ const cJson = await cRes.json(); const cRaw = typeof cJson.content === 'string' ? atob(String(cJson.content).replace(/\n/g,'')) : null; comments[id] = cRaw ? JSON.parse(cRaw) : {} }
      }catch(e){}
      try{
        const hRes = await fetch(`${apiBase}/history/${id}.json?ref=${ref}`, { cache: 'no-store' })
        if(hRes.ok){ const hJson = await hRes.json(); const hRaw = typeof hJson.content === 'string' ? atob(String(hJson.content).replace(/\n/g,'')) : null; history[id] = hRaw ? JSON.parse(hRaw) : [] }
      }catch(e){}
    }

    const usersMap = {}
    const app: AppData = { index, docs, comments, history, users: usersMap, syncMeta: { lastSync: new Date().toISOString(), dirty: false } }
    saveAppdata(app)
    try{ console.log('[Appdata] bootstrapped from Git', ownerRepo, ref, app) }catch(e){}
    return app
  }catch(e){
    console.warn('[Appdata] bootstrapFromGit failed', e)
    throw e
  }
}
