
// Single-file folder/page aggregate syncing (TypeScript version)
// root.json schema: FolderEntry[]

export interface PageEntry {
  id: string;
  title: string;
  createdAt: string;
  modifiedAt: string;
  createdBy: string;
}

export interface FolderEntry {
  id: string;
  type: 'folder';
  path: string;
  title: string;
  createdAt: string;
  modifiedAt: string;
  createdBy: string;
  pages: PageEntry[];
}

// GitHub integration disabled for remoteFolders — local-only aggregate

import { isRemoteOnly } from './appdata';
import { getCurrentUser } from './users';

function getUserId(): string {
  try {
    const u = getCurrentUser() || {};
    return u.id || u.email || u.name || 'anonymous';
  } catch {
    return 'anonymous';
  }
}

/**
 * Ensure there is a local root.json entry (noop in remote-only mode).
 */
export async function ensureRoot(): Promise<void> {
  try {
    if (!isRemoteOnly() && !localStorage.getItem('root.json')) {
      localStorage.setItem('root.json', JSON.stringify([]));
    }
  } catch (e) {
    console.warn('[remoteFolders] ensureRoot local failed', e);
  }
}

/**
 * Slugify a folder title for use in paths.
 */
export function slugify(title: string): string {
  return (title || 'folder').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'folder';
}

function buildAggregateFromIndex(index: any[]): FolderEntry[] {
  const entries: FolderEntry[] = [];
  function walk(nodes: any[], pathParts: string[]): void {
    for (const n of nodes) {
      if (n.type === 'folder') {
        const slug = slugify(n.title);
        const currentPathParts = [...pathParts, slug];
        const path = 'root' + (currentPathParts.length ? '/' + currentPathParts.join('/') : '');
        const pages: PageEntry[] = (n.children || [])
          .filter((c: any) => c.type === 'doc')
          .map((c: any) => ({
            id: c.id,
            title: c.title,
            createdAt: new Date().toISOString(),
            modifiedAt: new Date().toISOString(),
            createdBy: getUserId(),
          }));
        entries.push({
          id: n.id,
          type: 'folder',
          path,
          title: n.title,
          createdAt: new Date().toISOString(),
          modifiedAt: new Date().toISOString(),
          createdBy: getUserId(),
          pages,
        });
        walk((n.children || []).filter((c: any) => c.type === 'folder'), currentPathParts);
      }
    }
  }
  walk(index, []);
  return entries;
}


/**
 * Update the local root.json tree from the given index.
 */
export async function updateRootTree(index: any[]): Promise<void> {
  try {
    const aggregate = buildAggregateFromIndex(index);
    // write local cache only when not remote-only
    if (!isRemoteOnly()) localStorage.setItem('root.json', JSON.stringify(aggregate));
    try {
      window.dispatchEvent(new CustomEvent('root-updated', { detail: aggregate }));
    } catch {}
  } catch (e) {
    console.warn('[remoteFolders] updateRootTree local failed', e);
  }
}

/**
 * Read the local root.json aggregate.
 */
export function readRootAggregate(): any[] {
  try {
    const raw = localStorage.getItem('root.json');
    if (raw) return JSON.parse(raw);
  } catch {}
  return [];
}
