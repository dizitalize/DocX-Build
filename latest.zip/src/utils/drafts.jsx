// Draft utilities (React + localStorage)
// Provides helper functions for local draft autosave management and badge display.
// Drafts are stored locally in localStorage under key `draftAutosave:<docId>` and
// remotely under `drafts/<docId>.json` via remoteSync when queued.

const _drafts = new Map()
export function getDraftKey(docId){ return `draftAutosave:${docId}` }

export function hasLocalDraft(docId){ try{ const v = _drafts.get(getDraftKey(docId)); return !!(v && String(v).trim().length>0) }catch{ return false } }
export function getLocalDraft(docId){ try{ return _drafts.get(getDraftKey(docId)) || null }catch{ return null } }
export function saveLocalDraft(docId, html){ try{ _drafts.set(getDraftKey(docId), String(html)) }catch{} }
export function clearLocalDraft(docId){ try{ _drafts.delete(getDraftKey(docId)) }catch{} }

export function DraftBadge({ docId }){
  if(!hasLocalDraft(docId)) return null
  return (
    <span className="ml-2 inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 border border-amber-300 text-amber-700 rounded bg-amber-50 dark:bg-[#2B1B00] dark:border-amber-600 dark:text-amber-300">
      Draft saved
    </span>
  )
}
