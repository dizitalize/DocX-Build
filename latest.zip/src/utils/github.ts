// --- PAT Decryption Utility ---
import crypto from 'crypto';
import fs from 'fs';

/**
 * Decrypts the Personal Access Token (PAT) from pat.enc using the key from pat.key or PAT_DEC_KEY env.
 * Returns the decrypted PAT as a string (in memory only).
 */
export function getDecryptedPAT(): string {
  // Try env first, fallback to file
  const keyHex = process.env.PAT_DEC_KEY || fs.readFileSync('pat.key', 'utf8').trim();
  const enc = JSON.parse(fs.readFileSync('pat.enc', 'utf8'));

  const key = Buffer.from(keyHex, 'hex');
  const iv = Buffer.from(enc.iv, 'hex');
  const tag = Buffer.from(enc.tag, 'hex');

  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(tag);

  let decrypted = decipher.update(enc.data, 'hex', 'utf8');
  decrypted += decipher.final('utf8');

  return decrypted;
}
// --- Index Tree Types ---
type IndexNode = {
  id: string;
  type: 'folder' | 'doc';
  title: string;
  active?: boolean;
  children?: IndexNode[];
  [key: string]: any;
};

// Utility: Recursively ensure all nodes have 'active' boolean and remove local-only nodes not in remote
function normalizeIndexTree(tree: IndexNode[], remoteTree: IndexNode[]): IndexNode[] {
  // Build a set of all remote node ids for pruning
  const remoteIds = new Set<string>();
  function collectIds(nodes: IndexNode[] = []) {
    for (const n of nodes) {
      remoteIds.add(n.id);
      if (n.children) collectIds(n.children);
    }
  }
  collectIds(remoteTree || []);

  function normalize(nodes: IndexNode[] = [], remoteNodes: IndexNode[] = []): IndexNode[] {
    return nodes.filter((n) => remoteIds.has(n.id)).map((n) => {
      const remoteNode = (remoteNodes || []).find((rn) => rn.id === n.id);
      const base: IndexNode = { ...n, active: typeof n.active === 'boolean' ? n.active : true };
      if (base.children) {
        base.children = normalize(base.children, remoteNode ? remoteNode.children : []);
      }
      return base;
    });
  }
  return normalize(tree, remoteTree);
}

// Utility: Recursively update only the 'active' boolean in the remote tree from local tree
function mergeActiveOnly(remoteTree: IndexNode[], localTree: IndexNode[]): IndexNode[] {
  function merge(remoteNodes: IndexNode[] = [], localNodes: IndexNode[] = []): IndexNode[] {
    return (remoteNodes || []).map((rn) => {
      const ln = (localNodes || []).find((n) => n.id === rn.id);
      const merged: IndexNode = { ...rn };
      if (ln && typeof ln.active === 'boolean') merged.active = ln.active;
      if (rn.children) merged.children = merge(rn.children, ln ? ln.children : []);
      return merged;
    });
  }
  return merge(remoteTree, localTree);
}

// Utility: Ensure root node structure
function ensureRootNode(tree: IndexNode[]): IndexNode[] {
  if (!Array.isArray(tree)) return [{ id: 'root', type: 'folder', title: 'Pages', active: true, children: [] }];
  if (tree.length === 1 && tree[0].id === 'root' && Array.isArray(tree[0].children)) {
    // Already correct
    return [{ ...tree[0], active: typeof tree[0].active === 'boolean' ? tree[0].active : true, children: ensureActive(tree[0].children) }];
  }
  // Wrap in root if missing
  return [{ id: 'root', type: 'folder', title: 'Pages', active: true, children: ensureActive(tree) }];
}

// Utility: Recursively add 'active' true to all nodes if missing
function ensureActive(nodes: IndexNode[] = []): IndexNode[] {
  return nodes.map((n) => {
    const base: IndexNode = { ...n, active: typeof n.active === 'boolean' ? n.active : true };
    if (base.children) base.children = ensureActive(base.children);
    return base;
  });
}

// Smart upsert for index.json: only update 'active' in remote, never overwrite structure
export async function smartUpsertIndex(localIndex: IndexNode[]): Promise<{ ok: boolean; skipped?: boolean; reason?: string }> {
  // Always enforce root node and active keys
  const localTree = ensureRootNode(ensureActive(localIndex));
  const remoteRes = await getFile('index.json');
  const remoteTree = ensureRootNode(ensureActive(remoteRes?.json || []));
  // Remove local-only nodes before merge
  const prunedLocal = normalizeIndexTree(localTree, remoteTree);
  // Only update 'active' in remote tree
  const merged = mergeActiveOnly(remoteTree, prunedLocal);
  // Only push if there are changes in 'active' flags
  if (JSON.stringify(remoteTree) !== JSON.stringify(merged)) {
    return await putFile('index.json', merged, remoteRes?.sha);
  } else {
    return { ok: true, skipped: true, reason: 'No changes in active flags' };
  }
}

import { API, REMOTE_OWNER, REMOTE_REPO, REMOTE_BRANCH, getToken, headers } from './remoteConfig';

import { GitHubService } from '../services/github/GitHubService';

export const getFile = GitHubService.getFile;
export const putFile = GitHubService.putFile;


export type GetFileResult = { json: any; sha?: string }

function dispatchSyncState(state: string){ try{ window.dispatchEvent(new CustomEvent('sync-state',{ detail: state })) }catch(e){} }
function dispatchBlocking(on: boolean){ try{ window.dispatchEvent(new CustomEvent('blocking-loader',{ detail: on })) }catch(e){} }






// Lock helpers removed — we no longer use lock files. Pushing updates goes directly to the target file.

export async function ensureFile(path: string, defaultJson: any): Promise<{ ok: boolean; sha?: string }>{
  const existing = await getFile(path)
  if(existing?.sha) return { ok:true, sha: existing.sha }
  const created = await putFile(path, defaultJson)
  return { ok: !!created.ok, sha: created.sha }
}

export async function upsertJson(path: string, dataFn: (prev: any | null)=>any): Promise<{ ok: boolean; sha?: string; reason?: string }>{
  try{
    const existing = await getFile(path)
    const prev = existing?.json ?? null
    const next = dataFn(prev)
  if(JSON.stringify(prev) === JSON.stringify(next)) return ({ ok:true, skipped:true, sha: existing?.sha } as any)
    const res = await putFile(path, next, existing?.sha)
    return res
  }catch(e){ console.warn('[github] upsertJson failed', e); return { ok:false, reason: String(e) } }
}

// Safe sync: receive the user's local JSON and the SHA they originally read (originalSha).
// Behavior:
// - If remote SHA === originalSha and local differs from remote -> push local
// - If remote SHA !== originalSha and local differs -> fetch remote, merge via mergeFn, push merged
// - If local identical to remote -> skip push
export async function safeSyncJson(path: string, localJson: any, originalSha?: string, mergeFn?: (remote: any, local: any)=>any): Promise<{ ok: boolean; skipped?: boolean; sha?: string; reason?: string }>{
  try{
    const remote = await getFile(path)
    const remoteJson = remote?.json ?? null
    const remoteSha = remote?.sha
    const isSameAsRemote = JSON.stringify(localJson) === JSON.stringify(remoteJson)
    if(isSameAsRemote) return { ok:true, skipped:true, sha: remoteSha }
    if(originalSha && remoteSha && originalSha === remoteSha){
      const res = await putFile(path, localJson, originalSha)
      return res
    }
    if(mergeFn){
      const merged = mergeFn(remoteJson, localJson)
      if(JSON.stringify(merged) === JSON.stringify(remoteJson)) return { ok:true, skipped:true, sha: remoteSha }
      const res = await putFile(path, merged, remoteSha)
      return res
    }
    return { ok:false, reason: 'remote changed; merge required' }
  }catch(e){ console.warn('[github] safeSyncJson failed', e); return { ok:false, reason: String(e) } }
}

// Create a new page file at a given path (e.g. docs/<id>.json). This will attempt to PUT the file
// and return the new sha. It uses putFile which already handles retries on 409.
export async function createPageFile(path: string, jsonObj: any): Promise<{ ok:boolean; sha?:string; reason?:string }>{
  try{
    const existing = await getFile(path)
    if(existing?.sha) return { ok:true, sha: existing.sha }
    const res = await putFile(path, jsonObj)
    return res
  }catch(e){ console.warn('[github] createPageFile failed', e); return { ok:false, reason: String(e) } }
}

export async function batchEnsure(files: Array<{ path: string; json: any }>): Promise<void>{
  for(const f of files){ try{ await ensureFile(f.path, f.json) }catch(e){ console.warn('[github] batchEnsure failed', f.path, e) } }
}

export function isRemoteEnabled(){ return !!getToken() }
export function notifyRemoteFailure(reason: string){ try{ window.dispatchEvent(new CustomEvent('remote-failure',{ detail: reason })) }catch(e){} }

// List directory entries (used to discover orphaned docs not referenced in index)
export async function listDirectory(path: string): Promise<string[]> {
  try {
    const res = await fetch(
      `${API}/repos/${REMOTE_OWNER}/${REMOTE_REPO}/contents/${path}?ref=${REMOTE_BRANCH}`,
      { headers: await headers(), cache: 'no-cache' }
    );
    if (!res.ok) {
      console.warn('[github] listDirectory failed', path, res.status);
      return [];
    }
    const data = await res.json();
    if (!Array.isArray(data)) return [];
    return data.filter(e => e.type === 'file').map(e => e.name);
  } catch (e) {
    console.warn('[github] listDirectory error', path, e);
    return [];
  }
}
// GitHub integration disabled.

// Verify stored token by calling GET /user — returns auth status and login when successful.
export async function verifyAuth(): Promise<{ ok: boolean; status: number; login?: string; message?: string }> {
  try {
    const res = await fetch(
      `${API}/user`,
      { headers: await headers(), cache: 'no-cache' }
    );
    const status = res.status;
    if (!res.ok) {
      const txt = await res.text();
      return { ok: false, status, message: txt };
    }
    const data = await res.json();
    return { ok: true, status, login: data.login };
  } catch (e) {
    return { ok: false, status: 0, message: String(e) };
  }
}
