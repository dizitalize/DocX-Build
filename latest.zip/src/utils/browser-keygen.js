// browser-keygen.js
// Generates an AES-GCM key, exports it as base64, and saves to localStorage or downloads as a file.

async function generateAndExportKey() {
  const key = await window.crypto.subtle.generateKey(
    { name: 'AES-GCM', length: 256 },
    true,
    ['encrypt', 'decrypt']
  );
  const rawKey = await window.crypto.subtle.exportKey('raw', key);
  const b64Key = btoa(String.fromCharCode(...new Uint8Array(rawKey)));
  // Save to localStorage
  localStorage.setItem('aesKey', b64Key);
  // Optionally, download as a file
  const blob = new Blob([b64Key], { type: 'text/plain' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'aes-key.txt';
  a.click();
  return b64Key;
}

// Usage example:
// (async () => {
//   const key = await generateAndExportKey();
//   console.log('Generated AES Key (base64):', key);
// })();

export { generateAndExportKey };
