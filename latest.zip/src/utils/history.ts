import { loadAppdata, saveAppdata, markDirty } from './appdata';
import { queueDirtyHistory } from './remoteSync';

/**
 * Push a new snapshot to the document's history.
 * Keeps only the latest 50 snapshots.
 * @param docId - The document ID
 * @param snapshot - The snapshot object
 */
export function pushSnapshot(docId: string, snapshot: any): void {
  const app = loadAppdata();
  app.history[docId] = app.history[docId] || [];
  app.history[docId].unshift({ ...snapshot, ts: Date.now() });
  app.history[docId] = app.history[docId].slice(0, 50);
  markDirty(app);
  saveAppdata(app);
  queueDirtyHistory(docId);
}

/**
 * Get the history snapshots for a document.
 * @param docId - The document ID
 * @returns An array of snapshot objects
 */
export function getHistory(docId: string): any[] {
  const app = loadAppdata();
  return app.history[docId] || [];
}
