
// Remote sync: single-worker serialized queue with synchronous enqueue API.
// Callers (UI code) can call queueDirtyIndex()/queueDirtyDoc(id) synchronously.
// Internally we debounce per-resource and ensure only one network op runs at a time.

import { getFile, putFile, safeSyncJson, listDirectory, isRemoteEnabled } from './github';
import { loadAppdata, saveAppdata } from './appdata';

type Task = { resource: string; type: 'index' | 'doc'; id?: string };

const queue: Task[] = [];
const timers: Record<string, number> = {};
let isRunning = false;

const DEBOUNCE_MS = 7000; // 7 seconds buffer

function scheduleTask(t: Task): void {
	// If a timer is already running for this resource, clear it.
	if (timers[t.resource]) {
		clearTimeout(timers[t.resource]);
	}
	// Set a new timer.
	timers[t.resource] = setTimeout(() => {
		// When timer fires, add to the queue if not already present and run it.
		if (!queue.find(q => q.resource === t.resource)) {
			queue.push(t);
		}
		runQueue();
		delete timers[t.resource];
	}, DEBOUNCE_MS) as unknown as number;
}

// Public synchronous API
export function queueDirtyIndex(): void { /* now a no-op */ }
export function triggerIndexSync(): void { scheduleTask({ resource: 'index', type: 'index' }); }
export function queueDirtyDoc(id: string): void { scheduleTask({ resource: `doc:${id}`, type: 'doc', id }); }
export function queueDirtyComments(_id: string): void {}
export function queueDirtyHistory(_id: string): void {}
export function queueDirtyUsers(): void {}
export function queueDirtyDraft(_id: string): void {}

function wait(ms: number): Promise<void> { return new Promise(r => setTimeout(r, ms)); }

async function processTask(t: Task): Promise<void> {
	try {
		if (t.type === 'doc' && t.id) {
			await syncDoc(t.id);
		} else if (t.type === 'index') {
			await syncIndex();
		}
	} catch (e) { console.warn('[remoteSync] processTask failed', t, e); }
}

async function runQueue(): Promise<void> {
	if (isRunning) return;
	isRunning = true;
	while (queue.length) {
		const t = queue.shift()!;
		await processTask(t);
	}
	isRunning = false;
}

// Basic index merge: union by id with preservation of local children for touched nodes.
function mergeIndex(base: any[], local: any[], remote: any[]){
	// build maps
	const map = new Map()
		const pushNode = (n: any) => map.set(n.id, { ...n })
		;(remote||[]).forEach((n:any)=> pushNode(n))
		;(base||[]).forEach((n:any)=>{ if(!map.has(n.id)) pushNode(n) })
		;(local||[]).forEach((n:any)=> pushNode(n))
	// return as array preserving local order where possible
	const ids = new Set((local||[]).map(n=>n.id).concat((remote||[]).map(n=>n.id)))
	return Array.from(ids).map(id=> map.get(id))
}

async function syncIndex(){
	const app = loadAppdata()
	const localIndex = app.index || []
	if (!localIndex || localIndex.length === 0) {
		console.error('[remoteSync] syncIndex: local index is empty, aborting putFile. This should never happen!')
		return;
	}
	try{
		const remote = await getFile('index.json')
		console.debug('[remoteSync] syncIndex: isRemoteEnabled=', isRemoteEnabled())
	const remoteJson = remote ? ((typeof remote === 'object' && 'json' in remote) ? remote.json : (typeof remote === 'string' ? JSON.parse(remote) : remote)) : null
	const remoteSha = remote && typeof remote === 'object' && 'sha' in remote ? remote.sha : undefined
		if(!remoteJson){
				// remote missing: if remote writes disabled, keep local cache and emit event
				if(!isRemoteEnabled()){ try{ window.dispatchEvent(new CustomEvent('sync-skipped',{ detail: { resource:'index', reason: 'remote-writes-disabled' } })) }catch(e){}
					app.index = localIndex; saveAppdata(app); return }
				// otherwise create remote file
				console.debug('[remoteSync] creating remote index.json')
				const resCreate = await putFile('index.json', localIndex)
				console.debug('[remoteSync] putFile create result', resCreate)
				return
			}
		// normalize to arrays for merging
		const remoteArr = Array.isArray(remoteJson) ? remoteJson : (remoteJson && Array.isArray(remoteJson.index) ? remoteJson.index : [])
		const localArr = Array.isArray(localIndex) ? localIndex : []
		// simple conflict avoidance: if identical, skip
		if(JSON.stringify(remoteArr) === JSON.stringify(localArr)) return
		const merged = mergeIndex(remoteArr, localArr, remoteArr)
		console.log('[remoteSync] merged index to be saved:', merged)
		// push merged index if remote writes enabled; otherwise keep merged locally and emit event
		if(!isRemoteEnabled()){ try{ window.dispatchEvent(new CustomEvent('sync-skipped',{ detail: { resource:'index', reason: 'remote-writes-disabled', merged } })) }catch(e){}
				app.index = merged; saveAppdata(app); return }
		console.debug('[remoteSync] updating remote index.json')
		const resPut = await putFile('index.json', merged, remoteSha)
		console.debug('[remoteSync] putFile update result', resPut)
		// update local cache
		app.index = merged
		saveAppdata(app)
	}catch(e){ console.warn('[remoteSync] syncIndex failed', e) }
}

async function syncDoc(id: string){
	const app = loadAppdata()
	const localDoc = (app.docs||{})[id]
	if(!localDoc) return
	try{
		const remote = await getFile(`docs/${id}.json`)
	const remoteJson = remote ? ((typeof remote === 'object' && 'json' in remote) ? remote.json : (typeof remote === 'string' ? JSON.parse(remote) : remote)) : null
	const remoteSha = remote && typeof remote === 'object' && 'sha' in remote ? remote.sha : undefined
			if(!remoteJson){
				// create doc remotely; if remote writes disabled, keep local and emit
				if(!isRemoteEnabled()){ try{ window.dispatchEvent(new CustomEvent('sync-skipped',{ detail: { resource:`doc:${id}`, reason: 'remote-writes-disabled' } })) }catch(e){}
					app.docs[id] = localDoc; saveAppdata(app); return }
				const resCreate = await putFile(`docs/${id}.json`, localDoc)
				console.debug('[remoteSync] putFile create doc result', resCreate)
				return
			}
		// if identical, skip
		if(JSON.stringify(remoteJson) === JSON.stringify(localDoc)) return
		// naive merge: prefer local updatedAt if newer, else remote
		const localTs = new Date(localDoc.updatedAt || 0).getTime()
		const remoteTs = new Date(remoteJson.updatedAt || 0).getTime()
		const chosen = localTs >= remoteTs ? localDoc : remoteJson
			if(!isRemoteEnabled()){ try{ window.dispatchEvent(new CustomEvent('sync-skipped',{ detail: { resource:`doc:${id}`, reason: 'remote-writes-disabled', chosen } })) }catch(e){}
				app.docs[id] = chosen; saveAppdata(app); return }
		const resPutDoc = await putFile(`docs/${id}.json`, chosen, remoteSha)
		console.debug('[remoteSync] putFile update doc result', resPutDoc)
			// update local cache
			app.docs[id] = chosen
			saveAppdata(app)
	}catch(e){ console.warn('[remoteSync] syncDoc failed', id, e) }
}

export async function remoteBootstrap(){
	// no-op placeholder (bootstrap remains in appdata)
}

export async function flushRemote(){
	// process remaining queue synchronously
	while(queue.length){
		const t = queue.shift()!
		await processTask(t)
	}
}

export function hasDirty(){ return queue.length > 0 }
export function hasDraftDirty(){ return false }
export function isFlushing(){ return isRunning }
export async function fetchDocIfMissing(_docId: string){ return false }
