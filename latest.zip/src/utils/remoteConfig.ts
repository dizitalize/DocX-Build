/**
 * Debug utility: Print the extracted GitHub PAT key to the console.
 * Use ONLY for troubleshooting. Remove or disable in production.
 */
export async function printExtractedPAT(): Promise<void> {
  try {
    let pat: string | null = null;
    if (typeof getToken === 'function') {
      pat = await (getToken as any)();
    }
    // Fallback if getToken is not async
    if (!pat && typeof getToken === 'function') {
      pat = (getToken as any)();
    }
    // Print to console for debugging
    if (pat) {
      // Mask all but last 4 chars for safety
      const masked = pat.length > 8 ? pat.slice(0, 4) + '...' + pat.slice(-4) : pat;
      console.warn('[DEBUG] Extracted GitHub PAT:', masked);
    } else {
      console.warn('[DEBUG] No GitHub PAT extracted.');
    }
  } catch (e) {
    console.error('[DEBUG] Error extracting PAT:', e);
  }
}

// Remote configuration and helpers for GitHub API access.
// NOTE: Store tokens outside of source control for security.

export const API = 'https://api.github.com';
export const REMOTE_OWNER = 'Dizitalize';
export const REMOTE_REPO = 'DocX';
export const REMOTE_BRANCH = 'main';



// Reads the GitHub PAT from key.json (decrypted by a Node.js script, never in browser)

let cachedPAT: string | null = null;
export async function getToken(): Promise<string | null> {
  if (cachedPAT !== null) return cachedPAT;
  try {
    // Hardcoded encrypted PAT object
    const encObj = {
  "algorithm": "AES-256-GCM",
  "iterations": 200000,
  "salt": "Ei/WnQMaMqawearYfMcuKg==",
  "iv": "Sh2Pz5alGa+/9k3n",
  "tag": "HTsPbQ2BeBB6drDc03nJiA==",
  "data": "nNWfHmK5k5Fr2h6n2ZxIUBcka1OJn1/VcFL2/6vs1r+94PinC3piQKEstKAMk4zv1ysgQTuq1QEepwUB6jjqZ5v/6zWLfJgMJ0PNHPZQa8qmlwoPGlqqjLxi8sN+"
};
    // Hardcoded password (Docxv11)
    const password = 'Docxv11';
    // Decode base64 fields
    const salt = Uint8Array.from(atob(encObj.salt), c => c.charCodeAt(0));
    const iv = Uint8Array.from(atob(encObj.iv), c => c.charCodeAt(0));
    const tag = Uint8Array.from(atob(encObj.tag), c => c.charCodeAt(0));
    const data = Uint8Array.from(atob(encObj.data), c => c.charCodeAt(0));
    // Derive key using PBKDF2
    const keyMaterial = await window.crypto.subtle.importKey(
      'raw', new TextEncoder().encode(password), { name: 'PBKDF2' }, false, ['deriveKey']
    );
    const key = await window.crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt: salt,
        iterations: encObj.iterations,
        hash: 'SHA-256'
      },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      false,
      ['decrypt']
    );
    // Decrypt using AES-GCM
    const cipherBuffer = new Uint8Array([...data, ...tag]);
    const decrypted = await window.crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: iv, tagLength: 128 },
      key,
      cipherBuffer
    );
    cachedPAT = new TextDecoder().decode(decrypted);

    
    return cachedPAT;
  } catch (e) {
    console.error('[getToken] Decryption failed:', e);
    return null;
  }
}


// ...existing code...

/**
 * Get the headers for GitHub API requests, including Authorization if token is set.
 */
export async function headers(): Promise<Record<string, string>> {
  // Print the extracted PAT for every API call (debug only)
  if (typeof printExtractedPAT === 'function') {
    try { printExtractedPAT(); } catch {}
  }
  const token = await getToken();
  const h: Record<string, string> = { 'Accept': 'application/vnd.github.v3+json' };
  if (token) h['Authorization'] = `token ${token}`;
  return h;
}

/**
 * Encode an object or string as base64 (Unicode-safe).
 */
export function encodeContent(obj: any): string {
  try {
    const s = typeof obj === 'string' ? obj : JSON.stringify(obj);
    if (typeof (globalThis as any).btoa === 'function') {
      return (globalThis as any).btoa(unescape(encodeURIComponent(s)));
    }
  } catch {}
  return '';
}

/**
 * Decode a base64 string to an object (Unicode-safe).
 */
export function decodeContent(b64: string): any {
  try {
    if (typeof (globalThis as any).atob === 'function') {
      const str = decodeURIComponent(escape((globalThis as any).atob(b64)));
      return JSON.parse(str);
    }
  } catch {}
  return null;
}

export async function withRetry<T>(fn: ()=>Promise<T>, tag?: string, attempts = 3): Promise<T>{
  let i = 0
  while(true){
    try{ return await fn() }catch(e){
      i++
      if(i>=attempts) throw e
      await new Promise(r=>setTimeout(r, 150*i))
    }
  }
}


