// Simple XOR encryption for demonstration (not secure for production)
function xorEncrypt(str: string, key: string = 'docxkey'): string {
  return btoa(Array.from(str).map((c: string, i: number) => String.fromCharCode(c.charCodeAt(0) ^ key.charCodeAt(i % key.length))).join(''));
}
function xorDecrypt(str: string, key: string = 'docxkey'): string {
  try {
    return atob(str).split('').map((c: string, i: number) => String.fromCharCode(c.charCodeAt(0) ^ key.charCodeAt(i % key.length))).join('');
  } catch { return '' }
}

const DISPLAY_NAME_KEY = 'displayNameEnc';

export function setDisplayName(name: string) {
  if (!name) return;
  const enc = xorEncrypt(name);
  localStorage.setItem(DISPLAY_NAME_KEY, enc);
}

export function getDisplayName(): string {
  const enc = localStorage.getItem(DISPLAY_NAME_KEY);
  if (!enc) return '';
  return xorDecrypt(enc);
}

import { getFile as ghGetFile } from './github';

let cachedUsers: any[] | null = null;
let cachedCurrentUser: any = null;

const SESSION_KEY = 'currentUserSession';
const LAST_INTERACTION_KEY = 'lastInteraction';

// Attempt to restore persisted session (if any)
try {
  const raw = localStorage.getItem(SESSION_KEY);
  if (raw) {
    const parsed = JSON.parse(raw);
    if (parsed && parsed.user && parsed.expiresAt && Number(parsed.expiresAt) > Date.now()) {
      cachedCurrentUser = parsed.user;
    } else {
      localStorage.removeItem(SESSION_KEY);
    }
  }
} catch {
  // ignore
}

/**
 * Load the cached users array.
 */
export function loadUsers(): any[] {
  return cachedUsers || [];
}

/**
 * Fetch users from the remote users.json file.
 */
export async function fetchRemoteUsers(): Promise<any[]> {
  try {
    const raw = await ghGetFile('users.json');
    if (!raw) return (cachedUsers = [] as any[]);
    // ghGetFile now returns { json, sha } or a decoded string; handle both
    let parsed = null;
    if (raw && typeof raw === 'object' && 'json' in raw) {
      parsed = raw.json;
    } else {
      try {
        parsed = JSON.parse(typeof raw === 'string' ? raw : String(raw));
      } catch {
        parsed = null;
      }
    }
    if (Array.isArray(parsed)) {
      cachedUsers = parsed;
      try {
        window.dispatchEvent(new CustomEvent('users-updated'));
      } catch {}
      return cachedUsers;
    }
    // If the remote file is an object map (username -> user), convert to array
    if (parsed && typeof parsed === 'object') {
      try {
        cachedUsers = Object.values(parsed);
      } catch {
        cachedUsers = [];
      }
      try {
        window.dispatchEvent(new CustomEvent('users-updated'));
      } catch {}
      return cachedUsers;
    }
    // Fallback: empty array
    return (cachedUsers = []);
  } catch (e) {
    console.warn('[users] fetchRemoteUsers failed', e);
    return (cachedUsers = []);
  }
}

/**
 * Save the users array to the cache and emit an update event.
 */
export function saveUsers(list: any[]): void {
  // In remote-only runtime we avoid persisting users locally. Keep cache and emit event.
  cachedUsers = list;
  try {
    window.dispatchEvent(new CustomEvent('users-updated'));
  } catch {}
}

/**
 * Update a user by username with a patch object.
 */
export function updateUser(username: string, patch: any): boolean {
  const users = loadUsers();
  const idx = users.findIndex(u => u.username === username);
  if (idx === -1) return false;
  users[idx] = { ...users[idx], ...patch };
  saveUsers(users);
  return true;
}

/**
 * Get the current user from cache.
 */
export function getCurrentUser(): any {
  return cachedCurrentUser;
}

/**
 * Set the current user and persist the session for a given duration (default 3 hours).
 */
export function setCurrentUser(user: any, durationMs = 1000 * 60 * 60 * 3): void {
  cachedCurrentUser = user;
  try {
    window.dispatchEvent(new CustomEvent('current-user-updated'));
  } catch {}
  try {
    if (user) {
      const expiresAt = Date.now() + Number(durationMs || 0);
      localStorage.setItem(SESSION_KEY, JSON.stringify({ user, expiresAt }));
      // initialize last interaction timestamp
      localStorage.setItem(LAST_INTERACTION_KEY, String(Date.now()));
    } else {
      localStorage.removeItem(SESSION_KEY);
      localStorage.removeItem(LAST_INTERACTION_KEY);
    }
  } catch {
    // ignore write failures
  }
}

/**
 * Extend the current session by a given duration (default 3 hours).
 */
export function extendSession(durationMs = 1000 * 60 * 60 * 3): void {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return;
    const parsed = JSON.parse(raw);
    if (!parsed || !parsed.user) return;
    const expiresAt = Date.now() + Number(durationMs);
    localStorage.setItem(SESSION_KEY, JSON.stringify({ user: parsed.user, expiresAt }));
    localStorage.setItem(LAST_INTERACTION_KEY, String(Date.now()));
  } catch {}
}

/**
 * Log out the current user and clear session data.
 */
export function logoutCurrentUser(): void {
  cachedCurrentUser = null;
  try {
    window.dispatchEvent(new CustomEvent('current-user-updated'));
  } catch {}
  try {
    localStorage.removeItem(SESSION_KEY);
    localStorage.removeItem(LAST_INTERACTION_KEY);
  } catch {}
}

// Re-export explicit names to avoid runtime ESM export resolution issues in some dev setups
// Default export for compatibility (some import sites may default-import the module)
export default {
  loadUsers,
  fetchRemoteUsers,
  saveUsers,
  updateUser,
  getCurrentUser,
  setCurrentUser
};
