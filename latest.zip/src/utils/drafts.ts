
// This file is retained only as a forwarder to the JSX implementation to prevent module resolution conflicts.
// Prefer importing from 'drafts.jsx'. Provides DraftBadge and helpers via re-export.
export * from './drafts.jsx';
