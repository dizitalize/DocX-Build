import { loadAppdata, saveAppdata } from './appdata';

/**
 * Returns an array of nodes from root to the node with the given id.
 * @param tree - The document tree
 * @param id - The node id to search for
 * @param path - The current path (used for recursion)
 */
export function getPathToNode(tree: any[], id: string, path: any[] = []): any[] | null {
  for (const node of tree) {
    const newPath = [...path, node];
    if (node.id === id) return newPath;
    if (node.children) {
      const res = getPathToNode(node.children, id, newPath);
      if (res) return res;
    }
  }
  return null;
}

/**
 * Loads the document index from appdata.
 */
export function loadDocsIndex(): any[] {
  const idx = loadAppdata().index;
  if (!Array.isArray(idx)) return [{ id: 'root', type: 'folder', title: 'Pages', children: [] }];
  return idx;
}

/**
 * Saves the document index to appdata and dispatches an update event.
 */
export function saveDocsIndex(tree: any[]): void {
  const app = loadAppdata();
  app.index = tree;
  saveAppdata(app);
  try {
    window.dispatchEvent(new CustomEvent('docs-index-updated'));
  } catch {}
  // queueDirtyIndex() is now a no-op; index sync is triggered manually
}

/**
 * Finds a node by id in the document tree.
 */
export function findNode(tree: any[], id: string): any | null {
  for (const node of tree) {
    if (node.id === id) return node;
    if (node.children) {
      const f = findNode(node.children, id);
      if (f) return f;
    }
  }
  return null;
}

/**
 * Removes a node by id from the document tree.
 */
export function removeNode(tree: any[], id: string): any | null {
  for (let i = 0; i < tree.length; i++) {
    const n = tree[i];
    if (n.id === id) {
      tree.splice(i, 1);
      return n;
    }
    if (n.children) {
      const r = removeNode(n.children, id);
      if (r) return r;
    }
  }
  return null;
}

/**
 * Soft-delete or restore a node by setting its `active` flag.
 * If active=false, node remains in index but is considered deleted.
 */
export function setNodeActive(tree: any[], id: string, active: boolean): boolean {
  const n = findNode(tree, id);
  if (!n) return false;
  n.active = active;
  return true;
}

/**
 * Inserts a node into the tree under the given parent folder.
 */
export function insertNode(tree: any[], parentId: string, node: any, index = -1): boolean {
  const parent = findNode(tree, parentId);
  if (!parent || parent.type !== 'folder') return false;
  parent.children = parent.children || [];
  if (index >= 0) parent.children.splice(index, 0, node);
  else parent.children.push(node);
  return true
}

export function updateNodeTitle(tree: any[], id: string, title: string): boolean {
  const n = findNode(tree, id)
  if (!n) return false
  n.title = title
  return true
}
