
import { loadAppdata, saveAppdata, markDirty } from './appdata';

/**
 * Retrieve all comments for a given document ID.
 * @param docId - The document ID
 * @returns A record of blockId to array of comments
 */
export function getComments(docId: string): Record<string, any[]> {
  const app = loadAppdata();
  return app.comments[docId] || {};
}

/**
 * Add a comment to a specific block in a document.
 * @param docId - The document ID
 * @param blockId - The block ID
 * @param comment - The comment object (should contain author, text, etc.)
 */
export function addComment(docId: string, blockId: string, comment: any): void {
  const app = loadAppdata();
  if (!app.comments[docId]) app.comments[docId] = {};
  if (!app.comments[docId][blockId]) app.comments[docId][blockId] = [];
  app.comments[docId][blockId].push({ id: Date.now().toString(), ts: Date.now(), ...comment });
  markDirty(app);
  saveAppdata(app);
}
