import { API, REMOTE_OWNER, REMOTE_REPO, REMOTE_BRANCH, getToken, headers, encodeContent, decodeContent, withRetry } from '../../utils/remoteConfig';

export type GetFileResult = { json: any; sha?: string };

export class GitHubService {
  static dispatchSyncState(state: string) {
    try {
      window.dispatchEvent(new CustomEvent('sync-state', { detail: state }));
    } catch (e) {}
  }
  static dispatchBlocking(on: boolean) {
    try {
      window.dispatchEvent(new CustomEvent('blocking-loader', { detail: on }));
    } catch (e) {}
  }

  static async getFile(path: string): Promise<GetFileResult | null> {
    GitHubService.dispatchSyncState('flushing');
    GitHubService.dispatchBlocking(true);
    try {
      return await withRetry(async () => {
        const res = await fetch(
          `${API}/repos/${REMOTE_OWNER}/${REMOTE_REPO}/contents/${path}?ref=${REMOTE_BRANCH}`,
          { headers: await headers(), cache: 'no-cache' }
        );
        if (!res.ok) return null;
        const data = await res.json();
        const sha = data.sha;
        const content = data.content;
        const decoded = content ? atob(content) : null;
        try {
          const parsed = decoded ? JSON.parse(decoded) : null;
          return { json: parsed, sha };
        } catch (e) {
          return { json: decoded, sha };
        }
      });
    } finally {
      GitHubService.dispatchSyncState('idle');
      GitHubService.dispatchBlocking(false);
    }
  }

  static async putFile(path: string, jsonObj: any, sha?: string): Promise<{ ok: boolean; sha?: string; reason?: string }> {
    GitHubService.dispatchSyncState('flushing');
    GitHubService.dispatchBlocking(true);

    console.log("pushing json file to github:", path, jsonObj, sha);
    try {
      if (jsonObj === undefined || jsonObj === null || (typeof jsonObj === 'string' && jsonObj.trim() === '')) {
        return { ok: false, reason: 'Attempted to save empty/undefined/null content' };
      }
      let toEncode = jsonObj;
      if (typeof jsonObj === 'object') {
        toEncode = JSON.stringify(jsonObj);
      }
      if (!toEncode || (typeof toEncode === 'string' && toEncode.trim() === '')) {
        return { ok: false, reason: 'Attempted to save empty content after stringify' };
      }
      const contentB64 = encodeContent(toEncode);
      if (!contentB64 || contentB64.trim() === '') {
        return { ok: false, reason: 'Attempted to save empty content after encodeContent' };
      }
      const body: any = { message: `Update ${path}`, content: contentB64, branch: REMOTE_BRANCH };
      if (sha) body.sha = sha;
  const res = await fetch(`${API}/repos/${REMOTE_OWNER}/${REMOTE_REPO}/contents/${path}`, { method: 'PUT', headers: { ...(await headers()), 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      if (!res.ok) {
        const txt = await res.text();
        return { ok: false, reason: txt };
      }
      const d = await res.json();
      return { ok: true, sha: d.content?.sha };
    } catch (e) {
      return { ok: false, reason: String(e) };
    } finally {
      GitHubService.dispatchSyncState('idle');
      GitHubService.dispatchBlocking(false);
    }
  }
}
