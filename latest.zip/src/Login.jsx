import { useState } from 'react'
import { fetchRemoteUsers, setCurrentUser } from './utils/users'
import { useNavigate } from 'react-router-dom'
import { loadDocsIndex } from './utils/docsIndex'
import { loadAppdata, createDoc, saveAppdata } from './utils/appdata'
import { getFile as ghGetFile, isRemoteEnabled } from './utils/github'

export default function Login() {
  const [u, setU] = useState('')
  const [p, setP] = useState('')
  const nav = useNavigate()

  const login = async () => {
    // fetch remote users list (fallbacks to static users if remote fails)
    const list = await fetchRemoteUsers() || []
    console.debug('[Login] fetched users list', list)
    const uname = String(u || '').trim()
    const pass = String(p || '').trim()
    const usersArray = Array.isArray(list) ? list : (list ? Object.values(list) : [])
    const found = usersArray.find(x => {
      if(!x) return false
      const xu = String(x.username || x.id || x.email || '').trim()
      const xp = String(x.password || '').trim()
      return xu === uname && xp === pass
    })
    if (!found) { console.debug('[Login] credentials did not match any remote user', { uname, usersArray }); return alert('Invalid credentials') }
    // set current user in-memory only
    setCurrentUser(found)
  // After login, attempt to load Appdata from remote GitHub into memory (no local writes)
    try{
      if(!isRemoteEnabled()) console.debug('[Login] remote token not present; attempting anonymous fetch')
      // Try appdata.json first (preferred), then fall back to index.json at repo root
      let remote = await ghGetFile('index.json')
      console.debug('[Login] fetched remote index.json', remote)
      if(!remote || !remote.json){
        console.log('[Login] appdata.json not found, trying index.json')
        const idx = await ghGetFile('index.json')
        console.debug('[Login] fetched remote index.json', idx)
        if(idx?.json){
          const minimal = { index: idx.json, docs: {}, comments: {}, history: {}, users: {}, syncMeta: { lastSync: new Date().toISOString(), dirty: false } }
          try{ saveAppdata(minimal) }catch(e){ console.warn('[Login] saveAppdata(minimal) failed', e) }
        } else {
          console.warn('[Login] neither appdata.json nor index.json found in remote repo')
        }
        } else {
          try{
            // Remote returned a full appdata object or an index-like object.
            // We no longer save the entire remote Appdata into local storage
            // to avoid overwriting per-doc content, comments, and history.
            // Instead, persist only the `index` (folder/tree) and keep docs/comments/history empty.
            let indexData = null
            if(remote.json && Array.isArray(remote.json.index)) indexData = remote.json.index
            else if(Array.isArray(remote.json)) indexData = remote.json
            else if(remote.json && Array.isArray(remote.json.index?.children ? remote.json.index : null)) indexData = remote.json.index
            if(indexData === null){
              console.warn('[Login] remote returned unexpected shape; skipping saveAppdata')
            } else {
              const minimal = { index: indexData, docs: {}, comments: {}, history: {}, users: {}, syncMeta: { lastSync: new Date().toISOString(), dirty: false } }
              try{ saveAppdata(minimal); console.log('[Login] loaded minimal Appdata (index only) into memory') }catch(e){ console.warn('[Login] saveAppdata(minimal) failed', e) }
            }
          }catch(e){ console.warn('[Login] saveAppdata failed', e) }
        }
    }catch(e){ console.warn('[Login] fetch remote appdata failed', e) }
    // determine first doc, create one if missing
    // Note: loadDocsIndex will read the Appdata we just saved from remote (if available)
    let index = loadDocsIndex()
    // guard against malformed or missing index (avoid 'nodes is not iterable')
    if(!Array.isArray(index)){
      console.warn('[Login] docs index is missing or malformed, falling back to default root')
      index = [{ id:'root', type:'folder', title:'Pages', children: [] }]
    }
    const findFirst = (nodes) => {
      for(const n of nodes){
        if(n.type==='doc') return n.id
        if(n.children){ const r = findFirst(n.children); if(r) return r }
      }
      return null
    }
    let firstId = findFirst(index)
    if(!firstId){
      const app = loadAppdata()
      firstId = createDoc(app,'root','Page title','<p>Start writing…</p>')
    } else {
      // If remote is enabled, attempt to fetch the page content for the first doc from the repo
      try{
        const remoteDoc = await ghGetFile(`docs/${firstId}.json`)
        if(remoteDoc?.json){
          const app = loadAppdata()
          app.docs = app.docs || {}
          const rd = remoteDoc.json
          app.docs[firstId] = {
            title: rd.title || (app.docs[firstId] && app.docs[firstId].title) || 'Untitled Page',
            content: rd.content || (app.docs[firstId] && app.docs[firstId].content) || '<p>Start writing 26hellip;</p>',
            updatedAt: rd.updatedAt || (app.docs[firstId] && app.docs[firstId].updatedAt) || null,
            lastEditedBy: rd.lastEditedBy || (app.docs[firstId] && app.docs[firstId].lastEditedBy) || 'Unknown'
          }
          // do not persist to localStorage in runtime; keep in memory
          saveAppdata(app)
        }
      }catch(e){ console.warn('[Login] fetch remote doc failed', e) }
    }
    nav(`/docs/${firstId}`)
  }

  return (
    <div className="h-screen flex items-center justify-center bg-[#F4F5F7] dark:bg-[#0B0F1A]">
      <div className="bg-white dark:bg-[#0F172A] rounded shadow-lg p-6 w-80 border border-borderLight dark:border-[#1F2937]">
        <h2 className="text-center text-lg font-semibold mb-4">Login</h2>
        <input className="w-full border border-borderLight dark:border-[#1F2937] rounded px-3 py-2 mb-3 bg-white dark:bg-[#0B0F1A]" placeholder="username" value={u} onChange={e=>setU(e.target.value)} />
        <input className="w-full border border-borderLight dark:border-[#1F2937] rounded px-3 py-2 mb-4 bg-white dark:bg-[#0B0F1A]" placeholder="password" type="password" value={p} onChange={e=>setP(e.target.value)} />
        <button onClick={login} className="w-full bg-atlassianBlue text-white py-2 rounded hover:brightness-110">Login</button>
      </div>
    </div>
  )
}
