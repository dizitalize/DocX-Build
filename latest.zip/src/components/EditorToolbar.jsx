
import React from 'react';
import {
  Bold, Italic, Underline, Strikethrough, List, ListOrdered,
  CheckSquare, Quote, Minus, Code, Link as LinkIcon,
  Image as ImageIcon, Table as TableIcon, Type,
  Search as SearchIcon, MessageSquareText, History as HistoryIcon,
  Undo2, Redo2
} from 'lucide-react';

const ToolbarButton = React.memo(function ToolbarButton({ onClick, active, title, children }) {
  return (
    <button
      title={title}
      onClick={onClick}
      className={`p-2 rounded hover:bg-[#EBECF0] dark:hover:bg-[#101828] transition ${active ? 'bg-[#EBECF0] dark:bg-[#101828]' : ''}`}
      type="button"
    >
      {children}
    </button>
  );
});

/**
 * Toolbar for the rich text editor. Maintains Vite compatibility and preserves the public interface.
 */
export default function EditorToolbar({ editor }) {
  if (!editor) return null;

  // Helper to focus then run chain builder
  const run = (chainFn) => () => {
    chainFn(editor.chain().focus()).run();
  };

  const promptLink = () => {
    const url = prompt('Enter URL');
    if (url) editor.chain().focus().setLink({ href: url }).run();
  };

  const promptImage = () => {
    const url = prompt('Image URL (must end with .jpg, .jpeg, .png, .gif, .webp, .svg) or base64:');
    if (!url) return;
    const isBase64 = url.startsWith('data:image/');
    const isDirectImg = /\.(jpg|jpeg|png|gif|webp|svg)(\?.*)?$/i.test(url);
    if (!isBase64 && !isDirectImg) {
      alert('Please enter a direct image URL ending with .jpg, .jpeg, .png, .gif, .webp, .svg or a base64 image.');
      return;
    }
    editor.chain().focus().setImage({ src: url }).run();
  };

  return (
    <div className="sticky top-14 z-30 bg-toolbarBg dark:bg-[#0B0F1A] border-b border-borderLight dark:border-[#1F2937] shadow-toolbar">
      <div className="max-w-5xl mx-auto flex items-center gap-1 px-3 h-11">
        <ToolbarButton title="Bold" onClick={run(chain => chain.toggleBold())} active={editor.isActive('bold')}><Bold className="w-4 h-4" /></ToolbarButton>
        <ToolbarButton title="Italic" onClick={run(chain => chain.toggleItalic())} active={editor.isActive('italic')}><Italic className="w-4 h-4" /></ToolbarButton>
        <ToolbarButton title="Underline" onClick={run(chain => chain.toggleUnderline?.())} active={editor.isActive('underline')}><Underline className="w-4 h-4" /></ToolbarButton>
        <ToolbarButton title="Strike" onClick={run(chain => chain.toggleStrike())} active={editor.isActive('strike')}><Strikethrough className="w-4 h-4" /></ToolbarButton>
        <span className="mx-2 w-px h-6 bg-borderLight dark:bg-[#1F2937]" />
        <ToolbarButton title="Heading" onClick={run(chain => chain.toggleHeading({ level: 2 }))} active={editor.isActive('heading', { level: 2 })}><Type className="w-4 h-4" /></ToolbarButton>
        <ToolbarButton title="Bulleted list" onClick={run(chain => chain.toggleBulletList())} active={editor.isActive('bulletList')}><List className="w-4 h-4" /></ToolbarButton>
        <ToolbarButton title="Numbered list" onClick={run(chain => chain.toggleOrderedList())} active={editor.isActive('orderedList')}><ListOrdered className="w-4 h-4" /></ToolbarButton>
        <ToolbarButton title="Checklist" onClick={run(chain => chain.toggleTaskList())} active={editor.isActive('taskList')}><CheckSquare className="w-4 h-4" /></ToolbarButton>
        <ToolbarButton title="Quote" onClick={run(chain => chain.toggleBlockquote())} active={editor.isActive('blockquote')}><Quote className="w-4 h-4" /></ToolbarButton>
        <ToolbarButton title="Rule" onClick={run(chain => chain.setHorizontalRule())}><Minus className="w-4 h-4" /></ToolbarButton>
        <span className="mx-2 w-px h-6 bg-borderLight dark:bg-[#1F2937]" />
        <ToolbarButton title="Code block" onClick={run(chain => chain.toggleCodeBlock())} active={editor.isActive('codeBlock')}><Code className="w-4 h-4" /></ToolbarButton>
        <ToolbarButton title="Link" onClick={promptLink} active={editor.isActive('link')}><LinkIcon className="w-4 h-4" /></ToolbarButton>
        <ToolbarButton title="Image" onClick={promptImage}><ImageIcon className="w-4 h-4" /></ToolbarButton>
        <ToolbarButton title="Insert table" onClick={run(chain => chain.insertTable({ rows: 3, cols: 4, withHeaderRow: true }))}><TableIcon className="w-4 h-4" /></ToolbarButton>
        {/* Table operations */}
        <ToolbarButton title="Add row" onClick={run(chain => chain.addRowAfter())}><span className="text-xs">+Row</span></ToolbarButton>
        <ToolbarButton title="Del row" onClick={run(chain => chain.deleteRow())}><span className="text-xs">-Row</span></ToolbarButton>
        <ToolbarButton title="Add col" onClick={run(chain => chain.addColumnAfter())}><span className="text-xs">+Col</span></ToolbarButton>
        <ToolbarButton title="Del col" onClick={run(chain => chain.deleteColumn())}><span className="text-xs">-Col</span></ToolbarButton>
        <ToolbarButton title="Del table" onClick={run(chain => chain.deleteTable())}><span className="text-xs">XTbl</span></ToolbarButton>
        <span className="mx-2 w-px h-6 bg-borderLight dark:bg-[#1F2937]" />
  <ToolbarButton title="Search (Ctrl+K)" onClick={()=>window.dispatchEvent(new CustomEvent('open-search'))}>
    <SearchIcon className="w-4 h-4" />
  </ToolbarButton>
  <ToolbarButton title="Comments" onClick={()=>window.dispatchEvent(new CustomEvent('open-comments'))}>
    <MessageSquareText className="w-4 h-4" />
  </ToolbarButton>
  <ToolbarButton title="History" onClick={()=>window.dispatchEvent(new CustomEvent('open-history'))}>
    <HistoryIcon className="w-4 h-4" />
  </ToolbarButton>
        <span className="mx-2 w-px h-6 bg-borderLight dark:bg-[#1F2937]" />
  <ToolbarButton title="Undo" onClick={run(chain=>chain.undo())}>
    <Undo2 className="w-4 h-4" />
  </ToolbarButton>
  <ToolbarButton title="Redo" onClick={run(chain=>chain.redo())}>
    <Redo2 className="w-4 h-4" />
  </ToolbarButton>
      </div>
    </div>
  )
}
