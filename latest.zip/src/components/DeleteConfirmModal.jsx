
import { loadAppdata } from '../utils/appdata';

/**
 * Modal for confirming deletion of a folder or page.
 * Maintains Vite compatibility and preserves the public interface.
 */
export default function DeleteConfirmModal({ open, onClose, target, docs, onConfirm }) {
  if (!open) return null;

  const isFolder = target?.type === 'folder';

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-32 bg-black/30 backdrop-blur-sm">
      <div className="w-[520px] bg-white dark:bg-[#0F172A] rounded shadow-lg border border-borderLight dark:border-[#1F2937]">
        <div className="px-5 py-4 border-b border-borderLight dark:border-[#1F2937] flex items-center justify-between">
          <h2 className="text-lg font-semibold">Delete {isFolder ? 'Folder' : 'Page'}</h2>
        </div>
        <div className="px-5 pt-4 pb-5 text-sm max-h-[360px] overflow-y-auto">
          {isFolder ? (
            <p className="mb-3 text-textSecondary dark:text-gray-400">
              You're about to delete this folder and all pages inside it. The following pages will be permanently removed:
            </p>
          ) : (
            <p className="mb-3 text-textSecondary dark:text-gray-400">
              You're about to delete this page permanently:
            </p>
          )}
          <table className="w-full text-left text-xs border border-borderLight dark:border-[#1F2937] rounded overflow-hidden">
            <thead className="bg-[#F4F5F7] dark:bg-[#101828] text-textSecondary dark:text-gray-300">
              <tr>
                <th className="py-2 px-2 font-medium">Title</th>
                <th className="py-2 px-2 font-medium w-32">Last Edited By</th>
                <th className="py-2 px-2 font-medium w-40">Updated</th>
              </tr>
            </thead>
            <tbody>
              {docs.map((doc) => {
                const app = loadAppdata();
                const data = app?.docs?.[doc.id] || null;
                const safeTitle = data?.title || doc.title || 'Untitled';
                // Use lastEditedBy as a user key (username/email)
                let editorKey = data?.lastEditedBy || doc.lastEditedBy || null;
                let editor = '-';
                if (editorKey && app?.users && typeof app.users === 'object') {
                  const user = app.users[editorKey];
                  if (user) editor = user.name || user.username || user.email || editorKey;
                  else editor = editorKey;
                } else if (editorKey) {
                  editor = editorKey;
                }
                return (
                  <tr key={doc.id} className="border-t border-borderLight dark:border-[#1F2937]">
                    <td className="py-1.5 px-2 text-[13px] truncate">{safeTitle}</td>
                    <td className="py-1.5 px-2 text-[13px]">{editor}</td>
                    <td className="py-1.5 px-2 text-[11px] text-textSecondary dark:text-gray-400">
                      {data?.updatedAt ? new Date(data.updatedAt).toLocaleString() : '-'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="px-5 py-3 bg-[#F4F5F7] dark:bg-[#101828] border-t border-borderLight dark:border-[#1F2937] flex justify-end gap-2">
          <button onClick={onClose} className="px-3 py-1.5 text-sm rounded border border-borderLight dark:border-[#1F2937] bg-white dark:bg-[#0F172A] hover:bg-[#EBECF0] dark:hover:bg-[#162032] transition">Cancel</button>
          <button onClick={onConfirm} className="px-3 py-1.5 text-sm rounded bg-red-600 text-white hover:brightness-110 transition">Delete</button>
        </div>
      </div>
    </div>
  )
}
