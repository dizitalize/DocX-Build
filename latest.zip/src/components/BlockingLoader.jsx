
import { Loader2 } from 'lucide-react';
import { useEffect, useState } from 'react';

/**
 * Displays a blocking loader overlay when a 'blocking-loader' event is dispatched.
 * Maintains full compatibility with Vite and preserves the public interface.
 */
export default function BlockingLoader() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handleEvent = (e) => setVisible(Boolean(e.detail));
    window.addEventListener('blocking-loader', handleEvent);
    return () => window.removeEventListener('blocking-loader', handleEvent);
  }, []);

  if (!visible) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30">
      <div className="bg-white dark:bg-[#0B1220] p-6 rounded shadow flex items-center gap-3">
        <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
        <span className="text-sm">Syncing</span>
      </div>
    </div>
  );
}
