
import { X } from 'lucide-react';
import { useState, useEffect } from 'react';
import { getCurrentUser, updateUser, setCurrentUser } from '../utils/users';

/**
 * Modal for editing user settings. Maintains Vite compatibility and preserves the public interface.
 */
export default function UserSettingsModal({ open, onClose }) {
  const [user, setUser] = useState(getCurrentUser());
  const [draft, setDraft] = useState({ name: user?.name || '', email: user?.email || '' });
  const [msg, setMsg] = useState('');

  useEffect(() => {
    if (open) {
      const u = getCurrentUser();
      setUser(u);
      setDraft({ name: u?.name || '', email: u?.email || '' });
    }
  }, [open]);

  if (!open) return null;

  const save = () => {
    const name = draft.name.trim() || 'Unnamed';
    const email = draft.email.trim();
    updateUser(user.username, { name, email });
    setCurrentUser({ ...user, name, email });
    setMsg('Profile updated!');
    setTimeout(() => setMsg(''), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black bg-opacity-20">
      <div className="relative mt-12 w-full max-w-lg bg-white dark:bg-[#101828] rounded-xl shadow-2xl p-8 border border-borderLight dark:border-[#1F2937] animate-fade-in">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 dark:hover:text-white p-1 rounded-full focus:outline-none"
        >
          <X className="w-6 h-6" />
        </button>
        <h1 className="text-2xl font-bold mb-6">User Settings</h1>
        <div className="mb-4">
          <label className="block text-sm font-medium mb-1">Name</label>
          <input
            className="w-full text-base px-3 py-2 rounded border border-borderLight dark:border-[#1F2937] bg-white dark:bg-[#0F172A]"
            value={draft.name}
            onChange={e => setDraft(d => ({ ...d, name: e.target.value }))}
            placeholder="Name"
          />
        </div>
        <div className="mb-4">
          <label className="block text-sm font-medium mb-1">Email</label>
          <input
            className="w-full text-base px-3 py-2 rounded border border-borderLight dark:border-[#1F2937] bg-white dark:bg-[#0F172A]"
            value={draft.email}
            onChange={e => setDraft(d => ({ ...d, email: e.target.value }))}
            placeholder="Email"
          />
        </div>
        <button
          onClick={save}
          className="px-5 py-2 rounded bg-atlassianBlue text-white font-semibold shadow hover:brightness-110 transition"
        >
          Save
        </button>
        {msg && <div className="mt-3 text-green-600 dark:text-green-400">{msg}</div>}
      </div>
    </div>
  );
}
