
import { useEffect, useState, useRef } from 'react';
import { getCurrentUser, logoutCurrentUser } from '../utils/users';
import UserSettingsModal from './UserSettingsPage';

/**
 * User profile panel for account info and settings. Maintains Vite compatibility and preserves the public interface.
 */
export default function UserProfilePanel({ open, onClose, anchorRef }) {
  const [current, setCurrent] = useState(getCurrentUser());
  const [showSettings, setShowSettings] = useState(false);
  const popupRef = useRef(null);

  useEffect(() => {
    const handleCurrent = () => setCurrent(getCurrentUser());
    window.addEventListener('current-user-updated', handleCurrent);
    return () => window.removeEventListener('current-user-updated', handleCurrent);
  }, []);

  // Close popup on outside click
  useEffect(() => {
    if (!open) return;
    function handleClick(e) {
      if (
        popupRef.current &&
        !popupRef.current.contains(e.target) &&
        (!anchorRef || !anchorRef.current || !anchorRef.current.contains(e.target))
      ) {
        onClose();
      }
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, [open, onClose, anchorRef]);

  if (showSettings) {
    return <UserSettingsModal open={showSettings} onClose={() => setShowSettings(false)} />;
  }

  if (!open || !current) return null;

  // Position popup below anchorRef (profile icon)
  let style = { position: 'absolute', top: 60, right: 24, zIndex: 1000 };
  if (anchorRef && anchorRef.current) {
    const rect = anchorRef.current.getBoundingClientRect();
    style = {
      position: 'absolute',
      top: rect.bottom + 8 + window.scrollY,
      left: rect.left + window.scrollX - 180 + rect.width / 2,
      zIndex: 1000,
    };
  }

  return (
    <div
      ref={popupRef}
      style={style}
      className="bg-white dark:bg-[#101828] rounded-xl shadow-2xl border border-borderLight dark:border-[#1F2937] w-80 p-5 flex flex-col gap-2 animate-fade-in"
    >
      <div className="flex items-center gap-3 mb-2">
        <div className="w-11 h-11 rounded-full bg-gradient-to-br from-atlassianBlue to-blue-400 flex items-center justify-center text-white text-xl font-bold uppercase shadow-sm">
          {current.username?.slice(0, 2) || 'U'}
        </div>
        <div>
          <div className="font-semibold text-lg">{current.name || current.username}</div>
          <div className="text-xs text-textSecondary dark:text-gray-400">{current.email || '—'}</div>
          <div className="text-xs text-gray-400 mt-1">
            Role: <span className="font-medium text-gray-700 dark:text-gray-200">{current.role || 'user'}</span>
          </div>
        </div>
      </div>
      <button
        onClick={() => { setShowSettings(true); onClose(); }}
        className="px-4 py-2 rounded bg-atlassianBlue text-white font-semibold shadow hover:brightness-110 transition mt-2"
      >
        Settings
      </button>
      <button
        onClick={() => { logoutCurrentUser(); onClose(); }}
        className="px-4 py-2 rounded bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-100 font-semibold shadow hover:bg-gray-300 dark:hover:bg-gray-600 transition mt-1"
      >
        Sign Out
      </button>
    </div>
  );
}
