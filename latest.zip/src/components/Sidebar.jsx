// Local storage helpers
function saveTreeToLocal(tree) {
  try {
    localStorage.setItem('sidebarTree', JSON.stringify(tree));
  } catch (e) {}
}

function loadTreeFromLocal() {
  try {
    const data = localStorage.getItem('sidebarTree');
    return data ? JSON.parse(data) : null;
  } catch (e) { return null; }
}

// ...imports and other code remain unchanged...
function generateUniqueId(prefix, tree) {
  let id;
  do {
    id = prefix + '-' + Date.now() + '-' + Math.floor(Math.random() * 1000000);
  } while (findNode(tree, id));
  return id;
}


import { Plus, FolderPlus } from 'lucide-react';
import { loadDocsIndex, saveDocsIndex, insertNode, removeNode, findNode, updateNodeTitle, setNodeActive } from '../utils/docsIndex';
import { isRemoteEnabled, getFile as ghGetFile, putFile } from '../utils/github';
import { updateRootTree } from '../utils/remoteFolders';
import { loadAppdata, saveAppdata } from '../utils/appdata';
import { triggerIndexSync, queueDirtyDoc } from '../utils/remoteSync';
import SidebarItem from './SidebarItem';
import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import DeleteConfirmModal from './DeleteConfirmModal';

/**
 * Sidebar for navigating and managing documents and folders. Maintains Vite compatibility and preserves the public interface.
 */
export default function Sidebar({ collapsed, setCollapsed }) {
  // ...existing state and hooks...

  // Rename a node (doc or folder) by id
const renameNode = (id, newTitle) => {
  setTree(prevTree => {
    const next = structuredClone(prevTree);
    const changed = updateNodeTitle(next, id, newTitle);
    if (!changed) return prevTree;
    saveDocsIndex(next);
    updateRootTree(next);
    // Do NOT update appdata/docs title here; sidebar and doc titles are now independent
    try { window.dispatchEvent(new CustomEvent('docs-index-updated')); } catch (e) {}
    return next;
  });
};


  // Try to load from localStorage first
  // Robust initialization: always prefer localStorage if valid, else index, else root
  const [tree, setTree] = useState(() => {
    const local = loadTreeFromLocal();
    if (local && Array.isArray(local) && local.length > 0 && !(local.length === 1 && local[0].id === 'root' && (!local[0].children || local[0].children.length === 0))) return local;
    const idx = loadDocsIndex();
    if (idx && Array.isArray(idx) && idx.length > 0 && !(idx.length === 1 && idx[0].id === 'root' && (!idx[0].children || idx[0].children.length === 0))) return idx;
    return [{ id: 'root', type: 'folder', title: 'Pages', children: [] }];
  });
  const [lastPushedTree, setLastPushedTree] = useState(() => loadTreeFromLocal() || loadDocsIndex());
  const [isDraft, setIsDraft] = useState(false);
  const nav = useNavigate();
  const rootId = tree[0]?.id || 'root';
  const persist = (next) => { setTree([...next]); saveDocsIndex(next); };
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [autoEditId, setAutoEditId] = useState(null);
  const [indexSha, setIndexSha] = useState(null);
  const [sidebarWidth, setSidebarWidth] = useState(256);
  const minWidth = 180, maxWidth = 480;
  const sidebarRef = useRef(null);
  const dragging = useRef(false);

  // Handle drag to resize
  useEffect(() => {
    function onMouseMove(e) {
      if (!dragging.current) return;
      let newWidth = e.clientX - (sidebarRef.current?.getBoundingClientRect().left || 0);
      if (newWidth < minWidth) newWidth = minWidth;
      if (newWidth > maxWidth) newWidth = maxWidth;
      setSidebarWidth(newWidth);
    }
    function onMouseUp() { dragging.current = false; }
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
    };
  }, []);

  // On mount, listen for remote updates and update localStorage
  useEffect(() => {
    const refresh = () => {
      const idx = loadDocsIndex();
      setTree(idx);
      saveTreeToLocal(idx);
      setLastPushedTree(idx);
      setIsDraft(false);
    };
    window.addEventListener('docs-index-updated', refresh);
    if (isRemoteEnabled()) {
      ghGetFile('index.json').then(r => {
        if (r && r.json) {
          setTree(r.json);
          saveTreeToLocal(r.json);
          setLastPushedTree(r.json);
          setIsDraft(false);
        }
        if (r?.sha) setIndexSha(r.sha);
      }).catch(() => {});
    }
    return () => window.removeEventListener('docs-index-updated', refresh);
  }, []);

  // On every tree change, update localStorage and draft state
  useEffect(() => {
    saveTreeToLocal(tree);
    setIsDraft(JSON.stringify(tree) !== JSON.stringify(lastPushedTree));
  }, [tree, lastPushedTree]);

  // Every 10s, check if local tree differs from last pushed, and if so, push to GitHub
  useEffect(() => {
    const interval = setInterval(async () => {
      // Only push if different and not just the root node
      const isJustRoot = tree.length === 1 && tree[0].id === 'root' && (!tree[0].children || tree[0].children.length === 0);
      if (
        JSON.stringify(tree) !== JSON.stringify(lastPushedTree) &&
        !isJustRoot
      ) {
        // Extra guard: never push just root node
        if (tree.length === 1 && tree[0].id === 'root' && (!tree[0].children || tree[0].children.length === 0)) return;
        try {
          await putFile('index.json', tree);
          setLastPushedTree(tree);
          setIsDraft(false);
        } catch (e) {}
      }
    }, 10000);
    return () => clearInterval(interval);
  }, [tree, lastPushedTree]);


const createDoc = (parentId = rootId) => {
  setTree(prevTree => {
    const app = loadAppdata();
    const id = generateUniqueId('doc', prevTree);
    const node = { id, type: 'doc', title: 'Untitled Page', initial: { content: '<p>Start writing…</p>' } };
    app.docs[id] = { title: node.title, content: node.initial.content, updatedAt: new Date().toISOString(), lastEditedBy: 'Unknown' };
    app.history[id] = [];
    app.comments[id] = [];
    const next = structuredClone(prevTree);
    insertNode(next, parentId, node);
    saveDocsIndex(next);
    updateRootTree(next);
    setAutoEditId(id);
    putFile(`docs/${id}.json`, app.docs[id]);
    nav(`/docs/${id}`);
    return next;
  });
};
  // NOTE: If you use createDoc as an event handler, always wrap: onClick={() => createDoc()}

  // Create a new folder under the given parent (or root)
const createFolder = (parentId = rootId) => {
  setTree(prevTree => {
    const id = generateUniqueId('folder', prevTree);
    const node = { id, type: 'folder', title: 'Untitled Folder', active: true, children: [] };
    const next = structuredClone(prevTree);
    insertNode(next, parentId, node);
    saveDocsIndex(next);
    updateRootTree(next);
    setAutoEditId(id);
    try { window.dispatchEvent(new CustomEvent('docs-index-updated')); } catch (e) {}
    return next;
  });
};
  const collectDocs = (node) => {
    const list = []
    const walk = (n) => { if(n.type==='doc') list.push(n); if(n.children) n.children.forEach(walk) }
    walk(node)
    return list
  }
  const openDelete = (nodeId) => {
    const node = findNode(tree, nodeId);
    if(!node || node.id === rootId) return
    setDeleteTarget(node)
    setDeleteOpen(true)
  }
  const confirmDelete = () => {
    if(!deleteTarget) return
    const next = structuredClone(tree)
    // Soft-delete: set `active=false` on the node instead of removing it from the index
    const success = setNodeActive(next, deleteTarget.id, false)
    if(success){
      // Remove from parent's children for UI, but keep in index for data
      removeNode(next, deleteTarget.id)
      const app = loadAppdata()
      persist(next)
      saveAppdata(app)
      updateRootTree(next)
      if(autoEditId === deleteTarget.id) setAutoEditId(null)
    }
    setDeleteOpen(false)
    setDeleteTarget(null)
  }
  let dragNode = null
  const onDragStart = (e,node)=>{ dragNode = node; e.dataTransfer.effectAllowed='move' }
  const onDragOver = (e)=>{ e.preventDefault(); e.dataTransfer.dropEffect='move' }
  const onDrop = (e,target)=>{
    e.preventDefault()
    if(!dragNode || dragNode.id===target.id) return
    // Don't allow moving deleted nodes
    if(dragNode.active === false) return
    const next = structuredClone(tree)
    const moved = removeNode(next, dragNode.id)
    if(!moved) return
    if(target.type==='folder'){
      insertNode(next, target.id, moved)
    } else {
      // insert after target in its parent
      const stack=[{parent:null,list:next}]
      while(stack.length){
        const {parent,list}=stack.pop()
        for(let i=0;i<list.length;i++){
          const n=list[i]
          if(n.id===target.id){
            if(parent){
              const idx = parent.children.findIndex(c=>c.id===target.id)
              parent.children.splice(idx+1,0,moved)
            } else {
              list.splice(i+1,0,moved)
            }
            persist(next); updateRootTree(next); triggerIndexSync(); return
          }
          if(n.children) stack.push({parent:n,list:n.children})
        }
      }
    }
    persist(next); updateRootTree(next); triggerIndexSync()
  }
  return (
    <>
      <aside
        ref={sidebarRef}
        className={`bg-sidebarBg dark:bg-[#0B1220] border-r border-borderLight dark:border-[#1F2937] min-h-[calc(100vh-56px)] transition-all duration-150 ease-in-out relative ${collapsed ? 'w-12' : ''}`}
        style={{ width: collapsed ? 48 : sidebarWidth, minWidth: collapsed ? 48 : 180, maxWidth: collapsed ? 48 : 480 }}
        onMouseLeave={triggerIndexSync}
      >
        {/* Collapse/expand button */}
        <button
          className="absolute top-3 -right-3 z-30 w-7 h-7 flex items-center justify-center bg-white dark:bg-[#101828] border border-borderLight dark:border-[#1F2937] rounded-full shadow-lg hover:bg-gray-100 dark:hover:bg-[#22223b] transition focus:outline-none"
          style={{ boxShadow: '0 2px 8px #0002', borderWidth: '2px' }}
          onClick={() => setCollapsed && setCollapsed(c => !c)}
          tabIndex={-1}
        >
          <span className="sr-only">{collapsed ? 'Expand sidebar' : 'Collapse sidebar'}</span>
          <svg width="18" height="18" fill="none" viewBox="0 0 16 16"><path d={collapsed ? 'M6 4l4 4-4 4' : 'M10 4L6 8l4 4'} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </button>
        {/* Draft/Sync indicator */}
        {/* <div style={{position:'absolute',top:8,left:8}}>
          {isDraft ? <span title="Unsaved changes" style={{color:'#eab308',fontWeight:'bold'}}>📝 Draft</span> : <span title="All changes saved" style={{color:'#22c55e',fontWeight:'bold'}}>✔ All changes saved</span>}
        </div> */}
        {/* Drag handle for resizing */}
        {!collapsed && (
          <div
            className="absolute top-0 right-0 h-full w-2 cursor-col-resize z-10"
            style={{ userSelect: 'none' }}
            onMouseDown={() => { dragging.current = true }}
          />
        )}
        <div className={`flex flex-col h-full ${collapsed ? 'items-center' : ''}`}>
          <div className={`px-3 py-2 text-xs font-semibold text-textSecondary dark:text-gray-400 uppercase tracking-wide ${collapsed ? 'hidden' : ''}`}>Pages</div>
          <div className={`px-3 pb-2 flex gap-2 ${collapsed ? 'hidden' : ''}`}>
            <button onClick={createDoc} className="flex-1 flex items-center gap-2 bg-white dark:bg-[#0F172A] border border-borderLight dark:border-[#1F2937] rounded px-3 py-2 text-sm hover:shadow transition">
              <Plus className="w-4 h-4"/> New page
            </button>
            <button onClick={()=>{createFolder(); triggerIndexSync()}} className="px-3 py-2 bg-white dark:bg-[#0F172A] border border-borderLight dark:border-[#1F2937] rounded text-sm hover:shadow transition" title="New folder">
              <FolderPlus className="w-4 h-4"/>
            </button>
          </div>
          <div className={`px-3 py-2 text-xs font-semibold text-textSecondary dark:text-gray-400 uppercase tracking-wide ${collapsed ? 'hidden' : ''}`}>Page tree</div>
          <nav className={`px-1 overflow-y-auto max-h-[calc(100vh-56px-110px)] pb-4 flex-1 ${collapsed ? 'hidden' : ''}`}>
            {tree.filter(node => node.active !== false).map(node => (
              <SidebarItem
                key={node.id}
                node={node}
                onDragStart={onDragStart}
                onDragOver={onDragOver}
                onDrop={onDrop}
                onDelete={openDelete}
                onCreateDoc={createDoc}
                onCreateFolder={createFolder}
                onRename={(id, title) => {renameNode(id, title); triggerIndexSync()}}
                autoEditId={autoEditId}
              />
            ))}
          </nav>
          <DeleteConfirmModal
            open={deleteOpen}
            onClose={()=>{ setDeleteOpen(false); setDeleteTarget(null) }}
            target={deleteTarget}
            docs={deleteTarget ? collectDocs(deleteTarget) : []}
            onConfirm={() => {confirmDelete(); triggerIndexSync()}}
          />
        </div>
      </aside>
    </>
  )
}
