
import { useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { loadAppdata, sanitizeContent } from '../utils/appdata';
import { fetchDocIfMissing } from '../utils/remoteSync';

/**
 * Read-only view page for a document. Maintains Vite compatibility and preserves the public interface.
 */
export default function ViewPage() {
  const { id } = useParams();
  const [loading, setLoading] = useState(false);
  const [doc, setDoc] = useState({ title: 'Untitled', content: '<p>No content.</p>' });

  useEffect(() => {
    let mounted = true;
    const app = loadAppdata();
    if (app.docs[id]) {
      setDoc(app.docs[id]);
      return;
    }
    setLoading(true);
    fetchDocIfMissing(id).then(() => {
      if (!mounted) return;
      const fresh = loadAppdata().docs[id];
      if (fresh) setDoc(fresh);
      setLoading(false);
    });
    return () => { mounted = false; };
  }, [id]);

  const safeContent = sanitizeContent(doc.content);

  return (
    <div className="max-w-5xl mx-auto px-6 py-8">
      <h1 className="text-3xl font-semibold mb-6">
        {doc.title}
        {loading && <span className="ml-2 text-xs text-textSecondary">(loading…)</span>}
      </h1>
      {loading ? (
        <div className="animate-pulse space-y-3 bg-white dark:bg-[#0F172A] p-6 rounded border border-borderLight dark:border-[#1F2937]">
          <div className="h-4 w-3/4 bg-gray-200 dark:bg-[#1F2937] rounded" />
          <div className="h-4 w-2/3 bg-gray-200 dark:bg-[#1F2937] rounded" />
          <div className="h-4 w-1/2 bg-gray-200 dark:bg-[#1F2937] rounded" />
        </div>
      ) : (
        <article
          className="prose max-w-none bg-white dark:bg-[#0F172A] p-6 rounded border border-borderLight dark:border-[#1F2937]"
          dangerouslySetInnerHTML={{ __html: safeContent }}
        />
      )}
    </div>
  );
}
