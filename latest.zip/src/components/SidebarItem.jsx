import { useState, useEffect, useRef } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { Folder, ChevronDown, ChevronRight, FileText, Trash, Plus, Pencil } from 'lucide-react';
import { findNode } from '../utils/docsIndex';

/**
 * Sidebar item for a document or folder. Maintains Vite compatibility and preserves the public interface.
 */
export default function SidebarItem({ node, depth = 0, onDragStart, onDrop, onDragOver, onDelete, onCreateDoc, onCreateFolder, onRename, autoEditId }) {
  const [open, setOpen] = useState(true);
  const [editing, setEditing] = useState(!!(autoEditId === node.id));
  const [tempTitle, setTempTitle] = useState(node.title);
  const inputRef = useRef(null);
  const location = useLocation();

  // Reset editing state when navigating to a different page
  useEffect(() => {
    setEditing(!!(autoEditId === node.id));
    setTempTitle(node.title);
  }, [autoEditId, node.id, node.title, location.pathname]);

  useEffect(() => { if (autoEditId && findNode([node], autoEditId)) setOpen(true); }, [autoEditId, node]);
  useEffect(() => { if (editing && inputRef.current) { inputRef.current.focus(); inputRef.current.select(); } }, [editing]);

  const pad = 8 + depth * 12;

  if (node.type === 'folder') {
    return (
      <div className="select-none">
        <div
          className="group flex items-center gap-2 px-3 py-1.5 text-[15px] text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-[#181f2a] cursor-pointer rounded-lg transition-all shadow-sm"
          style={{ paddingLeft: pad, minHeight: 36, fontWeight: 500, letterSpacing: 0.1 }}
          draggable
          onDragStart={e => onDragStart(e, node)}
          onDragOver={e => onDragOver(e, node)}
          onDrop={e => onDrop(e, node)}
          onClick={() => setOpen(o => !o)}
        >
          <span className="flex items-center justify-center w-5 h-5 rounded-md bg-gray-200 dark:bg-[#232b3b] mr-1">
            {open ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
          </span>
          <Folder className="w-4 h-4 text-blue-500 dark:text-blue-400" />
          <div className="flex-1 min-w-0 flex items-center gap-1">
            {editing ? (
              <input
                ref={inputRef}
                value={tempTitle}
                onChange={e => setTempTitle(e.target.value)}
                onBlur={() => {
                  if (tempTitle.trim() && tempTitle !== node.title) {
                    onRename?.(node.id, tempTitle.trim());
                  }
                  setEditing(false);
                  setTempTitle(node.title); // Always reset to latest prop after blur
                }}
                onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); e.currentTarget.blur(); } if (e.key === 'Escape') { setEditing(false); setTempTitle(node.title); } }}
                className="w-full bg-transparent outline-none text-gray-800 dark:text-gray-100 text-[15px] px-1 rounded border border-gray-200 dark:border-[#232b3b] focus:border-blue-400 dark:focus:border-blue-500"
                style={{ minWidth: 0 }}
              />
            ) : (
              <span onDoubleClick={() => setEditing(true)} className="truncate font-medium" style={{ minWidth: 0 }}>{node.title}</span>
            )}
          </div>
          {node.id !== 'root' && (
            <button
              title="Delete"
              onClick={e => { e.stopPropagation(); onDelete?.(node.id); }}
              className="opacity-0 group-hover:opacity-100 transition p-1 rounded hover:bg-red-50 dark:hover:bg-[#2a1a1a] ml-1"
            >
              <Trash className="w-4 h-4 text-red-400" />
            </button>
          )}
          {/* Create buttons */}
          <div className="flex gap-1 ml-1 opacity-0 group-hover:opacity-100 transition">
            <button title="New page" onClick={e => { e.stopPropagation(); onCreateDoc?.(node.id); }} className="p-1 rounded hover:bg-blue-50 dark:hover:bg-[#1a2233]"><Plus className="w-4 h-4 text-blue-500" /></button>
            <button title="New folder" onClick={e => { e.stopPropagation(); onCreateFolder?.(node.id); }} className="p-1 rounded hover:bg-blue-50 dark:hover:bg-[#1a2233]"><Folder className="w-4 h-4 text-blue-400" /></button>
            <button title="Rename" onClick={e => { e.stopPropagation(); setEditing(true); }} className="p-1 rounded hover:bg-gray-200 dark:hover:bg-[#232b3b]"><Pencil className="w-4 h-4 text-gray-400" /></button>
          </div>
        </div>
        {open && node.children?.filter(child => child.active !== false).map(child => (
          <SidebarItem
            key={child.id}
            node={child}
            depth={depth + 1}
            onDragStart={onDragStart}
            onDragOver={onDragOver}
            onDrop={onDrop}
            onDelete={onDelete}
            onCreateDoc={onCreateDoc}
            onCreateFolder={onCreateFolder}
            onRename={onRename}
            autoEditId={autoEditId}
          />
        ))}
      </div>
    )
  }
  return (
    <NavLink to={`/docs/${node.id}`}
      draggable onDragStart={(e)=>onDragStart(e,node)} onDragOver={(e)=>onDragOver(e,node)} onDrop={(e)=>onDrop(e,node)}
      className={({isActive}) =>
        `group flex items-center gap-2 px-3 py-1.5 rounded-lg text-[15px] hover:bg-gray-100 dark:hover:bg-[#181f2a] transition shadow-sm ${
          isActive ? 'bg-white dark:bg-[#232b3b] shadow' : 'text-gray-700 dark:text-gray-200'
        }`
      }
      style={{paddingLeft: pad, minHeight: 36, fontWeight: 500, letterSpacing: 0.1}}
    >
      <FileText className="w-4 h-4 text-green-500 dark:text-green-400"/>
      <div className="flex-1 min-w-0 flex items-center gap-1">
        {editing ? (
          <input
            ref={inputRef}
            value={tempTitle}
            onChange={(e)=>setTempTitle(e.target.value)}
            onBlur={()=>{ setEditing(false); if(tempTitle.trim() && tempTitle!==node.title) onRename?.(node.id, tempTitle.trim()) }}
            onKeyDown={(e)=>{ if(e.key==='Enter'){ e.preventDefault(); e.currentTarget.blur() } if(e.key==='Escape'){ setEditing(false); setTempTitle(node.title) }} }
            className="w-full bg-transparent outline-none text-gray-800 dark:text-gray-100 text-[15px] px-1 rounded border border-gray-200 dark:border-[#232b3b] focus:border-green-400 dark:focus:border-green-500"
            style={{ minWidth: 0 }}
          />
        ) : (
          <span onDoubleClick={()=>setEditing(true)} className="truncate font-medium" style={{ minWidth: 0 }}>{node.title}</span>
        )}
      </div>
      <button title="Delete" onClick={(e)=>{e.preventDefault(); onDelete?.(node.id)}}
        className="opacity-0 group-hover:opacity-100 transition p-1 rounded hover:bg-red-50 dark:hover:bg-[#2a1a1a] ml-1">
        <Trash className="w-4 h-4 text-red-400" />
      </button>
    </NavLink>
  )
}
