
import { useParams } from 'react-router-dom';
import { useEffect, useState, useRef } from 'react';
import { getDisplayName } from '../utils/users';
import { EditorContent, useEditor } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Underline from '@tiptap/extension-underline';
import Link from '@tiptap/extension-link';
import ResizeImage from '../extensions/ResizeImage';
import TableWithResize from '../extensions/TableWithResize';
import Highlight from '@tiptap/extension-highlight';
import TaskList from '@tiptap/extension-task-list';
import TaskItem from '@tiptap/extension-task-item';
import TableRow from '@tiptap/extension-table-row';
import TableCell from '@tiptap/extension-table-cell';
import TableHeader from '@tiptap/extension-table-header';
import EditorToolbar from './EditorToolbar.jsx';
import { loadDocsIndex, getPathToNode, updateNodeTitle, saveDocsIndex } from '../utils/docsIndex';
import { loadAppdata, saveAppdata, markDirty, sanitizeContent } from '../utils/appdata';
import { getFile, putFile } from '../utils/github';
import { getCurrentUser } from '../utils/users';
import { queueDirtyDoc, queueDirtyIndex, queueDirtyDraft } from '../utils/remoteSync';

import { DraftBadge, hasLocalDraft } from '../utils/drafts.jsx';
import { BlockId } from '../extensions/BlockId';
import { getHistory, pushSnapshot } from '../utils/history';
import HistoryDrawer from './HistoryDrawer.jsx';
import SearchModal from './SearchModal.jsx';
import UserProfilePanel from './UserProfilePanel.jsx';
import debounce from 'lodash.debounce';




/**
 * Main editor page for documents. Maintains Vite compatibility and preserves the public interface.
 */
export default function EditorPage() {
  const { id } = useParams();
  // Find the node in the index for this id, to get the correct initial title
  const getInitialTitle = () => {
    const idx = loadDocsIndex();
    const node = (typeof id === 'string') ? findDoc(idx, id) : null;
    return node?.title || 'Untitled Page';
  };
  const [title, setTitle] = useState(getInitialTitle());

  // Only set initial title from index on mount; do not sync sidebar title to doc title after mount
  // This ensures sidebar and doc titles are independent
  const [saving, setSaving] = useState(false);
  const [path, setPath] = useState([]);
  const [showHistory, setShowHistory] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [showUserProfile, setShowUserProfile] = useState(false);
  const profileIconRef = useRef(null);
  const [lockStatus] = useState('acquired'); // pending | acquired | failed
  const [docContent, setDocContent] = useState(null);
  const [docLoaded, setDocLoaded] = useState(false);
  const user = getCurrentUser() || {};

  useEffect(() => {
    const openHistory = () => setShowHistory(true);
    const openSearch = () => setShowSearch(true);
    const openUserProfile = () => setShowUserProfile(true);
    window.addEventListener('open-history', openHistory);
    window.addEventListener('open-search', openSearch);
    window.addEventListener('open-user-profile', openUserProfile);
    return () => {
      window.removeEventListener('open-history', openHistory);
      window.removeEventListener('open-search', openSearch);
      window.removeEventListener('open-user-profile', openUserProfile);
    };
  }, []);

  const [notFound, setNotFound] = useState(false);
  // Always fetch latest doc from GitHub when id changes
  useEffect(() => {
    let cancelled = false;
    setDocLoaded(false);
    setNotFound(false);
    async function fetchDoc() {
      try {
        const file = await getFile(`docs/${id}.json`);
        let doc = null;
        if (file && file.json) {
          doc = file.json;
        } else if (file && file.content) {
          try { doc = JSON.parse(file.content); } catch { doc = null; }
        }
        if (!doc) throw new Error('No content');
  setTitle(doc.title || getInitialTitle()); // This will be overwritten by the effect above if index changes
        setDocContent(sanitizeContent(doc.content));
        setNotFound(false);
        setDocLoaded(true);
        if (!cancelled) {
          const app = loadAppdata();
          app.docs[id] = doc;
          markDirty(app);
          saveAppdata(app);
        }
      } catch {
        const app = loadAppdata();
        const doc = app.docs[id];
        if (doc) {
          setTitle(doc.title || getInitialTitle()); // This will be overwritten by the effect above if index changes
          setDocContent(sanitizeContent(doc.content));
          setNotFound(false);
          setDocLoaded(true);
          return;
        }
        const idx = loadDocsIndex();
        const legacy = findDoc(idx, id);
        if (!legacy) {
          setNotFound(true);
          setTitle('Page not found');
          setDocContent('');
          setDocLoaded(true);
          return;
        }
        const init = legacy?.initial || { content: '<p>Start writing…</p>' };
  setTitle(legacy?.title || getInitialTitle()); // This will be overwritten by the effect above if index changes
        setDocContent(sanitizeContent(init.content));
        setNotFound(false);
        setDocLoaded(true);
      }
    }
    fetchDoc();
    return () => { cancelled = true; };
  }, [id]);

  // Update breadcrumb path when id changes OR tree updates
  useEffect(() => {
    const computePath = () => {
      const idx = loadDocsIndex();
      const p = getPathToNode(idx, id);
      setPath(p || []);
    };
    computePath();
    window.addEventListener('docs-index-updated', computePath);
    return () => window.removeEventListener('docs-index-updated', computePath);
  }, [id]);


  const editor = useEditor({
    extensions: [
      StarterKit.configure({ history: true }),
      Underline,
      BlockId,
      Link.configure({ openOnClick: true, autolink: true }),
      ResizeImage,
      Highlight,
      TaskList,
      TaskItem,
      TableWithResize,
      TableRow,
      TableHeader,
      TableCell,
    ],
    content: docContent || '',
    editable: lockStatus !== 'failed',
    onUpdate: ({ editor }) => {
      const html = editor.getHTML();
      const app = loadAppdata();
      const isNew = !app.docs[id];
  // Use a unique user identifier for lastEditedBy (username or email)
  let editorId = user?.username || user?.email || user?.name || 'Unknown';
  if (isNew) app.docs[id] = { title, content: html, updatedAt: null, lastEditedBy: editorId };
  app.docs[id].title = title;
  app.docs[id].content = html;
  app.docs[id].updatedAt = new Date().toISOString();
  app.docs[id].lastEditedBy = editorId;
      markDirty(app);
      saveAppdata(app);
      queueDirtyDoc(id);
      queueDirtyDraft(id);
      if (isNew) queueDirtyIndex();
      setSaving(true);
      debouncedSaved();
    },
  }, [id, docContent, title, user.name]);

  const debouncedSaved = debounce(() => setSaving(false), 400);

  // Only update doc title in appdata/docs when changed in editor
  useEffect(() => {
    const sync = debounce((t) => {
      const app = loadAppdata();
      if (app.docs[id]) app.docs[id].title = t;
      markDirty(app);
      saveAppdata(app);
      try { console.log('[EditorPage] updated doc title only', { id, title: t }); } catch (e) { }
    }, 500);
    sync(title);
    return () => sync.cancel();
  }, [title, id]);

  useEffect(() => {
    const interval = setInterval(() => {
      const app = loadAppdata();
      const data = app.docs[id];
      if (data) pushSnapshot(id, { user: data.lastEditedBy, content: data.content, title: data.title });
    }, 60000);
    return () => clearInterval(interval);
  }, [id]);


  const history = getHistory(id);

  // Save handler: saves doc to GitHub using putFile
  const [toast, setToast] = useState({ show: false, type: '', message: '' });
  const saveDoc = async () => {
    setSaving(true);
    const app = loadAppdata();
    const data = app.docs[id];
    if (!data) { setSaving(false); return; }
    const file = await getFile(`docs/${id}.json`);
    const sha = file?.sha;
    const res = await putFile(`docs/${id}.json`, data, sha);
    setSaving(false);
    if (res.ok) {
      setToast({ show: true, type: 'success', message: 'Saved the data' });
      setTimeout(() => setToast({ show: false, type: '', message: '' }), 2000);
    } else {
      setToast({ show: true, type: 'error', message: 'Save failed!' });
      setTimeout(() => setToast({ show: false, type: '', message: '' }), 2000);
    }
  };

  const restore = (snap) => {
    editor?.commands.setContent(snap.content, false);
    setTitle(snap.title || title);
    const app = loadAppdata();
    if (app.docs[id]) {
      app.docs[id].content = snap.content;
      if (snap.title) app.docs[id].title = snap.title;
      markDirty(app);
      saveAppdata(app);
    }
    setShowHistory(false);
  };

  if (!docLoaded) return <SkeletonEditor />;
  if (notFound) {
    return (
      <div className="max-w-2xl mx-auto px-6 py-12 text-center text-lg text-red-600">
        <strong>No document found.</strong>
      </div>
    );
  }
  return (
    <>
      <div className="sticky top-0 z-30 bg-white dark:bg-[#101828] shadow-sm border-b border-borderLight dark:border-[#232b3b]">
        <EditorToolbar editor={editor} />
      </div>
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="bg-white dark:bg-[#101828] rounded-2xl shadow-xl border border-borderLight dark:border-[#232b3b] p-8">
          <nav className="text-[15px] mb-4 text-gray-400 dark:text-gray-400 flex items-center flex-wrap gap-1">
            <span className="text-atlassianBlue font-semibold cursor-pointer">DocX</span>
            <span className="px-1">/</span>
            {path.length === 0 ? (
              <>
                <span className="text-atlassianBlue font-semibold cursor-pointer">Pages</span>
                <span className="px-1">/</span>
                <span className="font-semibold text-gray-700 dark:text-gray-100">{title || 'Page'}</span>
              </>
            ) : (
              path.filter(n => n.id !== 'root').map((node, idx, arr) => (
                <span key={node.id} className={
                  idx === arr.length - 1
                    ? 'font-semibold text-gray-700 dark:text-gray-100'
                    : 'text-atlassianBlue font-semibold cursor-pointer hover:underline'
                }>
                  {node.title || 'Untitled'}
                  {idx < arr.length - 1 && <span className="px-1">/</span>}
                </span>
              ))
            )}
            <span className="ml-3 inline-block text-[11px] px-2 py-0.5 border border-borderLight rounded-full bg-gray-100 dark:bg-[#232b3b] text-gray-500 dark:text-gray-300">DRAFT</span>
          </nav>
          <div className="flex items-center gap-3 mb-2">
            <input
              className="flex-1 text-[2rem] font-bold placeholder:text-[#A5ADBA] bg-transparent outline-none dark:text-white rounded-lg px-2 py-1 focus:ring-2 focus:ring-blue-200 dark:focus:ring-blue-900 transition"
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="Page title"
              style={{ marginBottom: 0 }}
            />
            <button
              onClick={saveDoc}
              className="ml-2 px-5 py-2 text-base rounded-lg bg-atlassianBlue text-white font-semibold shadow hover:brightness-110 transition"
              style={{ whiteSpace: 'nowrap' }}
            >
              Save
            </button>
          </div>
          {/* Toast is now rendered at the root below */}
          <div className="flex items-center justify-between mb-4">
            <div className="text-xs text-gray-400 dark:text-gray-400">
              Last edited by <span className="font-semibold text-gray-700 dark:text-gray-200">{getDisplayName() || user?.name || user?.username || user?.email || 'Unknown'}</span>
              <DraftBadge docId={id} />
            </div>
          </div>
          <div className="editor-surface p-4 rounded-xl bg-gray-50 dark:bg-[#181f2a] border border-gray-200 dark:border-[#232b3b]">
            {!editor && <SkeletonEditor />}
            {editor && <EditorContent editor={editor} className="prose max-w-none dark:prose-invert" />}
          </div>
        </div>
      </div>
      {/* Removed bottom Save button and status bar as requested */}
      <HistoryDrawer open={showHistory} onClose={() => setShowHistory(false)} history={history} onRestore={restore} />
      <SearchModal open={showSearch} onClose={() => setShowSearch(false)} />
      <UserProfilePanel open={showUserProfile} onClose={() => setShowUserProfile(false)} anchorRef={profileIconRef} />
      {toast.show && (
        <div
          className={`fixed top-6 left-1/2 transform -translate-x-1/2 px-4 py-2 rounded shadow-lg z-50 transition-all ${toast.type === 'success' ? 'bg-green-600 text-white' : 'bg-red-600 text-white'}`}
        >
          {toast.message}
        </div>
      )}
    </>
  );
}

function findDoc(tree, id){
  for (const n of tree){
    if (n.type==='doc' && n.id===id) return n
    if (n.children){ const f = findDoc(n.children,id); if (f) return f }
  }
  return null
}

function SkeletonEditor(){
  return (
    <div className="space-y-4 animate-pulse" aria-label="Loading editor">
      <div className="h-5 w-2/5 rounded bg-gray-200 dark:bg-[#1F2937]" />
      <div className="space-y-2">
        <div className="h-4 w-full rounded bg-gray-200 dark:bg-[#1F2937]" />
        <div className="h-4 w-11/12 rounded bg-gray-200 dark:bg-[#1F2937]" />
        <div className="h-4 w-5/6 rounded bg-gray-200 dark:bg-[#1F2937]" />
        <div className="h-4 w-2/3 rounded bg-gray-200 dark:bg-[#1F2937]" />
        <div className="h-4 w-3/4 rounded bg-gray-200 dark:bg-[#1F2937]" />
        <div className="h-4 w-1/2 rounded bg-gray-200 dark:bg-[#1F2937]" />
      </div>
      <div className="h-5 w-1/3 rounded bg-gray-200 dark:bg-[#1F2937]" />
      <div className="space-y-2">
        <div className="h-4 w-full rounded bg-gray-200 dark:bg-[#1F2937]" />
        <div className="h-4 w-10/12 rounded bg-gray-200 dark:bg-[#1F2937]" />
        <div className="h-4 w-9/12 rounded bg-gray-200 dark:bg-[#1F2937]" />
        <div className="h-4 w-2/3 rounded bg-gray-200 dark:bg-[#1F2937]" />
      </div>
    </div>
  );
}

