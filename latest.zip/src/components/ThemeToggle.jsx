
import { useEffect, useState } from 'react';
import { Moon, Sun } from 'lucide-react';

/**
 * Theme toggle button for switching between light and dark mode.
 * Maintains Vite compatibility and preserves the public interface.
 */
export default function ThemeToggle() {
  const [dark, setDark] = useState(false);

  useEffect(() => {
    const root = document.documentElement;
    if (dark) root.classList.add('dark');
    else root.classList.remove('dark');
  }, [dark]);

  return (
    <button
      className="flex items-center gap-2 px-2 py-1 rounded border border-borderLight dark:border-[#1F2937] hover:bg-[#F4F5F7] dark:hover:bg-[#101828] transition"
      onClick={() => setDark((d) => !d)}
      title="Toggle theme"
    >
      {dark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
      <span className="text-sm">{dark ? 'Light' : 'Dark'}</span>
    </button>
  );
}
