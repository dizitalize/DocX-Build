
import { useRef, useEffect, useState } from 'react';
import { Search, HelpCircle, UserRound, Loader2, Cloud, CheckCircle, CloudUpload, AlertTriangle } from 'lucide-react';
import ThemeToggle from './ThemeToggle';

function SyncStatus() {
  const [state, setState] = useState('idle');
  const [dirty, setDirty] = useState(false);
  const [warning, setWarning] = useState(null);

  useEffect(() => {
    const handleSyncState = (e) => setState(e.detail);
    window.addEventListener('sync-state', handleSyncState);
    const interval = setInterval(() => {
      try {
        const rs = window.__remoteSyncStatus;
        if (rs) {
          setDirty(rs.hasDirty);
          if (rs.lastError) setWarning(rs.lastError);
        }
      } catch {}
    }, 4000);
    return () => {
      window.removeEventListener('sync-state', handleSyncState);
      clearInterval(interval);
    };
  }, []);

  let icon = null;
  let title = '';
  if (state === 'bootstrap') {
    icon = <Cloud className="w-4 h-4 animate-pulse" />;
    title = 'Bootstrapping remote data';
  } else if (state === 'scheduled') {
    icon = <CloudUpload className="w-4 h-4 animate-pulse" />;
    title = 'Changes queued for sync';
  } else if (state === 'flushing') {
    icon = <Loader2 className="w-4 h-4 animate-spin" />;
    title = 'Syncing with GitHub...';
  } else if (warning) {
    icon = <AlertTriangle className="w-4 h-4 text-amber-500" />;
    title = 'Sync warning: check console';
  } else if (dirty) {
    icon = <CloudUpload className="w-4 h-4" />;
    title = 'Pending local changes';
  } else {
    icon = <CheckCircle className="w-4 h-4 text-emerald-500" />;
    title = 'All changes saved';
  }

  return (
    <div className="flex items-center gap-1 text-xs text-textSecondary dark:text-gray-400" title={title}>
      {icon}
    </div>
  );
}

/**
 * Top navigation bar for the app. Maintains Vite compatibility and preserves the public interface.
 */
export default function TopNav() {
  const profileIconRef = useRef(null);
  return (
    <header className="h-14 bg-white dark:bg-[#0B0F1A] border-b border-borderLight dark:border-[#1F2937] flex items-center justify-between px-4">
      <div className="flex items-center gap-3">
        <img src="https://github.com/dizitalize/DocX/raw/main/logo.png" alt="DocX Logo" className="w-16 h-16" style={{ objectFit: 'contain' }} />
      </div>
      <div className="flex items-center gap-3">
        <SyncStatus />
        <ThemeToggle />
        <Search className="w-5 h-5 cursor-pointer text-textSecondary dark:text-gray-300" onClick={() => window.dispatchEvent(new CustomEvent('open-search'))} />
        <HelpCircle className="w-5 h-5 cursor-pointer text-textSecondary dark:text-gray-300" />
        <div
          ref={profileIconRef}
          className="w-8 h-8 rounded-full bg-[#DFE1E6] dark:bg-[#1F2937] flex items-center justify-center cursor-pointer"
          onClick={() => window.dispatchEvent(new CustomEvent('open-user-profile'))}
        >
          <UserRound className="w-5 h-5 text-textSecondary dark:text-gray-300" />
        </div>
      </div>
    </header>
  );
}
