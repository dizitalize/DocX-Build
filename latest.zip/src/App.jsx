import { Routes, Route, Navigate } from 'react-router-dom'
import TopNav from './components/TopNav.jsx'
import Sidebar from './components/Sidebar.jsx'
import { useState } from 'react'
import EditorPage from './components/EditorPage.jsx'
import ViewPage from './components/ViewPage.jsx'
import { loadDocsIndex } from './utils/docsIndex'
import { getCurrentUser } from './utils/users'
import UserSettingsPage from './components/UserSettingsPage.jsx'


function isLoggedIn(){ return !!getCurrentUser() }

export default function App() {
  const logged = isLoggedIn()
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  // find first doc id in index (only load index when logged in)
  function findFirstDoc(nodes){
    for(const n of nodes){
      if(n.type==='doc') return n.id
      if(n.children){ const r = findFirstDoc(n.children); if(r) return r }
    }
    return null
  }
  let firstDoc = 'demo'
  if(logged){
    const index = loadDocsIndex()
    firstDoc = findFirstDoc(index) || 'demo'
  }
  return (
    <div className="min-h-screen text-textPrimary dark:text-white">
      <TopNav />
      <div className="flex flex-nowrap">
        {logged && (
          <div
            style={{ width: sidebarCollapsed ? 48 : 256, minWidth: sidebarCollapsed ? 48 : 180, maxWidth: sidebarCollapsed ? 48 : 480 }}
            className="h-[calc(100vh-56px)] bg-white dark:bg-[#101624] border-r border-gray-200 dark:border-gray-800 transition-all duration-150 ease-in-out"
          >
            <Sidebar collapsed={sidebarCollapsed} setCollapsed={setSidebarCollapsed} />
          </div>
        )}
        <div className="flex-1 min-h-[calc(100vh-56px)] bg-[#FAFBFC] dark:bg-[#0B0F1A] transition-all duration-150 ease-in-out">
          <Routes>
            <Route path="/" element={logged ? <Navigate to={`/view/${firstDoc}`} replace /> : <Navigate to="/login" replace />} />
            <Route path="/docs/:id" element={isLoggedIn() ? <EditorPage /> : <Navigate to="/login" />} />
            <Route path="/view/:id" element={isLoggedIn() ? <ViewPage /> : <Navigate to="/login" />} />
            <Route path="/settings" element={isLoggedIn() ? <UserSettingsPage /> : <Navigate to="/login" />} />
          </Routes>
        </div>
      </div>
    </div>
  )
}
