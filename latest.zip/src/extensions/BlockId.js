
import { Extension } from '@tiptap/core';
import { nanoid } from 'nanoid';

/**
 * Tiptap extension to add a unique block ID attribute to block nodes.
 * Applies to paragraph, heading, blockquote, and codeBlock types.
 */
export const BlockId = Extension.create({
  name: 'blockId',
  addGlobalAttributes() {
    return [
      {
        types: ['paragraph', 'heading', 'blockquote', 'codeBlock'],
        attributes: {
          'data-block-id': {
            default: null,
            rendered: true,
            parseHTML: el => el.getAttribute('data-block-id'),
            renderHTML: attrs => ({ 'data-block-id': attrs['data-block-id'] || nanoid(8) }),
          },
        },
      },
    ];
  },
});
