
// Tiptap extension: Image node with resizable handles and aspect ratio lock.
import { Node, mergeAttributes } from '@tiptap/core';
import { NodeSelection } from 'prosemirror-state';

export const ResizeImage = Node.create({
  name: 'image',
  group: 'inline',
  inline: true,
  draggable: true,
  selectable: true,
  addAttributes() {
    return {
      src: { default: null },
      alt: { default: null },
      title: { default: null },
      width: { default: 'auto' },
      height: { default: 'auto' },
      style: { default: null },
    };
  },
  parseHTML() {
    return [{ tag: 'img[src]' }];
  },
  renderHTML({ HTMLAttributes }) {
    return ['img', mergeAttributes(HTMLAttributes)];
  },
  addNodeView() {
    return ({ node, getPos, editor, selected }) => {
      const img = document.createElement('img');
      img.src = node.attrs.src;
      img.alt = node.attrs.alt || '';
      img.title = node.attrs.title || '';
      img.style.width = node.attrs.width || 'auto';
      img.style.height = node.attrs.height || 'auto';
      img.style.maxWidth = '100%';
      img.style.cursor = 'pointer';
      img.draggable = false;
      img.tabIndex = 0;
      const container = document.createElement('span');
      container.style.position = 'relative';
      container.style.display = 'inline-block';
      container.style.verticalAlign = 'middle';

      function selectImage(e) {
        e.stopPropagation();
        const { state, view } = editor;
        const pos = getPos();
        if (typeof pos === 'number') {
          setTimeout(() => {
            const tr = state.tr.setSelection(NodeSelection.create(state.doc, pos));
            view.dispatch(tr);
          }, 0);
        }
      }
      img.addEventListener('click', selectImage);
      img.addEventListener('contextmenu', (e) => { selectImage(e); e.preventDefault(); });
      container.addEventListener('click', (e) => { selectImage(e); });

      function setBorderAndHandles(show) {
        img.style.outline = show ? '2px solid #3182ce' : 'none';
        img.style.outlineOffset = show ? '2px' : '0';
        for (const h of container.querySelectorAll('.resize-handle')) {
          h.style.display = show ? 'block' : 'none';
        }
      }

      const cornerHandles = [
        { x: 0, y: 0, cursor: 'nwse-resize', name: 'top-left' },
        { x: 100, y: 0, cursor: 'nesw-resize', name: 'top-right' },
        { x: 100, y: 100, cursor: 'nwse-resize', name: 'bottom-right' },
        { x: 0, y: 100, cursor: 'nesw-resize', name: 'bottom-left' },
      ];
      cornerHandles.forEach((h) => {
        const handle = document.createElement('div');
        handle.className = 'resize-handle';
        handle.contentEditable = 'false';
        handle.setAttribute('data-handle', h.name);
        handle.setAttribute('role', 'slider');
        handle.setAttribute('aria-label', `Resize image ${h.name}`);
        handle.tabIndex = 0;
        handle.style.left = `calc(${h.x}% - 6px)`;
        handle.style.top = `calc(${h.y}% - 6px)`;
        handle.setAttribute('aria-hidden', selected ? 'false' : 'true');
        handle.style.cursor = h.cursor;
        handle.addEventListener('mousedown', (event) => {
          event.preventDefault();
          event.stopPropagation();
          const startX = event.clientX;
          const startY = event.clientY;
          const startWidth = img.offsetWidth;
          const startHeight = img.offsetHeight;
          const aspect = startWidth / startHeight || 1;
          function onMouseMove(e) {
            let deltaX = 0;
            if (h.name.includes('left')) {
              deltaX = startX - e.clientX;
            } else {
              deltaX = e.clientX - startX;
            }
            let newWidth = Math.max(32, Math.round(startWidth + deltaX));
            let newHeight = Math.max(32, Math.round(newWidth / aspect));
            img.style.width = newWidth + 'px';
            img.style.height = newHeight + 'px';
          }
          function onMouseUp() {
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
            const transaction = editor.state.tr.setNodeMarkup(getPos(), undefined, {
              ...node.attrs,
              width: img.style.width,
              height: img.style.height,
            });
            editor.view.dispatch(transaction);
          }
          document.addEventListener('mousemove', onMouseMove);
          document.addEventListener('mouseup', onMouseUp);
        });
        handle.addEventListener('keydown', (ke) => {
          const step = ke.shiftKey ? 10 : 1;
          const startWidth = img.offsetWidth;
          const startHeight = img.offsetHeight;
          let newWidth = startWidth;
          let newHeight = startHeight;
          if (ke.key === 'ArrowRight') newWidth = startWidth + step;
          if (ke.key === 'ArrowLeft') newWidth = Math.max(32, startWidth - step);
          if (ke.key === 'ArrowDown') newHeight = startHeight + step;
          if (ke.key === 'ArrowUp') newHeight = Math.max(32, startHeight - step);
          if (ke.key === 'Enter') {
            const transaction = editor.state.tr.setNodeMarkup(getPos(), undefined, {
              ...node.attrs,
              width: img.style.width,
              height: img.style.height,
            });
            editor.view.dispatch(transaction);
          } else {
            img.style.width = newWidth + 'px';
            img.style.height = newHeight + 'px';
            ke.preventDefault();
          }
        });
        container.appendChild(handle);
      });
      container.appendChild(img);
      setBorderAndHandles(!!selected);
      return {
        dom: container,
        contentDOM: null,
        update: (updatedNode, decorations, innerSelected) => {
          setBorderAndHandles(!!innerSelected);
          return true;
        },
      };
    };
  },
});

export default ResizeImage;
