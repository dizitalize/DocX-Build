
import { Node } from '@tiptap/core';

/**
 * ResizeTable extension for Tiptap: Adds resizable handles to tables.
 * - Handles appear when the table is selected.
 * - Supports mouse and keyboard resizing.
 * - Persists size in node attrs if schema supports 'style'.
 * - Vite compatible, no public API changes.
 */
export const ResizeTable = Node.create({
  name: 'table',
  group: 'block',
  selectable: true,
  draggable: false,
  addNodeView() {
    return ({ node, getPos, editor, selected }) => {
      // Container for the table and resize handles
      const container = document.createElement('div');
      container.style.position = 'relative';
      container.style.display = 'block';
      container.style.width = '100%';
      container.style.boxSizing = 'border-box';

      // contentDOM: ProseMirror will render the actual table inside this element
      const content = document.createElement('div');
      content.style.display = 'block';
      container.appendChild(content);

      let handles = [];

      /**
       * Remove all resize handles from the DOM.
       */
      function clearHandles() {
        handles.forEach((h) => h.remove());
        handles = [];
      }

      /**
       * Create a resize handle at a given position.
       */
      function createHandle(xPct, yPct, cursor, name) {
        const handle = document.createElement('div');
        handle.className = 'table-resize-handle';
        handle.style.position = 'absolute';
        handle.style.width = '12px';
        handle.style.height = '12px';
        handle.style.background = '#3182ce';
        handle.style.border = '2px solid #fff';
        handle.style.borderRadius = '50%';
        handle.style.boxShadow = '0 0 2px #0003';
        handle.style.left = `calc(${xPct}% - 6px)`;
        handle.style.top = `calc(${yPct}% - 6px)`;
        handle.style.cursor = cursor;
        handle.style.zIndex = '20';
        handle.setAttribute('data-handle', name);
        handle.style.display = selected ? 'block' : 'none';
        handle.tabIndex = 0;
        handle.setAttribute('role', 'slider');
        handle.setAttribute('aria-label', `Resize table ${name}`);
        handle.setAttribute('aria-hidden', selected ? 'false' : 'true');
        return handle;
      }

      /**
       * Refresh the resize handles based on the current table element.
       */
      function refreshHandles() {
        const tbl = content.querySelector('table');
        if (!tbl) {
          clearHandles();
          return;
        }
        clearHandles();
        const positions = [
          { x: 0, y: 0, cursor: 'nwse-resize', name: 'top-left' },
          { x: 50, y: 0, cursor: 'ns-resize', name: 'top-center' },
          { x: 100, y: 0, cursor: 'nesw-resize', name: 'top-right' },
          { x: 100, y: 50, cursor: 'ew-resize', name: 'middle-right' },
          { x: 100, y: 100, cursor: 'nwse-resize', name: 'bottom-right' },
          { x: 50, y: 100, cursor: 'ns-resize', name: 'bottom-center' },
          { x: 0, y: 100, cursor: 'nesw-resize', name: 'bottom-left' },
          { x: 0, y: 50, cursor: 'ew-resize', name: 'middle-left' },
        ];
        positions.forEach((p) => {
          const handle = createHandle(p.x, p.y, p.cursor, p.name);
          // Mouse drag logic
          handle.addEventListener('mousedown', (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            const startX = ev.clientX;
            const startY = ev.clientY;
            const startW = tbl.offsetWidth;
            const startH = tbl.offsetHeight;

            function onMove(e) {
              let newW = startW;
              let newH = startH;
              if (p.name.includes('left')) {
                newW = Math.max(64, startW - (e.clientX - startX));
              }
              if (p.name.includes('right')) {
                newW = Math.max(64, startW + (e.clientX - startX));
              }
              if (p.name.includes('top')) {
                newH = Math.max(32, startH - (e.clientY - startY));
              }
              if (p.name.includes('bottom')) {
                newH = Math.max(32, startH + (e.clientY - startY));
              }
              tbl.style.width = newW + 'px';
              tbl.style.height = newH + 'px';
            }

            function onUp() {
              document.removeEventListener('mousemove', onMove);
              document.removeEventListener('mouseup', onUp);
              // Persist size into node attrs if possible
              try {
                const pos = getPos();
                if (typeof pos === 'number') {
                  const attrs = { ...node.attrs };
                  attrs.style = tbl.getAttribute('style') || '';
                  const tr = editor.state.tr.setNodeMarkup(pos, undefined, attrs);
                  editor.view.dispatch(tr);
                }
              } catch (err) {
                // ignore
              }
            }

            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
          });
          // Keyboard resize logic
          handle.addEventListener('keydown', (ke) => {
            const step = ke.shiftKey ? 10 : 1;
            const tbl = content.querySelector('table');
            if (!tbl) return;
            const startW = tbl.offsetWidth;
            const startH = tbl.offsetHeight;
            let newW = startW;
            let newH = startH;
            if (ke.key === 'ArrowRight') newW = startW + step;
            if (ke.key === 'ArrowLeft') newW = Math.max(64, startW - step);
            if (ke.key === 'ArrowDown') newH = startH + step;
            if (ke.key === 'ArrowUp') newH = Math.max(32, startH - step);
            tbl.style.width = newW + 'px';
            tbl.style.height = newH + 'px';
            if (ke.key === 'Enter') {
              try {
                const pos = getPos();
                if (typeof pos === 'number') {
                  const attrs = { ...node.attrs };
                  attrs.style = tbl.getAttribute('style') || '';
                  const tr = editor.state.tr.setNodeMarkup(pos, undefined, attrs);
                  editor.view.dispatch(tr);
                }
              } catch (err) {
                // ignore
              }
            }
            ke.preventDefault();
          });
          container.appendChild(handle);
          handles.push(handle);
        });
      }

      // Observe table rendering and refresh handles
      const observer = new MutationObserver(refreshHandles);
      observer.observe(content, { childList: true, subtree: true });

      // Initial refresh
      setTimeout(refreshHandles, 20);

      return {
        dom: container,
        contentDOM: content,
        update: (_updatedNode, _decorations, innerSelected) => {
          handles.forEach((h) => (h.style.display = innerSelected ? 'block' : 'none'));
          refreshHandles();
          return true;
        },
        destroy: () => observer.disconnect(),
      };
    };
  },
});

export default ResizeTable;
