// crypto.js
// Usage:
//   node crypto.js encrypt   -> saves some.enc.json
//   node crypto.js decrypt   -> reads some.enc.json and prints plaintext

import fs from "fs";
import crypto from "crypto";
import 'dotenv/config';

// ===== CONFIG =====
const PASSPHRASE = "mohansecure";   // change if needed
const OUTPUT_FILE = "Key.json";
const ITERATIONS = 200000;

// ===== ENCRYPT =====
function encryptToJson(text) {
  const salt = crypto.randomBytes(16);
  const iv = crypto.randomBytes(12);

  const key = crypto.pbkdf2Sync(PASSPHRASE, salt, ITERATIONS, 32, "sha256");

  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  const encrypted = Buffer.concat([cipher.update(text, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();

  return {
    algorithm: "AES-256-GCM",
    iterations: ITERATIONS,
    salt: salt.toString("base64"),
    iv: iv.toString("base64"),
    tag: tag.toString("base64"),
    data: encrypted.toString("base64"),
  };
}

// ===== DECRYPT =====
function decryptFromJson(encObj) {
  const salt = Buffer.from(encObj.salt, "base64");
  const iv = Buffer.from(encObj.iv, "base64");
  const tag = Buffer.from(encObj.tag, "base64");
  const data = Buffer.from(encObj.data, "base64");

  const key = crypto.pbkdf2Sync(PASSPHRASE, salt, encObj.iterations, 32, "sha256");

  const decipher = crypto.createDecipheriv("aes-256-gcm", key, iv);
  decipher.setAuthTag(tag);

  const decrypted = Buffer.concat([decipher.update(data), decipher.final()]);
  return decrypted.toString("utf8");
}

// ===== MAIN EXECUTION =====
const mode = process.argv[2];

if (mode === "encrypt") {
  const secret = process.env.MY_SECRET;
  if (!secret) {
    console.error("❌ Missing MY_SECRET in .env");
    process.exit(1);
  }

  const encJson = encryptToJson(secret);
  fs.writeFileSync(OUTPUT_FILE, JSON.stringify(encJson, null, 2), "utf8");
  console.log(`✅ Encrypted and saved to ${OUTPUT_FILE}`);

} else if (mode === "decrypt") {
  if (!fs.existsSync(OUTPUT_FILE)) {
    console.error(`❌ ${OUTPUT_FILE} not found`);
    process.exit(1);
  }

  const encObj = JSON.parse(fs.readFileSync(OUTPUT_FILE, "utf8"));
  const plaintext = decryptFromJson(encObj);

  console.log("✅ Decrypted value:");
  console.log(plaintext);

} else {
  console.log(`
Usage:
  node crypto.js encrypt    -> saves some.enc.json
  node crypto.js decrypt    -> prints decrypted value

Make sure .env contains:
  MY_SECRET=yoursecrettext
`);
}
