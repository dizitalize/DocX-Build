# Security & Credential Handling

This project currently embeds a hard-coded Personal Access Token (PAT) for GitHub in `src/utils/github.ts`.

## Risks
- Exposure: Anyone inspecting source or network traffic can extract the token.
- Scope escalation: If the PAT has broader scopes than needed (e.g. repo:all, delete), compromise impact grows.
- Accidental leak: Committing the PAT publicly persists it in Git history even after removal.

## Recommended Mitigations
| Area | Current | Recommended |
| ---- | ------- | ---------- |
| Auth Secret | Hard-coded Base64 PAT | Environment variable injected at build (e.g. Vite env) or server-side proxy |
| Token Scope | Potentially broad | Restrict to `repo` (or fine-grained token limited to target repo) |
| Client Writes | Direct from browser | Route through minimal backend that validates ops & rate-limits |
| Locking | Ad-hoc lock files | Consider server-managed distributed locks (Redis) for multi-user edits |
| Draft Storage | Plain localStorage | Optional encryption (Crypto.subtle) if sensitive content |

## Migration Path
1. Remove encoded PAT constant; read `import.meta.env.VITE_GH_TOKEN` (never commit `.env`).
2. Add a lightweight proxy endpoint `/api/github` that accepts signed requests (JWT from login) and performs GitHub writes.
3. Rotate existing token and revoke old PAT.
4. Implement token usage analytics / alert on unusual commit frequency.

## Handling Conflicts
We store remote `sha` per doc (`app.docs[id].sha`). Before overwriting remote content, fetch current sha and compare:
- If unchanged: proceed.
- If different: fetch remote content and materialize a conflict copy `docId-conflict-<timestamp>.json`, then surface merge UI.

## Data Integrity Add-ons (Future)
- Content hash (SHA256) field in each doc; verify after fetch.
- Tamper-evident audit log: append-only `journal.json` recording operations with user + timestamp.
- Optional encryption-at-rest of drafts using user-derived key (PBKDF2).

## Least Privilege Principle
Use fine-grained GitHub token with permissions limited to: Contents read/write for this single repo.
Avoid enabling Actions, Packages, or Admin scopes.

## Summary
DO NOT deploy with embedded PAT. Use environment config + backend proxy. Add monitoring and narrow scopes to reduce impact of leak.
