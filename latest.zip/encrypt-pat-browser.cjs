// encrypt-pat-browser.js

// Encrypts the MY_SECRET from .env using the password 'Docxv11' and saves to key.json
// Usage: node encrypt-pat-browser.js <outputFile>

const fs = require('fs');
const crypto = require('crypto');
require('dotenv').config();

if (process.argv.length < 3) {
  console.log('Usage: node encrypt-pat-browser.js <outputFile>');
  process.exit(1);
}

const SECRET = process.env.MY_SECRET;
const PASSWORD = 'Docxv11';
const OUTPUT_FILE = process.argv[2];

if (!SECRET) {
  console.error('❌ MY_SECRET not found in .env');
  process.exit(1);
}

const salt = crypto.randomBytes(16);
const iv = crypto.randomBytes(12);
const iterations = 200000;
const key = crypto.pbkdf2Sync(PASSWORD, salt, iterations, 32, 'sha256');

const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
const encrypted = Buffer.concat([cipher.update(SECRET, 'utf8'), cipher.final()]);
const tag = cipher.getAuthTag();

const encObj = {
  algorithm: 'AES-256-GCM',
  iterations,
  salt: salt.toString('base64'),
  iv: iv.toString('base64'),
  tag: tag.toString('base64'),
  data: encrypted.toString('base64')
};

fs.writeFileSync(OUTPUT_FILE, JSON.stringify(encObj, null, 2), 'utf8');
console.log(`✅ Encrypted and saved to ${OUTPUT_FILE}`);
