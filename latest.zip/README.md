# Docs Home (Confluence-style Editor)

Modern React + TipTap knowledge base that runs locally and on GitHub Pages.

## Features
- Confluence-style UI (sidebar tree, sticky editor toolbar, breadcrumbs)
- Folders with drag & drop
- TipTap rich editor (tables, tasks, images, code)
- LocalStorage persistence
- Login + last edited by
- Version history with restore
- Comments per block
- Global search (Ctrl/⌘+K)
- Dark / Light theme toggle
- GitHub auto-save (optional)

## Setup
```bash
npm install
npm run dev
```

## GitHub Auto-save
Set your GitHub config once in the browser console:
```js
localStorage.setItem('githubSync', JSON.stringify({
  owner:'YOUR_GH_USER',
  repo:'YOUR_REPO',
  branch:'main',
  token:'YOUR_PAT_WITH_REPO_SCOPE',
  basePath:'docs' // optional subfolder
}))
```

## Deploy to GitHub Pages
Build with a base if needed:
```bash
VITE_BASE=/YOUR_REPO_NAME/ npm run build
```
Host the `dist/` folder with GitHub Pages.
