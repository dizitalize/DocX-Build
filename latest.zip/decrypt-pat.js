// decrypt-pat.js
// Usage: node decrypt-pat.js <passphrase> <inputFile> <outputFile>
// Example: node decrypt-pat.js mypassphrase key.json public/key.json

const fs = require('fs');
const crypto = require('crypto');

if (process.argv.length < 5) {
  console.log('Usage: node decrypt-pat.js <passphrase> <inputFile> <outputFile>');
  process.exit(1);
}

const PASSPHRASE = process.argv[2];
const INPUT_FILE = process.argv[3];
const OUTPUT_FILE = process.argv[4];

const encObj = JSON.parse(fs.readFileSync(INPUT_FILE, 'utf8'));
const salt = Buffer.from(encObj.salt, 'base64');
const iv = Buffer.from(encObj.iv, 'base64');
const tag = Buffer.from(encObj.tag, 'base64');
const data = Buffer.from(encObj.data, 'base64');
const key = crypto.pbkdf2Sync(PASSPHRASE, salt, encObj.iterations, 32, 'sha256');

const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
decipher.setAuthTag(tag);
const decrypted = Buffer.concat([decipher.update(data), decipher.final()]);
const pat = decrypted.toString('utf8');

fs.writeFileSync(OUTPUT_FILE, JSON.stringify({ pat }, null, 2), 'utf8');
console.log(`✅ Decrypted PAT written to ${OUTPUT_FILE}`);