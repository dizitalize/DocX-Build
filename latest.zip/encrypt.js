// example.js
import {  encryptMohan, decryptMohan  } from './cryptoMohanSecure.js';

const passphrase = "mohansecure";  // your custom secret

const secret = "ghp_XXXXXXXXXXXXXXXXXXXXXXX";

// Encrypt
const encrypted = encryptMohan(secret, passphrase);
console.log("Encrypted JSON:", encrypted);

// Convert to string if saving to file:
const jsonString = JSON.stringify(encrypted);
console.log("\nStore this anywhere:\n", jsonString);

// Decrypt
const decrypted = decryptMohan(JSON.parse(jsonString), passphrase);
console.log("\nDecrypted value:", decrypted);