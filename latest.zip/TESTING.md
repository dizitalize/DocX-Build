# Testing Plan

This document outlines manual and automated test flows to validate reliable GitHub-backed CRUD, conflict safety, and draft/lock features.

## Environments
- Local dev: `npm run dev` (Vite) with test PAT or proxy.
- Incognito / second browser window for multi-session tests.

## Preconditions
- At least one starter doc (Welcome).
- Remote repo initialized with `index.json`.

## Test Categories
### 1. Create / Update
| Step | Expected |
| ---- | -------- |
| Create new page via sidebar | Local index updates instantly; after debounce flush, remote `docs/<id>.json` then `index.json` created |
| Type continuously for 5s | Only final content appears after flush; history snapshot only every 60s |
| Rename page | Remote `index.json` updated once; doc file retains same id & updates `title` |

### 2. Draft Autosave
| Step | Expected |
| Open page, edit content without publishing | `localStorage` entry `draftAutosave:<id>` exists; remote `drafts/<id>.json` after flush |
| Refresh page before flush | Editor restores draft content; draft badge visible |
| Publish | Draft badge removed; draft key cleared; history snapshot added |

### 3. Locking
| Step | Expected |
| Open doc in Window A (lock acquired) | Lock file created `locks/<id>.lock` with your user name |
| Open same doc in Window B | Editor becomes read-only with warning; no content updates flushed |
| Close Window A | Lock released (DELETE); B can refresh to acquire lock |

### 4. Conflict (Simulated)
| Step | Expected |
| Modify remote file directly on GitHub while local draft dirty | On next flush 409 resolves with sha refresh; local doc sha updated |
| Force divergent changes (rapid remote edits) | After max attempts, error logged; no data loss locally |

### 5. Delete
| Step | Expected |
| Delete page with children | All child doc files removed locally; remote flush leaves orphan or (future) marks tombstone |

### 6. Reconciliation (after implementation)
| Step | Expected |
| Manually add `docs/<id>.json` remote (not in index) | Bootstrap/interval adds it under "Recovered" folder |
| Remove doc from index manually remote | Local reconciliation prunes stale entry |

### 7. Lifecycle / Autosave
| Step | Expected |
| Close tab with unsaved changes | Prompt shown; if stay, flush completes; if leave, attempt best-effort hidden flush |

### 8. Security (Manual)
| Step | Expected |
| Remove PAT, use empty token | Remote writes skipped; UI icons show pending changes but no PUTs |
| Inject invalid token | 401 errors logged; `remote-failure` event fired; badge shows warning |

## Automated Test Ideas
Minimal script harness (future):
1. `createDoc(n)` programmatically for N docs.
2. Random edit cycles over docs; assert sha updates.
3. Simulated conflict: modify file then trigger flush.
4. Cleanup: verify index integrity vs docs directory file list.

## Regression Checklist Before Release
- [ ] Create/edit/publish works.
- [ ] Draft restore after reload works.
- [ ] Lock prevents second editor from modifying.
- [ ] SHA stored after flush (`app.docs[id].sha`).
- [ ] No infinite 409 loops.
- [ ] Sidebar reflects remote index after pull.

## Reporting
Capture console logs during tests; highlight any `[remoteSync] flush error` or `[github] getFile failed` occurrences.

## Future Additions
- Jest/Playwright integration for E2E multi-tab simulation.
- Mock GitHub layer for offline CI tests.
