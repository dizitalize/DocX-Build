/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html','./src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        atlassianBlue: '#0052CC',
        pageBg: '#FFFFFF',
        sidebarBg: '#F4F5F7',
        textPrimary: '#172B4D',
        textSecondary: '#42526E',
        borderLight: '#DFE1E6',
        toolbarBg: '#FAFBFC'
      },
      boxShadow: {
        toolbar: '0 1px 2px rgba(9,30,66,0.15)',
        editor: '0 1px 2px rgba(9,30,66,0.08)'
      }
    }
  },
  plugins: [require('@tailwindcss/typography')]
}
